#!/bin/bash
# next_report.sh -- what the diag + moeblk sequence produced
echo "##### chunk_diag (full model, 2200 tokens, vs the saved chunk-512 reference)"
[ -f ~/bench/franken/glm5/chunk_diag/gate_run.log ] && ~/bench/oracle_verdict.sh ~/bench/franken/glm5/chunk_diag/gate_run.log || echo "(no chunk_diag log)"
grep -aE "Memory access|HIP error|out of memory" ~/bench/franken/glm5/chunk_diag/gate_run.log 2>/dev/null | head -2 | cut -c1-160
echo "##### moeblk gate + timing"
grep -hE "^=== moeblk|^emb gate rc|GATE FAILED|^G=|^=== G=|exactness|not_exact|^c32s2|^c512s|^long512s" ~/bench/franken/glm5/moeblk/../../../glm_seq_next.log 2>/dev/null | head -40
ls ~/bench/franken/glm5/moeblk 2>/dev/null
[ -f ~/bench/franken/glm5/moeblk/emb_gate/gate_run.log ] && ~/bench/oracle_verdict.sh ~/bench/franken/glm5/moeblk/emb_gate/gate_run.log
for f in ~/bench/franken/glm5/moeblk/g*/gate_run.log; do [ -f "$f" ] && awk -v d="$(basename $(dirname $f))" '/^=== gate-plan config/ { c = $4 } /^prefill_tokens=/ { split($5, a, "="); printf "%-14s %s %8.3f ms/token = %6.1f tok/s\n", d, c, a[2], 1000 / a[2] }' "$f"; done
