#!/bin/bash
# pf_chain.sh -- run the batched prefill oracle + timings with the cards empty:
# stop the gateway (under run_chain's lock), run m5_bench, restart, accept_live.
set -u
HERE=~/src/colibri/tools/hot-expert
KEY=$(cat ~/.colibri_api_key); GLOG=~/glm53_server.log
engine_alive() { ps -C glm53 -o stat= 2>/dev/null | grep -qv '^Z'; }
wait_no_glm53() { for _ in $(seq 1 120); do engine_alive || return 0; sleep 2; done; echo "glm53 still alive after 240 s"; return 1; }
start_gateway() {
  env -u COLI_CKPT_DIR -u GLM53_PREFIX_CKPT SKIP_WARM=1 setsid nohup ~/start_glm53.sh >> "$GLOG" 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -H "Authorization: Bearer $KEY" -w '%{http_code}' http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && break
    sleep 5
  done
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(engine_alive && echo 1 || echo 0)"
}
stop_gateway() {
  pkill -f "openai_[s]erver.py" 2>/dev/null || true
  for _ in $(seq 1 10); do pgrep -f "openai_[s]erver.py" >/dev/null || break; sleep 1; done
  pkill -9 -f "openai_[s]erver.py" 2>/dev/null || true
  pkill -9 -x glm53 2>/dev/null || true
  wait_no_glm53
}
on_exit() {
  rc=$?; trap - EXIT INT TERM HUP
  if pgrep -f "openai_[s]erver.py" >/dev/null && engine_alive; then echo "gateway already in service"; else stop_gateway; start_gateway; fi
  echo "=== pf_chain exit rc=$rc $(date -Is)"
  "$HERE/accept_live.sh"; a=$?; echo "--- accept_live exit=$a"; [ "$rc" -eq 0 ] && rc=$a; exit "$rc"
}
trap on_exit EXIT INT TERM HUP
echo "=== pf_chain start $(date -Is)"
stop_gateway || exit 1
sleep 5
for d in /sys/class/drm/card[0-9]/device; do echo "vram_used_before=$(( $(cat $d/mem_info_vram_used) / 1048576 )) MiB"; done
O=~/bench/franken/bisect; mkdir -p $O
D() { B=$1; shift; docker run --rm --device /dev/kfd --device /dev/dri --group-add video --security-opt seccomp=unconfined --ipc=host -e LD_LIBRARY_PATH=/opt/rocm/lib:/home/ronald/src/llama-glm53/build-hip/bin -v /home/ronald:/home/ronald -w /home/ronald/src/colibri-m1/tools/hot-expert/franken/decode rocm/dev-ubuntu-24.04:7.14.0-full /home/ronald/bench/franken_bin/$B --model /home/ronald/models/Qwen3.8-Flash-Next/UD-IQ4_XS/Qwen3.8-Flash-Next-UD-IQ4_XS-00001-of-00003.gguf "$@" 2>&1; }
vram_wait() { for _ in $(seq 1 30); do m=0; for d in /sys/class/drm/card[0-9]/device; do u=$(( $(cat $d/mem_info_vram_used)/1048576 )); [ $u -gt $m ] && m=$u; done; [ $m -lt 1024 ] && return 0; sleep 2; done; echo "vram still $m MiB"; }
P="--tokens 1 --devices 3 --layers 0-47 --ctx 32768 --chunk 256 --gemm-lds 1 --time-prefill 32768"
for arm in perf1 hg0 hg0 perf1; do
  vram_wait
  case $arm in perf1) B=franken_decode.perf1; X="";; hg0) B=franken_decode.hg; X="--hip-graph 0";; esac
  echo "=== arm $arm $(date +%T)"; D $B $P $X | grep "prefill_ms_per\|HIP error\|fault"
done
vram_wait; echo "=== hg1 profile"; D franken_decode.hg $P --hip-graph 1 --profile | grep "prefill_ms_per\|prof_trunk\|prof_expert_gather\|prof_qsa_rows\|prof_total\|device" | cut -c1-100
vram_wait; echo "=== perf1 profile"; D franken_decode.perf1 $P --profile | grep "prefill_ms_per\|prof_trunk\|prof_expert_gather\|prof_qsa_rows\|prof_total\|device" | cut -c1-100
rc=0
for d in /sys/class/drm/card[0-9]/device; do echo "vram_used_after=$(( $(cat $d/mem_info_vram_used) / 1048576 )) MiB"; done
echo "=== franken_decode rc=$rc"
exit $rc
