#!/bin/bash
# RP4 chain: GPU-side timestamps on the expert group.
#
# Structure is p6b_chain.sh's, minus the serving-script patch: RP4 changes
# nothing about what is served (COLI_VK_TIMESTAMPS is off by default), so
# ~/start_glm53.sh is used unmodified on every exit path.
#
#   stop gateway -> merge p0-sync -> build (glm53 + both qwen38) -> smoke the
#   knob -> prefill_gate OFF (MIN_SPEEDUP=0.97) -> tworeq 4 slots at KDA=2 ->
#   prefill_gate ON (MIN_SPEEDUP=0.97, the "timestamps are cheap" gate) ->
#   the profile runs -> restart the gateway on the candidate if every gate
#   passed, on ~/bench/glm53.p6b (sha 53ccbb42…) if any did not.
set -u
TAG=rp4$(date +%m%d%H%M)
OUT=~/bench/rp4_chain_out; mkdir -p $OUT
# Prefix checkpoints OFF for every measured run, and into this chain's own
# directory when they are written at all. prefill_gate.sh runs the PRISTINE
# side first and the CANDIDATE second against ONE checkpoint store: with
# checkpoints on, the candidate RESTORES what the pristine just wrote and comes
# out "faster" because it went second (measured 2026-09-07: size 300 45.5 s ->
# 0.56 s on the candidate side, and the gate passed for that reason). This is
# the same trap p6b_gate.sh step 2 documents. RP4 changes no prefill path, so
# the honest comparison is with the feature off.
export GLM53_PREFIX_CKPT=0
export COLI_CKPT_DIR=$OUT/ckpt; mkdir -p $COLI_CKPT_DIR
SERVED=0
PREMERGE=""
PRISTINE=~/bench/glm53.p6b
PRISTINE_SHA=53ccbb42970ab3f141740083ff6d12896165ea656ef8aaeb68a082ddabdd46ec
HERE=~/src/colibri/tools/hot-expert

start_gateway() {
  # the chain's measurement env must NOT leak into the owner's service:
  # COLI_CKPT_DIR would move its checkpoint store into ~/bench, and
  # GLM53_PREFIX_CKPT=0 would only be overridden because start_glm53.sh
  # happens to set it -- unset both rather than rely on that.
  unset COLI_CKPT_DIR GLM53_PREFIX_CKPT
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}

wait_no_engine() {
  for _ in $(seq 1 180); do pgrep -x glm53 >/dev/null || return 0; sleep 1; done
  echo "REFUSED: a glm53 is still running: $(pgrep -x glm53 | tr '\n' ' ')"; return 1
}

revert_and_serve_pristine() {
  echo "--- REVERTING: ~/bench/glm53.p6b back in service"
  ~/bench/p7_stop.sh
  if [ -n "$PREMERGE" ]; then (cd ~/src/colibri && git reset --hard "$PREMERGE"); fi
  cp $PRISTINE ~/src/colibri/c/glm53 || echo "REVERT COPY FAILED"
  b=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
  if [ "$b" != "$PRISTINE_SHA" ]; then echo "REVERT FAILED: served binary is NOT the pristine one ($b)";
  else echo "revert verified: $b"; fi
  start_gateway
}

on_exit() {
  rc=$?
  if [ "$SERVED" != 1 ]; then
    echo "=== chain exiting rc=$rc without a served candidate"
    if ! pgrep -f "openai_[s]erver.py" >/dev/null; then revert_and_serve_pristine; fi
  fi
  echo "=== rp4 chain done $(date -Is)"
}
trap on_exit EXIT

echo "=== rp4 chain start $(date -Is) tag=$TAG"
sha256sum $PRISTINE ~/src/colibri/c/glm53
[ "$(sha256sum $PRISTINE | cut -d' ' -f1)" = "$PRISTINE_SHA" ] || { echo "PRISTINE SHA MISMATCH"; exit 2; }

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2

echo "--- merging p0-sync into hot-expert-tier"
cd ~/src/colibri || exit 2
git checkout hot-expert-tier || exit 2
PREMERGE=$(git rev-parse HEAD); echo "pre-merge HEAD $PREMERGE"
git merge --no-edit p0-sync || { echo "MERGE FAILED"; exit 2; }
git log --oneline -1

echo "--- building glm53 + qwen38 + qwen38-vk (backend_vulkan.c is shared)"
make -C c glm53 qwen38 qwen38-vk VK=1 2>&1 | grep -Ei "error|Error" | head -20
[ -x ~/src/colibri/c/glm53 ] || { echo "BUILD FAILED"; exit 2; }
sha256sum ~/src/colibri/c/glm53 ~/src/colibri/c/qwen38 ~/src/colibri/c/qwen38-vk
echo "--- the four qwen38 C tests"
for t in prefix config metrics serve_framing; do
  make -C c tests/test_qwen38_$t VK=1 >/dev/null 2>&1
  ./c/tests/test_qwen38_$t >/dev/null 2>&1; echo "  test_qwen38_$t exit=$?"
done

# --------------------------------------------------------------- prompts
python3 - > ~/bench/prefill_prompt_3000.txt <<'PY'
t = open("/home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md").read()
print("Summarise these notes in one sentence.\n\n" + t[:10500])
PY
python3 - > ~/bench/prefill_prompt_30.txt <<'PY'
print("Summarise these notes in one sentence.\n\nThe rig has three GPUs.")
PY
wc -c ~/bench/prefill_prompt_600.txt ~/bench/prefill_prompt_3000.txt

# --------------------------------------------------------------- smoke
echo
echo "### smoke — does the knob produce [VKTS] lines at all, and is it silent when off?"
SMOKE_OK=1
for lv in 0 1 2; do
  wait_no_engine || exit 2
  echo "--- smoke COLI_VK_TIMESTAMPS=$lv"
  COLI_VK_TIMESTAMPS=$lv COLI_KDA_GPU=2 \
    bash $HERE/prefill_profile.sh ~/src/colibri/c/glm53 ~/bench/prefill_prompt_30.txt "$TAG-smoke$lv" 128 \
    > $OUT/smoke_$lv.txt 2>&1
  r=$?
  n=$(grep -c '^\[VKTS' ~/bench/prefill_profile_$TAG-smoke$lv.log)
  echo "  rc=$r VKTS lines: $n"
  grep -E "^\[VKTS" ~/bench/prefill_profile_$TAG-smoke$lv.log | head -12
  tail -3 $OUT/smoke_$lv.txt
  [ "$r" = 0 ] || { echo "  SMOKE FAIL: run rc=$r"; SMOKE_OK=0; }
  if [ "$lv" = 0 ] && [ "$n" != 0 ]; then echo "  SMOKE FAIL: the knob is off and it printed anyway"; SMOKE_OK=0; fi
  if [ "$lv" != 0 ] && [ "$n" -lt 2 ]; then echo "  SMOKE FAIL: no [VKTS] output at level $lv"; SMOKE_OK=0; fi
done
if [ "$SMOKE_OK" != 1 ]; then
  echo "=== SMOKE FAILED -- not spending two hours on a broken instrument"
  revert_and_serve_pristine; exit 4
fi

# --------------------------------------------------------------- gate OFF
echo
echo "### gate 1 — prefill_gate.sh with the knob OFF (bit-identical, serve rows neutral)"
wait_no_engine || exit 2
MIN_SPEEDUP=0.97 bash $HERE/prefill_gate.sh $PRISTINE ~/src/colibri/c/glm53 $TAG-off 2>&1 | tee $OUT/gate_off.log
G_OFF=${PIPESTATUS[0]}; echo "GATE OFF rc=$G_OFF"

# --------------------------------------------------------------- tworeq
echo
echo "### gate 2 — tworeq TWOREQ_SLOTS=4 at COLI_KDA_GPU=2"
wait_no_engine || exit 2
env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close \
    COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto \
    COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695 \
    COLI_VK_SHADERS=~/src/colibri/c/shaders COLI_USAGE_PATH=$OUT/hist.bin \
    COLI_KDA_GPU=2 TWOREQ_SLOTS=4 TWOREQ_EXE=~/src/colibri/c/glm53 GLM53_VERBOSE=1 \
    python3 $HERE/tworeq.py > $OUT/tworeq.txt 2>&1
TWOREQ=$?
echo "tworeq: $(grep '^RESULT:' $OUT/tworeq.txt || echo 'NO RESULT') (rc=$TWOREQ)"
echo "  forcing lines: $(grep -c 'forcing COLI_KDA_GPU=0' $OUT/tworeq.txt)"

# --------------------------------------------------------------- gate ON
echo
echo "### gate 3 — prefill_gate.sh with COLI_VK_TIMESTAMPS=1 (oracle identical, TTFT within 3 %)"
wait_no_engine || exit 2
COLI_VK_TIMESTAMPS=1 MIN_SPEEDUP=0.97 \
  bash $HERE/prefill_gate.sh $PRISTINE ~/src/colibri/c/glm53 $TAG-on 2>&1 | tee $OUT/gate_on.log
G_ON=${PIPESTATUS[0]}; echo "GATE ON rc=$G_ON"

# --------------------------------------------------------------- profiles
echo
echo "### RP4 profile — serving knob (COLI_KDA_GPU=2), cap 512, chunk 128, GLM53_PREFIX_CKPT=0"
for p in 600 3000; do
  for r in 1 2 3; do
    wait_no_engine || exit 2
    echo "--- profile lvl1 prompt=$p repeat=$r"
    COLI_VK_TIMESTAMPS=1 COLI_KDA_GPU=2 \
      bash $HERE/prefill_profile.sh ~/src/colibri/c/glm53 ~/bench/prefill_prompt_$p.txt "$TAG-p${p}r$r" 128 \
      2>&1 | tee $OUT/prof_${p}_lvl1_$r.txt | tail -40
  done
done
for p in 600 3000; do
  wait_no_engine || exit 2
  echo "--- profile lvl2 (per-expert, dispatches serialized) prompt=$p"
  COLI_VK_TIMESTAMPS=2 COLI_KDA_GPU=2 \
    bash $HERE/prefill_profile.sh ~/src/colibri/c/glm53 ~/bench/prefill_prompt_$p.txt "$TAG-q$p" 128 \
    2>&1 | tee $OUT/prof_${p}_lvl2.txt | tail -50
done

# --------------------------------------------------------------- verdict
echo
echo "=== RP4 verdict: gate OFF rc=$G_OFF, tworeq rc=$TWOREQ, gate ON rc=$G_ON"
wait_no_engine || exit 2
if [ "$G_OFF" = 0 ] && [ "$TWOREQ" = 0 ] && [ "$G_ON" = 0 ]; then
  SERVED=1
  echo "=== RP4 IN SERVICE: $(sha256sum ~/src/colibri/c/glm53 | cut -c1-16), unchanged serving script"
  start_gateway
  ~/bench/owui_report.sh 4
else
  echo "=== A GATE FAILED -- reverting to the pristine p6b binary"
  revert_and_serve_pristine
  exit 3
fi
