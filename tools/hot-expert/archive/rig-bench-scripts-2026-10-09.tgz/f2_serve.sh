#!/bin/bash
# f2_serve.sh -- put the gated F2 binary (clamp + streamed prefill, chunk 512) in service.
set -u
T=$HOME/src/colibri-f2/tools/hot-expert
M=$HOME/models/GLM-5.3-Flash-colibri-int4-g64
CAND=$HOME/bench/glm53.f2; PRIS=$HOME/bench/glm53.f2base
. "$T/rig_lock.sh"
rig_lock_take "f2_serve" || exit 3
trap 'rig_lock_release' EXIT INT TERM
echo "=== f2_serve $(date -u -Is)"
cp -p $HOME/src/colibri-f2/c/glm53 $CAND || exit 4
sha256sum $CAND $PRIS | cut -c1-16,65-
# additive shaders (the unclamped ones are byte-identical; the pristine never binds these)
cp -p $HOME/src/colibri-f2/c/shaders/qmatmul_gate_up_clamp.spv $HOME/src/colibri-f2/c/shaders/qmatmul_gate_up_tile_clamp.spv $HOME/src/colibri/c/shaders/ || exit 4
# serving script: new inode, never edit the running file in place
S=$HOME/start_glm53.sh
cp -p $S $HOME/bench/start_glm53.sh.pre-f2
if ! grep -q COLI_PREFILL_STREAM $S; then
  awk '/^export COLI_PREFIX_PIN=1/ { print; print "# F2 (2026-09-19): the swiglu clamp on the GPU routed-expert kernels (the fix for the placement-dependent"; print "# output, record F2 step 2a), non-resident experts streamed to the cards in prefill, prefill chunk 512."; print "# Gate: turn 1 2.03x, 18k turn 1.75x, KL 3.5e-05 / top-1 99.89 % stream on vs off under the clamp."; print "export GLM53_VK_SWIGLU_CLAMP=1 COLI_PREFILL_STREAM=1 GLM53_PREFILL_CHUNK=512"; next } { print }' $S > $S.new && chmod +x $S.new && bash -n $S.new && mv -f $S.new $S || exit 5
fi
grep -n "SWIGLU_CLAMP" $S || exit 5
# prefix checkpoints were computed with the unclamped kernels: set them aside, the candidate recaptures
if [ -d $M/.coli_ckpt ]; then mv $M/.coli_ckpt $M/.coli_ckpt.pre-f2.$(date -u +%m%d%H%M) && mkdir $M/.coli_ckpt; fi
"$T/serve_candidate.sh" $CAND $PRIS
rc=$?
echo "=== serve_candidate rc=$rc $(date -u -Is)"
if [ $rc -ne 0 ]; then mv -f $HOME/bench/start_glm53.sh.pre-f2 $S.revert && mv -f $S.revert $S; echo "start script reverted (takes effect at the next restart; the pristine ignores the F2 env)"; fi
grep -a "SWIGLU\|STREAM\|clamp" $HOME/glm53_server.log | head -8
ls -la $M/.coli_ckpt | tail -6
exit $rc
