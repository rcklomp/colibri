#!/bin/bash
echo "##### needle run of the installed build (old build: 8/8 at 30k 293 s, 60k 589 s, 120k 1311 s, 200k 2190 s)"
grep -aE "needle:depth" ~/bench/franken_quality/chain_needle_new.log 2>/dev/null | cut -c1-120
grep -aE "total wall|needle depths|depth +[0-9]" ~/bench/franken_quality/chain_needle_new.log 2>/dev/null | tail -6 | cut -c1-140
echo "##### verify-cost probe"
~/bench/vc_report.sh 2>&1 | head -24
