#!/bin/bash
# Reproduce one runaway DeepSeek answer on the Franken engine (mmlu:570) and keep the full text.
set -u
H=~/src/colibri/tools/hot-expert; O=~/bench/franken_quality/repro570; mkdir -p $O
export FRANKEN_BIN=$HOME/bench/franken_decode_ds4_docker.sh
on_exit() { rc=$?; trap - EXIT; echo "=== restoring GLM rc=$rc $(date -Is)"; $H/serve_alt.sh glm 2>&1 | tail -2; echo "=== repro570 done $(date -Is)"; }
trap on_exit EXIT
echo "=== serve franken-ds4 $(date -Is)"
$H/serve_alt.sh franken-ds4 2>&1 | grep "now serving\|FATAL" || { echo "FATAL: no serve"; exit 1; }
python3 - <<PY
import json, sys, time, urllib.request, os
sys.path.insert(0, os.path.expanduser("~/src/colibri/tools/hot-expert"))
import quality_eval as q
items = json.load(open(os.path.expanduser("~/bench/f11_quality/mmlu_pro_sample.json")))
items = items["items"] if isinstance(items, dict) else items
it = next(i for i in items if int(i.get("question_id", -1)) == 570)
prompt = q.mmlu_prompt(it)
key = open(os.path.expanduser("~/.colibri_api_key")).read().strip()
t = time.time()

os.environ["QE_REASONING_EFFORT"] = "xhigh"
r = q.send_chat("http://127.0.0.1:8081", key, "glm-5.3-flash", prompt, 16000)
d = r.get("data") or {}
ch = (d.get("choices") or [{}])[0]; msg = ch.get("message", {})
out = {"wall_s": time.time()-t, "finish": ch.get("finish_reason"), "usage": d.get("usage"),
       "reasoning": msg.get("reasoning_content") or "", "content": msg.get("content") or ""}
json.dump(out, open(os.path.expanduser("~/bench/franken_quality/repro570/out.json"), "w"))
rs = out["reasoning"]; print("finish", out["finish"], "usage", out["usage"], "reasoning chars", len(rs), "content chars", len(out["content"]))
print("--- reasoning tail ---"); print(rs[-1500:])
PY
