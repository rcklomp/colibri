#!/bin/bash
# pftl_cpu_check.sh <part 1|2> -- CPU-arm checks of the pf-timeline branch (GLM5.md 14): --timeline
# on vs off is bit-identical, and the timeline file is written and readable. No GPU. Refuses while
# the rig lock is held by a live process. Each part < 5 min, nice 19, 4 threads.
set -u
if [ -d ~/bench/.rig.lock ]; then
  pid=$(awk '{print $2}' ~/bench/.rig.lock/owner 2>/dev/null)
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && { echo "REFUSED: rig lock held by $(cat ~/bench/.rig.lock/owner)"; exit 3; }
fi
W=/home/ronald/src/franken-engine-pftl/franken/decode
N=$W/franken_decode_glm_cpu
M=/home/ronald/models/GLM-5.3-Flash/UD-IQ4_XS/GLM-5.3-Flash-UD-IQ4_XS-00001-of-00005.gguf
S5=/home/ronald/bench/franken/glm5/s5
O=/home/ronald/bench/franken/glm5/pftl_cpu
T6="154822 785 6722 315 9621 374"
T136=/home/ronald/bench/franken/glm5/t136.txt
mkdir -p $O
COMMON="--model $M --cpu --devices 3 --split 2,4 --layers 0-4 --no-head --ctx 4096 --threads 4 --placement /home/ronald/bench/m2/glm --expert-gb 0.3"
verdict() { awk '/^=== gate-plan config/{f=$4} /^oracle .* cos=/{n[f]++; if ($0 !~ /cos=1.000000 maxabs=0 /) b[f]++} /GLM5 CPU ORACLE/{r[f]=$4} END{for (k in n) printf "  %-8s taps=%d not_bitexact=%d oracle=%s\n", k, n[k], b[k]+0, r[k]}' $1 | sort; grep -E "gate_plan_summary|^glm5_timeline" $1; }
if [ "${1:-1}" = 1 ]; then
  # 6 tokens in chunks of 2 on three "devices" (three-link, helpers computing missed experts):
  # timeline off dumps, timeline on (all 3 chunks) is held to that dump bit for bit
  cat > $O/p1_plan.txt <<PLAN
a6  --tokens $T6 --adapt 0 --chunk 2 --dump $O/a6
t6  --tokens $T6 --adapt 0 --chunk 2 --timeline $O/t6.csv --timeline-skip 0 --timeline-chunks 3 --oracle $O/a6
PLAN
  timeout 300 nice -n 19 $N $COMMON --gate-plan $O/p1_plan.txt > $O/p1.log 2>&1; echo "part 1 rc=$?"
  verdict $O/p1.log
  python3 -I $W/glm5_timeline.py $O/t6.csv --tokens 2 > $O/t6_report.txt 2>&1; echo "glm5_timeline.py rc=$?"
  head -12 $O/t6_report.txt
else
  # 136 tokens in chunks of 32 with --timeline (chunks 1-3) against the pre-change token-by-token
  # dump (s5/base136, the CPU gates' reference since GLM step 5)
  cat > $O/p2_plan.txt <<PLAN
c32tl --tokens-file $T136 --oracle $S5/base136 --adapt 0 --chunk 32 --timeline $O/c32.csv --timeline-skip 1 --timeline-chunks 3
PLAN
  timeout 300 nice -n 19 $N $COMMON --gate-plan $O/p2_plan.txt > $O/p2.log 2>&1; echo "part 2 rc=$?"
  verdict $O/p2.log
  python3 -I $W/glm5_timeline.py $O/c32.csv --tokens 32 > $O/c32_report.txt 2>&1; echo "glm5_timeline.py rc=$?"
  grep -c . $O/c32.csv
fi
