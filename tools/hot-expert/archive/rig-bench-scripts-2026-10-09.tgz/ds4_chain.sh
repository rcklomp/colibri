#!/bin/bash
# ds4_chain.sh -- run the M5 launch/sync-floor microbenchmark with the cards empty:
# stop the gateway (under run_chain's lock), run m5_bench, restart, accept_live.
set -u
HERE=~/src/colibri/tools/hot-expert
KEY=$(cat ~/.colibri_api_key); GLOG=~/glm53_server.log
engine_alive() { ps -C glm53 -o stat= 2>/dev/null | grep -qv '^Z'; }
wait_no_glm53() { for _ in $(seq 1 120); do engine_alive || return 0; sleep 2; done; echo "glm53 still alive after 240 s"; return 1; }
start_gateway() {
  env -u COLI_CKPT_DIR -u GLM53_PREFIX_CKPT SKIP_WARM=1 setsid nohup ~/start_glm53.sh >> "$GLOG" 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -H "Authorization: Bearer $KEY" -w '%{http_code}' http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && break
    sleep 5
  done
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(engine_alive && echo 1 || echo 0)"
}
stop_gateway() {
  pkill -f "openai_[s]erver.py" 2>/dev/null || true
  for _ in $(seq 1 10); do pgrep -f "openai_[s]erver.py" >/dev/null || break; sleep 1; done
  pkill -9 -f "openai_[s]erver.py" 2>/dev/null || true
  pkill -9 -x glm53 2>/dev/null || true
  wait_no_glm53
}
on_exit() {
  rc=$?; trap - EXIT INT TERM HUP
  if pgrep -f "openai_[s]erver.py" >/dev/null && engine_alive; then echo "gateway already in service"; else stop_gateway; start_gateway; fi
  echo "=== ds4_chain exit rc=$rc $(date -Is)"
  "$HERE/accept_live.sh"; a=$?; echo "--- accept_live exit=$a"; [ "$rc" -eq 0 ] && rc=$a; exit "$rc"
}
trap on_exit EXIT INT TERM HUP
echo "=== ds4_chain start $(date -Is)"
stop_gateway || exit 1
sleep 5
for d in /sys/class/drm/card[0-9]/device; do echo "vram_used_before=$(( $(cat $d/mem_info_vram_used) / 1048576 )) MiB"; done
vram_wait() { for _ in $(seq 1 60); do m=0; for d in /sys/class/drm/card[0-9]/device; do u=$(( $(cat $d/mem_info_vram_used)/1048576 )); [ $u -gt $m ] && m=$u; done; [ $m -lt 1024 ] && return 0; sleep 2; done; echo "vram still $m MiB"; }
O=/home/ronald/bench/franken/ds4; mkdir -p $O; 
W=/home/ronald/src/colibri-m1/tools/hot-expert/franken/decode
DK() { docker run --rm "$@"; }
IMG=rocm/dev-ubuntu-24.04:7.14.0-full
LIB="-e LD_LIBRARY_PATH=/opt/rocm/lib:/home/ronald/src/llama-glm53/build-hip/bin"
GPU="--device /dev/kfd --device /dev/dri --group-add video --security-opt seccomp=unconfined --ipc=host"
M=/home/ronald/models/DeepSeek-V4-Flash-0731-UD-IQ2_M/UD-IQ2_M/DeepSeek-V4-Flash-0731-UD-IQ2_M-00001-of-00003.gguf
T="0 671 6102 294 8760 344"; P=/home/ronald/bench/m2/deepseek_b60
F() { grep "^oracle \|STEP2\|greedy\|summary\|HIP error\|fault\|layers0\|issue_ms\|vram_dev" | grep -v "maxabs=0 \|INCOMPARABLE\|contained=1.000000" | head -14; }
echo skip-sync; : DK $GPU $LIB -v /home/ronald:/home/ronald -w $W $IMG ./franken_decode_ds4 --model $M --tokens $T --ctx 512 --placement $P --expert-gb 20 --greedy 16 --oracle $O/cpu_l042 --sync-debug 2>&1 | tee $O/gpu_sync.txt | F
vram_wait; echo "=== gpu vs cpu"; DK $GPU $LIB -v /home/ronald:/home/ronald -w $W $IMG ./franken_decode_ds4 --model $M --tokens $T --ctx 512 --placement $P --expert-gb 20 --greedy 16 --oracle $O/cpu_l042 2>&1 | tee $O/gpu.txt | F
vram_wait; echo "=== timing 256k alloc"; DK $GPU $LIB -v /home/ronald:/home/ronald -w $W $IMG ./franken_decode_ds4 --model $M --tokens $T --ctx 262144 --placement $P --expert-gb 20 --greedy 16 --time 32 2>&1 | tee $O/time.txt | F
rc=0
echo "=== ds4 rc=$rc"
exit $rc
