#!/bin/bash
# accept_locked.sh -- run accept_live.sh against the live gateway while HOLDING the rig lock,
# so no chain restarts the gateway underneath it (two unlocked runs collided on 2026-09-16).
set -u
. ~/src/colibri/tools/hot-expert/rig_lock.sh
rig_lock_take accept_locked || exit 3
trap rig_lock_release EXIT INT TERM
~/src/colibri/tools/hot-expert/accept_live.sh; rc=$?
echo "=== accept_locked rc=$rc $(date -Is)"; exit $rc
