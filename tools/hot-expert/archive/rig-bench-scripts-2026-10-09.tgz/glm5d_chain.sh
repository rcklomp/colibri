#!/bin/bash
# glm5d_chain.sh -- the GLM GPU gate (glm5_gpu_gate.sh all, 33 configurations, GLM5.md 11.6 + 12.6) with the cards empty:
# stop the gateway (under run_chain lock), run the gate into gpu6/, restart, accept_live.
set -u
HERE=~/src/colibri/tools/hot-expert
KEY=$(cat ~/.colibri_api_key); GLOG=~/glm53_server.log
engine_alive() { ps -C glm53 -o stat= 2>/dev/null | grep -qv '^Z'; }
wait_no_glm53() { for _ in $(seq 1 120); do engine_alive || return 0; sleep 2; done; echo "glm53 still alive after 240 s"; return 1; }
start_gateway() {
  env -u COLI_CKPT_DIR -u GLM53_PREFIX_CKPT SKIP_WARM=1 setsid nohup ~/start_glm53.sh >> "$GLOG" 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -H "Authorization: Bearer $KEY" -w '%{http_code}' http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && break
    sleep 5
  done
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(engine_alive && echo 1 || echo 0)"
}
stop_gateway() {
  pkill -f "openai_[s]erver.py" 2>/dev/null || true
  for _ in $(seq 1 10); do pgrep -f "openai_[s]erver.py" >/dev/null || break; sleep 1; done
  pkill -9 -f "openai_[s]erver.py" 2>/dev/null || true
  pkill -9 -x glm53 2>/dev/null || true
  wait_no_glm53
}
on_exit() {
  rc=$?; trap - EXIT INT TERM HUP
  if [ -e "$HOME/bench/.dev_reserved" ]; then echo "rig reserved for development: gateway left down"
  elif pgrep -f "openai_[s]erver.py" >/dev/null && engine_alive; then echo "gateway already in service"; else stop_gateway; start_gateway; fi
  echo "=== glm5d_chain exit rc=$rc $(date -Is)"
  "$HERE/accept_live.sh"; a=$?; echo "--- accept_live exit=$a"; [ "$rc" -eq 0 ] && rc=$a; exit "$rc"
}
trap on_exit EXIT INT TERM HUP
mkdir -p ~/bench/franken/glm5/gpu7
echo "=== glm5d_chain start $(date -Is)"
stop_gateway || exit 1
sleep 5
for d in /sys/class/drm/card[0-9]/device; do echo "vram_used_before=$(( $(cat $d/mem_info_vram_used) / 1048576 )) MiB"; done
docker run --rm --device /dev/kfd --device /dev/dri --group-add video --security-opt seccomp=unconfined --ipc=host --ulimit memlock=-1 -e LD_LIBRARY_PATH=/opt/rocm/lib:/home/ronald/src/llama-glm53/build-hip/bin -e HOME=/home/ronald -v /home/ronald:/home/ronald -w /home/ronald/src/franken-engine/franken/decode rocm/dev-ubuntu-24.04:7.14.0-full ./franken_decode_glm --model /home/ronald/models/GLM-5.3-Flash/UD-IQ4_XS/GLM-5.3-Flash-UD-IQ4_XS-00001-of-00005.gguf --placement /home/ronald/bench/m2/glm --expert-gb 17 --gate-plan /home/ronald/bench/franken/glm5/gpu7/plan.txt > ~/bench/franken/glm5/gpu7/gate_run.log 2>&1; rc=$?
echo "=== glm5d run rc=$rc"
exit $rc
