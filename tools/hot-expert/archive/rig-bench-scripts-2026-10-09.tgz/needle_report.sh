#!/bin/bash
# what the long-context needle run of the installed build has produced
L=~/bench/franken_quality/chain_needle_new.log
grep -aE "^=== |now serving|FATAL|\[needle\]|\[identity\]|needle:depth|total wall|needle depths|depth +[0-9]|accept_live|chunk=" "$L" 2>/dev/null | cut -c1-230 | tail -40
echo "--- engine start line:"; grep -a "^\[start\]" ~/bench/serve_alt_franken_glm.log 2>/dev/null | tail -1 | cut -c1-200
