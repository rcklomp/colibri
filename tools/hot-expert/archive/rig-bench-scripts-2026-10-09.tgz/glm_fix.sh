pkill -f run_glm_bisect.sh; pkill -f run_steady.sh; pkill -9 -f datapoint.py; pkill -9 -x glm53; pkill -9 -x qwen38; pkill -9 -x qwen38-vk; sleep 3
uptime; free -g | head -2
cd /home/ronald/src/colibri/c
G=/home/ronald/models/GLM-5.3-Flash-colibri-int4-g64
P="$(cat ~/bench/prompt_glm.txt)"
echo "[$(date +%H:%M:%S)] warm GLM"; cat $G/*.safetensors > /dev/null
fincore --bytes --noheadings $G/*.safetensors | awk '{r+=$1} END {printf "resident %.1f GiB\n", r/2^30}'
VK="COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_EXPERTS2=1695 COLI_VK_DEV3=auto COLI_VK_EXPERTS3=1695 COLI_VK_SHADERS=shaders COLI_USAGE_PATH=/home/ronald/.glm53_explain.bin"
for th in 8 16; do
  echo "[$(date +%H:%M:%S)] HEAD glm53, 3 GPUs, OMP_NUM_THREADS=$th"
  env $VK OMP_NUM_THREADS=$th OMP_PLACES=cores OMP_PROC_BIND=close /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_fix_t$th.log 2>&1; echo "rc=$?"
  grep -E "preload:|decode |Major" ~/bench/glm_fix_t$th.log | cut -c1-120
done
echo "[$(date +%H:%M:%S)] glm fix test done"
