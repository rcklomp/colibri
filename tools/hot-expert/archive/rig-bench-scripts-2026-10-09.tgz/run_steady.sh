#!/usr/bin/env bash
cd /home/ronald/src/colibri
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "pristine worktree build at 2d3cf7e"
[ -d /tmp/wt-pristine ] || git worktree add -q /tmp/wt-pristine 2d3cf7e
( cd /tmp/wt-pristine/c && make qwen38 qwen38-vk VK=1 2>&1 | grep -E "error" ; ls -la qwen38 qwen38-vk )
cd c
S=/home/ronald/src/colibri/c/shaders
VK="Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS=$S"
camp(){ name=$1; eng=$2; shift 2; log "campaign $name ($eng)"; env "$@" python3 tools/datapoint.py --snap $M --engine $eng --cap 512 --max-new 80 --warm-runs 2 --rotating-runs 2 > ~/bench/steady_$name.log 2>&1; echo "rc=$?"; grep -iE "cold|warm|rotating|tok/s|hit|load" ~/bench/steady_$name.log | grep -vE "^\[datapoint\] (rotating prompt|warm run)" | tail -25; }
camp pristine_cpu16 /tmp/wt-pristine/c/qwen38 X=1
camp patched_cpu16 /home/ronald/src/colibri/c/qwen38 X=1
camp pristine_vk16 /tmp/wt-pristine/c/qwen38-vk $VK
camp patched_vk16 /home/ronald/src/colibri/c/qwen38-vk $VK


log "steady done"
