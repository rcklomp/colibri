#!/bin/bash
# Runs detached on the rig so an SSH disconnect can't kill it mid-sequence.
# Holds the real rig lock (via the project's own rig_lock.sh, which handles
# stale-lock detection correctly) for the whole stop -> swap -> restart ->
# verify sequence, and only releases it once the gateway is confirmed healthy
# or the sequence gives up.
set -u
LOG=/home/ronald/bench/ledger_fix_deploy.log
exec > "$LOG" 2>&1
echo "=== deploy started $(date) ==="

source /home/ronald/src/colibri/tools/hot-expert/rig_lock.sh
if ! rig_lock_take "ledger-fix-deploy-final"; then
  echo "LOCK REFUSED"
  rig_lock_holder
  exit 3
fi
trap 'rig_lock_release; echo "=== deploy ended $(date), lock released ==="' EXIT
echo "LOCK TAKEN, pid=$$"

echo "--- stopping any existing gateway/engine ---"
pkill -TERM -f "openai_[s]erver.py"
sleep 3
pkill -9 -x glm53
sleep 2

echo "--- waiting for clean state ---"
for i in 1 2 3 4 5 6 7 8 9 10; do
  ALIVE_GW=$(pgrep -af "openai_[s]erver.py")
  ALIVE_ENG=$(pgrep -x glm53)
  PORTBOUND=$(ss -tlnp 2>/dev/null | grep 8081)
  if [ -z "$ALIVE_GW" ] && [ -z "$ALIVE_ENG" ] && [ -z "$PORTBOUND" ]; then
    echo "confirmed clean after ${i} checks"
    break
  fi
  echo "settling ($i): gw=[$ALIVE_GW] eng=[$ALIVE_ENG] port=[$PORTBOUND]"
  sleep 2
done

echo "--- applying the fix ---"
if [ -f /home/ronald/src/colibri/c/openai_server.py.fix2 ]; then
  mv /home/ronald/src/colibri/c/openai_server.py.fix2 /home/ronald/src/colibri/c/openai_server.py
  echo "moved fix2 into place"
elif grep -q "Canonical signature of the assistant" /home/ronald/src/colibri/c/openai_server.py; then
  echo "fix already in place"
else
  echo "ERROR: neither fix2 staged file nor fix content found -- aborting without restarting"
  exit 4
fi

python3 -m py_compile /home/ronald/src/colibri/c/openai_server.py
echo "compiles OK"
echo "fix present: $(grep -c 'Canonical signature of the assistant' /home/ronald/src/colibri/c/openai_server.py)"
echo "diagnostic present: $(grep -c 'ledger-diag' /home/ronald/src/colibri/c/openai_server.py)"

echo "--- restarting ---"
cd /home/ronald
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
disown

echo "--- polling for readiness ---"
READY=0
for i in $(seq 1 50); do
  if grep -q "OpenAI-compatible API listening" ~/glm53_server.log 2>/dev/null; then
    echo "READY after ~$((i*3))s"
    READY=1
    break
  fi
  sleep 3
done

if [ "$READY" != "1" ]; then
  echo "FAILED to come up within timeout"
  tail -30 ~/glm53_server.log
  exit 5
fi

sleep 3
echo "--- final health check ---"
ps aux | grep -E "openai_server|glm53" | grep -v grep
ss -tlnp 2>/dev/null | grep 8081
KEY=$(cat ~/.colibri_api_key)
curl -s -m 8 -H "Authorization: Bearer $KEY" http://127.0.0.1:8081/v1/models
echo ""
unset KEY
echo "=== deploy sequence complete, healthy ==="
