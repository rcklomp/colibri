#!/bin/bash
# Q7 steps 2 and 3 (QSA projections, LM head) -- one chain, one lock, one
# gateway stop. Spec tools/hot-expert/Q7-DENSE-GPU-SPEC-2026-09-12.md; the gate
# is Fable's corrected one in record §Q7 `### Arbitration`.
#
# Order, which is the spec's: step 0 FIRST (and by the corrected rule -- the
# gap replay, not back-to-back), then the knob-off identity, then the oracle and
# the [OPTIME] A/B per step.
#
# The pristine is the a19b938 rebuild (merge criterion 3), not the 313f1f5
# q7base every step-1 number was taken against.
set -u
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q7-s23" 120 || exit 3

for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
stop_gateway || exit 1

log "tree: $(git -C $WT log --oneline -1)"
q7_build_engines || { log "build failed"; exit 1; }

# ---- step 0 for steps 2 and 3: the gap replay --------------------------------
gcc -O2 -march=native -fopenmp -I"$WT/c" -o /tmp/q7_vkbench \
    "$WT/tools/hot-expert/rome_vkbench.c" "$WT/c/backend_vulkan.o" -lvulkan -lm \
  || { log "vkbench build failed"; exit 1; }
log "--- rome_vkbench q7s23 (head shape check + QSA/head gap replays, 5 repeats each)"
/tmp/q7_vkbench "$WT/c/shaders/qmatmul.spv" q7s23 2>&1 | tee "$OUT/vkbench-q7s23.log"

# ---- the engine legs ---------------------------------------------------------
export Q7_PARENT_LOCK=$$
export PRIS=/home/ronald/bench/qwen38-vk.q7base2
export PRIS_SH=/home/ronald/bench/shaders_q7base2
for ph in base step2 step3; do
  log "=== q7_probe.sh $ph"
  "$WT/tools/hot-expert/q7_probe.sh" "$ph" || { log "probe $ph FAILED"; exit 1; }
done
log "steps 2-3 measured"
