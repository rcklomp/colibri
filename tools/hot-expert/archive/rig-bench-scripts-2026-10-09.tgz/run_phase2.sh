#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
G=/home/ronald/models/GLM-5.3-Flash-colibri-int4-g64
P="$(cat ~/bench/prompt1.txt)"
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "Qwen VK baseline (3 GPUs, cap=512, 128 tokens)"
SNAP=$M N_NEW=128 NOSTREAM=1 COLI_TIMERS=1 Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS=shaders \
  COLI_USAGE=/home/ronald/bench/q38_usage_vk.bin /usr/bin/time -v ./qwen38-vk 512 8 ~/bench/prompt1.txt > ~/bench/q38_vk_cap512.log 2>&1
echo "rc=$?"; grep -E 'Speed|TTFT|hit rate|PEAK|timers\]   |Vulkan|page faults|Text' ~/bench/q38_vk_cap512.log
log "Qwen CPU perf profile (cap=512, 32 tokens)"
SNAP=$M N_NEW=32 NOSTREAM=1 COLI_TIMERS=1 perf record -F 299 -e cycles -o ~/bench/q38_cpu.perf.data ./qwen38 512 8 ~/bench/prompt1.txt > ~/bench/q38_cpu_perf.log 2>&1
echo "rc=$?"; grep -E 'Speed|routed-expert|resident-mm|deltanet' ~/bench/q38_cpu_perf.log
perf report -i ~/bench/q38_cpu.perf.data --no-children --percent-limit 0.7 --stdio 2>/dev/null | grep -vE '^#|^$' | head -45 > ~/bench/q38_cpu_perf.txt
log "GLM GPU baseline (3 GPUs, heat preload, 64 tokens)"
COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_EXPERTS2=100000 COLI_VK_DEV3=auto COLI_VK_EXPERTS3=100000 COLI_VK_SHADERS=shaders \
  COLI_USAGE_PATH=/home/ronald/.glm53_usage.bin GLM53_VERBOSE=1 /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 64 > ~/bench/glm_gpu.log 2>&1
echo "rc=$?"; grep -E 'decode|teacher|VK\]|Vulkan|experts hits|caricamento|Elapsed|page faults|denso' ~/bench/glm_gpu.log | cut -c1-200
log "GLM CPU-only (12 tokens, oracle)"
GLM53_VERBOSE=1 /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 12 > ~/bench/glm_cpu.log 2>&1
echo "rc=$?"; grep -E 'decode|teacher|experts hits|caricamento|Elapsed' ~/bench/glm_cpu.log | cut -c1-200
log "phase2 done"
