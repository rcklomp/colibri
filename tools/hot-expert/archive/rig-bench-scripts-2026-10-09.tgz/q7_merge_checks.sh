#!/bin/bash
# Q7 arm: the non-benchmark merge criteria (Fable, record §Q7 `### Arbitration`).
#   (2) tworeq.py for qwen38 -- three identical requests in ONE persistent
#       engine, knob ON, byte-identical; plus a knob-off control so the new
#       parametrisation is shown to work rather than asserted.
#   (4) the six C tests (four qwen38 + two glm53).
#   (5) the OTHER engine: glm53's binary, which steps 2-3 must not have moved.
# Short: one engine at a time, the lock held, the gateway down only while an
# engine runs.
set -u
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q7-merge-checks" 120 || exit 3
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done

QSNAP=/home/ronald/models/Qwen3.8-Flash-Next-FP8
LOGD=~/bench/q7_merge_out; mkdir -p "$LOGD"

# ---- (5) the other engine: glm53 must be byte-identical to step 1's -----------
# Steps 2 and 3 touch c/qwen38_core.h only; the shared files (qmatmul.comp,
# backend_vulkan.c) are step 0's and were glm-checked there. Prove it with the
# binary, not with the diff: build glm53 at step 1's tip and compare sha256.
log "--- glm53 binary identity: step-1 tip (90e1f21) vs this candidate"
rm -rf /tmp/q7s1tree
git -C /home/ronald/src/colibri worktree add --detach /tmp/q7s1tree 90e1f21 >/dev/null 2>&1
make -C /tmp/q7s1tree/c glm53 VK=1 -j8 > /tmp/q7s1_build.log 2>&1 \
  && sha256sum /tmp/q7s1tree/c/glm53 "$WT/c/glm53" | tee "$LOGD/glm53_sha.txt" \
  || { log "glm53 step-1 build failed"; tail -10 /tmp/q7s1_build.log; }

# ---- (4) the six tests -------------------------------------------------------
log "--- the six C tests"
: > "$LOGD/tests.txt"
for t in test_qwen38_prefix test_qwen38_config test_qwen38_metrics test_qwen38_serve_framing \
         test_glm53_cancel_frames test_glm53_ckpt_touch; do
  if make -C "$WT/c" "tests/$t" VK=1 > "/tmp/q7t_$t.build.log" 2>&1; then
    if "$WT/c/tests/$t" > "/tmp/q7t_$t.log" 2>&1; then r="exit 0"; else r="exit $? -- FAIL"; fi
  else r="BUILD FAILED"
  fi
  echo "$t: $r" | tee -a "$LOGD/tests.txt"
done

# ---- (2) tworeq.py for qwen38 ------------------------------------------------
stop_gateway || exit 1
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
export Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto
export COLI_VK_SHADERS="$WT/c/shaders"
export TWOREQ_ARCH=qwen38 TWOREQ_SNAP="$QSNAP" TWOREQ_EXE="$WT/c/qwen38-vk"
for leg in off on; do
  cp -f "$QSNAP/.coli_usage" /tmp/q7_tworeq_hist_$leg.bin
  if [ "$leg" = on ]; then export Q38_DENSE_GPU=7; else unset Q38_DENSE_GPU; fi
  log "--- tworeq qwen38, knob $leg"
  COLI_USAGE=/tmp/q7_tworeq_hist_$leg.bin \
    python3 "$WT/tools/hot-expert/tworeq.py" > "$LOGD/tworeq_$leg.log" 2>&1
  log "  rc=$? -> $(grep '^RESULT:' "$LOGD/tworeq_$leg.log" || echo 'NO RESULT LINE')"
  wait_no_engine qwen38-vk || exit 1
done
log "merge checks done; see $LOGD"
