#!/bin/bash
# Oracle + order-controlled A/B for the KDA parallelisation, on UPSTREAM dev.
set -u
M="$HOME/models/GLM-5.3-Flash-colibri-int4-g64"
P="$HOME/bench/hc_pristine/c/glm53"; Q="$HOME/bench/kda_patched/c/glm53"
PROMPT="Describe the water cycle in three sentences."
N=40; OUT="$HOME/bench/kda_check.log"
. "$HOME/src/colibri/tools/hot-expert/rig_lock.sh"
rig_lock_take "kda-check" || { echo "LOCK BUSY: $(rig_lock_holder)"; exit 3; }
GW=0; pgrep -f "openai_[s]erver.py" >/dev/null && GW=1
cleanup(){ if [ "$GW" = 1 ] && ! pgrep -f "openai_[s]erver.py" >/dev/null; then
    SKIP_WARM=1 setsid nohup "$HOME/start_glm53.sh" > "$HOME/glm53_server.log" 2>&1 < /dev/null & fi
  rig_lock_release; }
trap cleanup EXIT
if [ "$GW" = 1 ]; then pkill -f "start_[g]lm53.sh"; sleep 1; pkill -f "openai_[s]erver.py"; sleep 3
  pkill -9 -x glm53 2>/dev/null; for i in $(seq 1 90); do pgrep -x glm53 >/dev/null || break; sleep 1; done; fi

echo "=== kda_check $(date -Is) ===" | tee "$OUT"
env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close "$P" --model "$M" --prompt "$PROMPT" --greedy $N --logits > ~/bench/kda_p.out 2>&1
env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close "$Q" --model "$M" --prompt "$PROMPT" --greedy $N --logits > ~/bench/kda_q.out 2>&1
for f in teacher_forcing last_logits; do
  if diff <(grep "^$f" ~/bench/kda_p.out) <(grep "^$f" ~/bench/kda_q.out) >/dev/null; then
    echo "$f: IDENTICAL" | tee -a "$OUT"
  else
    echo "$f: DIFFERS" | tee -a "$OUT"
    python3 - <<'PY' | tee -a "$OUT"
import os
def v(p,k):
    for l in open(os.path.expanduser(p)):
        if l.startswith(k): return [float(x) for x in l.split()[1:]]
    return []
a,b=v("~/bench/kda_p.out","last_logits"),v("~/bench/kda_q.out","last_logits")
if a and b:
    n=min(len(a),len(b)); import math
    d=max(abs(a[i]-b[i]) for i in range(n))
    dot=sum(a[i]*b[i] for i in range(n)); na=math.sqrt(sum(x*x for x in a[:n])); nb=math.sqrt(sum(x*x for x in b[:n]))
    print(f"  max_abs={d:.3e} cos={dot/(na*nb):.9f} argmax {a.index(max(a))} vs {b.index(max(b))}")
PY
  fi
done
diff <(grep -v "USAGE\|STATS\|teacher_forcing\|last_logits\|tok/s\|token in\|experts hits\|^cache:\|budget" ~/bench/kda_p.out) \
     <(grep -v "USAGE\|STATS\|teacher_forcing\|last_logits\|tok/s\|token in\|experts hits\|^cache:\|budget" ~/bench/kda_q.out) >/dev/null \
  && echo "generated text: IDENTICAL" | tee -a "$OUT" || echo "generated text: DIFFERS" | tee -a "$OUT"

echo "--- order-controlled A/B (P,Q,Q,P, warm) ---" | tee -a "$OUT"
for arm in P Q Q P; do
  [ "$arm" = P ] && BIN="$P" || BIN="$Q"
  r=$(env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close "$BIN" --model "$M" --prompt "$PROMPT" --greedy $N 2>&1 | grep -m1 "^decode ")
  printf '%s  %s\n' "$arm" "$r" | tee -a "$OUT"
done
echo "=== done ===" | tee -a "$OUT"
