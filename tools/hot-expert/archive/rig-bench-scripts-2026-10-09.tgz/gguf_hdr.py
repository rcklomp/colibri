import struct, sys, glob, collections
T = {0:'F32',1:'F16',2:'Q4_0',3:'Q4_1',6:'Q5_0',7:'Q5_1',8:'Q8_0',9:'Q8_1',10:'Q2_K',11:'Q3_K',12:'Q4_K',13:'Q5_K',14:'Q6_K',15:'Q8_K',16:'IQ2_XXS',17:'IQ2_XS',18:'IQ3_XXS',19:'IQ1_S',20:'IQ4_NL',21:'IQ3_S',22:'IQ2_S',23:'IQ4_XS',24:'I8',25:'I16',26:'I32',27:'I64',28:'F64',29:'IQ1_M',30:'BF16',34:'TQ1_0',35:'TQ2_0',39:'MXFP4'}
def rd(f, fmt): return struct.unpack('<'+fmt, f.read(struct.calcsize('<'+fmt)))[0]
def rstr(f): n = rd(f,'Q'); return f.read(n).decode('utf-8','replace')
def rval(f, t):
    if t==0: return rd(f,'B')
    if t==1: return rd(f,'b')
    if t==2: return rd(f,'H')
    if t==3: return rd(f,'h')
    if t==4: return rd(f,'I')
    if t==5: return rd(f,'i')
    if t==6: return rd(f,'f')
    if t==7: return rd(f,'?')
    if t==8: return rstr(f)
    if t==9:
        at = rd(f,'I'); n = rd(f,'Q')
        if at==8 and n>64:
            for _ in range(n): rstr(f)
            return '<%d strings>'%n
        v=[rval(f,at) for _ in range(n)]
        return v if n<=64 else ('<%d x t%d> first %s'%(n,at,v[:8]))
    if t==10: return rd(f,'Q')
    if t==11: return rd(f,'q')
    if t==12: return rd(f,'d')
tensors=[]
for i,p in enumerate(sorted(glob.glob(sys.argv[1]))):
    f=open(p,'rb'); assert f.read(4)==b'GGUF'; ver=rd(f,'I'); nt=rd(f,'Q'); nkv=rd(f,'Q')
    for _ in range(nkv):
        k=rstr(f); t=rd(f,'I'); v=rval(f,t)
        if i==0: print('KV',k,'=',v)
    for _ in range(nt):
        n=rstr(f); nd=rd(f,'I'); dims=[rd(f,'Q') for _ in range(nd)]; tt=rd(f,'I'); off=rd(f,'Q')
        tensors.append((n,dims,T.get(tt,tt),i))
for n,d,t,i in tensors: print('T',n,d,t,i)
