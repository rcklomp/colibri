#!/bin/bash
# P7b smoke: the new --prefix-ckpt-partial case only, no tools, small system,
# scratch-clone binary. Minutes, not hours -- it says whether the harness step
# and the engine change work at all before the chain spends two hours.
set -u
OUT=~/bench/p7b_smoke_out; mkdir -p $OUT
rm -rf $OUT/ckpt; mkdir -p $OUT/ckpt
EXE=~/src/colibri-p7/c/glm53
HERE=~/src/colibri-p7/tools/hot-expert
echo "=== p7b smoke $(date -Is)"
~/bench/p7_stop.sh || exit 2
for _ in $(seq 1 240); do pgrep -x glm53 >/dev/null || break; sleep 1; done
COLI_CKPT_DIR=$OUT/ckpt python3 $HERE/ttft_serve.py --engine $EXE \
  --prefix-ckpt-partial --system ~/bench/p6_system.txt --kv-slots 4 \
  --sizes "" --repeat 0 --warm --min-resident 96 --tag p7bsmoke \
  --json $OUT/smoke.jsonl --engine-log $OUT/engine.log 2>&1 | tee $OUT/smoke.txt
echo "smoke rc=${PIPESTATUS[0]}"
for _ in $(seq 1 240); do pgrep -x glm53 >/dev/null || break; sleep 1; done
echo "--- restarting the gateway"
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 100
echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p7b smoke done $(date -Is)"
