#!/bin/bash
# glmserve_chain.sh -- one pass of the Franken engine on GLM-5.3-Flash behind the owner's
# gateway: serve_alt.sh franken-glm up, a wire-protocol conformance check plus one real chat
# request against it, then serve_alt.sh glm to hand the port back.
#
# --- WHY THIS IS NOT LAUNCHED AS `run_chain.sh glmserve_chain.sh` ------------------------------
# Every other chain on this rig (p*_chain.sh, f*_chain.sh) stops/starts glm53 directly and has
# no lock discipline of its own, so run_chain.sh's rig_lock_take(<chain-basename>) is the only
# thing standing between it and the watchdog. serve_alt.sh is different: it has ALWAYS had its
# own rig-lock protocol (serve_alt_lock_take/serve_alt_lock_release, serve_alt.sh's own header),
# because ITS job does not end when the script exits -- a `franken-glm`/`franken-ds4`/`qwen38`
# swap hands the lock to a KEEPER process (`tail --pid=$epid`) that holds it for as long as the
# alternative engine serves, however long the owner keeps it. `refuse_if_busy` and
# `serve_alt_lock_take` both treat a lock holder whose name matches `serve_alt*` as "ours"; a
# holder named `glmserve_chain` (what `run_chain.sh glmserve_chain.sh` would write) does NOT
# match that pattern, so `serve_alt.sh franken-glm` run underneath a run_chain.sh wrapper would
# hit `refuse_if_busy`'s "REFUSED: rig lock held by ... -- not ours" on its very first line and
# never start anything -- verified by reading rig_lock.sh/serve_alt.sh together, not run (this
# task is build-only), see this chain's own commit body.
#
# So: this script takes the SAME physical lock (~/bench/.rig.lock, rig_lock.sh) itself, under a
# NAME THAT STARTS WITH `serve_alt` (satisfying every `serve_alt*` check inside serve_alt.sh), and
# is meant to be launched directly, detached, exactly the way CLAUDE.md's "How a session drives
# the rig" says every rig job must be:
#
#   ssh -n -f rome 'setsid nohup ~/bench/glmserve_chain.sh > ~/bench/glmserve_chain.log 2>&1 < /dev/null &'
#
# It refuses (exit 3) if the lock is already held by anyone whose name does not start with
# `serve_alt` -- including a run_chain.sh chain, a live serve_alt keeper for a DIFFERENT
# alternative, or nothing at all if `serve_alt.sh franken-glm` itself is already mid-run.
#
# --- WHY serve_conformance.py IS NOT THE GATE HERE, AND WHAT THE CHAIN ACTUALLY CHECKS ---------
# serve_conformance.py speaks GATEWAY-PROTOCOL.md directly to a `--serve-test` CHILD PROCESS (the
# CPU binary, no GPU, no gateway, no port) -- it never touches port 8081. Run here as a fast,
# standalone wire-protocol smoke check of the SAME glm5_serve.cpp code the GPU binary links,
# --arch glm: phase 1 checks 6/7 (rollback to a checkpoint) and all of phase 3 (a second chat
# reusing a shared head) are EXPECTED TO FAIL -- glm5_serve.h's own header comment explains why
# (live-prefix reuse only, no checkpoint/snapshot) -- so this chain does not gate on its exit
# code, only prints its output for the record. The actual "does the served GLM arm work" check
# is the curl chat request against the LIVE gateway on port 8081 after `serve_alt.sh franken-glm`
# has put it there (which itself already runs one via send_test_chat, plus accept_live.sh when
# the rig is not reserved) -- this chain's own curl call is a second, independent one, exactly
# the "measure the request after the one being tested" rule CLAUDE.md gives for every gate.
set -u
HERE="$HOME/src/colibri/tools/hot-expert"
SERVE_ALT="$HERE/serve_alt.sh"
KEY_FILE="$HOME/.colibri_api_key"
ALT_PORT=8081
ALT_ALIAS=glm-5.3-flash
LOCK_NAME=serve_alt-glmserve-chain
CONFORM_LOG="$HOME/bench/glmserve_chain_conformance.log"

# shellcheck disable=SC1090
. "$HERE/rig_lock.sh"

log() { echo "[glmserve_chain] $(date -Is) $*"; }

RESTORED=0
on_exit() {
  local rc=$?
  # Every exit path stops the Franken container, whatever else happened.
  docker stop -t 5 franken_engine >/dev/null 2>&1 || true
  if [ "$RESTORED" != 1 ]; then
    log "exit trap: handing the port back to GLM (serve_alt.sh glm)"
    "$SERVE_ALT" glm || log "exit trap: serve_alt.sh glm did not return 0 -- the rig lock may still be held, investigate by hand"
  fi
  rig_lock_release
  log "chain done, rc=$rc"
}
trap on_exit EXIT INT TERM

log "=== glmserve_chain starting"
rig_lock_take "$LOCK_NAME" || { log "rig lock busy -- refusing (see this file's own header for why this isn't run_chain.sh)"; exit 3; }

log "--- step 1/4: serve_alt.sh franken-glm"
if ! "$SERVE_ALT" franken-glm; then
  log "FAIL: serve_alt.sh franken-glm did not come up -- it already ran its own restore-to-GLM on failure"
  RESTORED=1   # cmd_franken_glm's own failure paths already called restore_glm; don't call it twice
  exit 1
fi

log "--- step 2/4: serve_conformance.py --arch glm (informational, see this file's header)"
# Prefer this item's own worktree (has --arch glm; CLAUDE.md marks it temporary and it is
# removed once this item lands into ~/src/franken-engine) and fall back to the main tree, which
# gets --arch glm once the glm-serve branch is merged there.
if [ -e "$HOME/src/franken-engine-glmserve/franken/decode/serve_conformance.py" ]; then
  SC="$HOME/src/franken-engine-glmserve/franken/decode/serve_conformance.py"
elif [ -e "$HOME/src/franken-engine/franken/decode/serve_conformance.py" ]; then
  SC="$HOME/src/franken-engine/franken/decode/serve_conformance.py"
else
  SC=""
fi
if [ -n "$SC" ]; then
  python3 "$SC" --arch glm > "$CONFORM_LOG" 2>&1
  sc_rc=$?
  log "serve_conformance.py --arch glm rc=$sc_rc (full output: $CONFORM_LOG)"
  grep -E "^(PASS|FAIL|==)" "$CONFORM_LOG" | tail -60
else
  log "NOTE: serve_conformance.py not found under a known franken-engine checkout -- skipped"
fi

log "--- step 3/4: one real chat request against the live gateway (port $ALT_PORT)"
[ -s "$KEY_FILE" ] || { log "FAIL: $KEY_FILE missing or empty"; exit 1; }
resp_file=$(mktemp)
t0=$(date +%s.%N)
curl -s -m 300 -H "Authorization: Bearer $(cat "$KEY_FILE")" -H "Content-Type: application/json" \
  "http://127.0.0.1:${ALT_PORT}/v1/chat/completions" \
  -d "{\"model\":\"$ALT_ALIAS\",\"messages\":[{\"role\":\"user\",\"content\":\"In one short sentence, name the model you are and answer: what is 17 plus 25?\"}],\"max_tokens\":96}" \
  > "$resp_file"
t1=$(date +%s.%N)
dt=$(python3 -c "print($t1 - $t0)")
chat_rc=0
python3 - "$resp_file" "$dt" <<'PY' || chat_rc=1
import json, sys
path, dt = sys.argv[1], float(sys.argv[2])
try:
    d = json.load(open(path))
    choice = d["choices"][0]["message"]["content"]
    usage = d.get("usage", {})
    ct = usage.get("completion_tokens")
except Exception as e:
    print(f"FAIL: could not parse a chat reply ({e}); raw response follows:")
    print(open(path).read()[:2000])
    sys.exit(1)
print("--- reply:")
print(choice.strip())
if ct:
    print(f"--- completion_tokens={ct} wall_s={dt:.2f} tok/s={ct/dt:.2f}")
else:
    print(f"--- wall_s={dt:.2f} (no completion_tokens in usage)")
PY
rm -f "$resp_file"
if [ "$chat_rc" != 0 ]; then
  log "FAIL: the live chat request did not return a usable reply"
  exit 1
fi

log "--- step 4/4: serve_alt.sh glm (hand the port back; under ~/bench/.dev_reserved this only stops the alt arm and frees the lock)"
if "$SERVE_ALT" glm; then
  RESTORED=1
  log "PASS: franken-glm served one real chat, and the port is back with serve_alt.sh glm"
  exit 0
else
  log "FAIL: serve_alt.sh glm did not return 0 -- rig lock may be held on purpose (its own FATAL message says why); NOT calling it again from the exit trap"
  RESTORED=1
  exit 1
fi
