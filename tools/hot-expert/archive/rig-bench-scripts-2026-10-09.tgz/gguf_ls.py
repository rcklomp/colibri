import struct, sys
TN={0:'F32',1:'F16',2:'Q4_0',3:'Q4_1',6:'Q5_0',7:'Q5_1',8:'Q8_0',9:'Q8_1',10:'Q2_K',11:'Q3_K',12:'Q4_K',13:'Q5_K',14:'Q6_K',15:'Q8_K',16:'IQ2_XXS',17:'IQ2_XS',18:'IQ3_XXS',19:'IQ1_S',20:'IQ4_NL',21:'IQ3_S',22:'IQ2_S',23:'IQ4_XS',24:'I8',25:'I16',26:'I32',27:'I64',28:'F64',29:'IQ1_M',30:'BF16',34:'TQ1_0',35:'TQ2_0',39:'MXFP4'}
def rd(f,fmt): return struct.unpack('<'+fmt,f.read(struct.calcsize('<'+fmt)))
def rstr(f): n,=rd(f,'Q'); return f.read(n).decode('utf-8','replace')
def rval(f,t):
    m={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
    if t in m: return rd(f,m[t])[0]
    if t==8: return rstr(f)
    if t==9:
        at,=rd(f,'I'); n,=rd(f,'Q')
        return [rval(f,at) for _ in range(n)]
for p in sys.argv[1:]:
    f=open(p,'rb'); f.read(4); ver,=rd(f,'I'); nt,nkv=rd(f,'QQ')
    print('##',p,'tensors',nt,'kv',nkv)
    for _ in range(nkv):
        k=rstr(f); t,=rd(f,'I'); v=rval(f,t)
        if isinstance(v,list) and len(v)>64: v=('[%d] '%len(v))+str(v[:8])+'...'
        print('KV',k,'=',v)
    for _ in range(nt):
        n=rstr(f); nd,=rd(f,'I'); ne=rd(f,'Q'*nd); t,=rd(f,'I'); off,=rd(f,'Q')
        print('T',n,TN.get(t,t),'x'.join(map(str,ne)))
