#!/bin/bash
# Re-run of step (e) after the gateway-side fix (openai_server.py: a cancelled
# request keeps its [req] line). No engine change: c/glm53.c is untouched since
# the merge the gate already ran on, so the served binary is not rebuilt and
# not replaced -- the merge here is a fast-forward over tools/ and
# c/openai_server.py only, and the binary is untracked (c/.gitignore:49).
#
# Structure is the chain's: stop gateway -> merge -> python suite -> restart ->
# live rows -> the curl disconnect twice. The gateway comes back on every exit
# path, and the served binary's sha is asserted unchanged before and after.
set -u
TAG=cancellive2$(date +%m%d%H%M)
OUT=~/bench/cancel_live2_out; mkdir -p $OUT
HERE=~/src/colibri/tools/hot-expert
CAND_SHA=fb795eb1159baf7ab93035c057bf5c83d538f4c4281085aa39c11dc375bd51b5

start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
on_exit() {
  rc=$?
  pgrep -f "openai_[s]erver.py" >/dev/null || { echo "=== restoring the gateway (rc=$rc)"; start_gateway; }
  echo "=== live2 done $(date -Is)"
}
trap on_exit EXIT

echo "=== live2 start $(date -Is) tag=$TAG"
b=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
[ "$b" = "$CAND_SHA" ] || { echo "REFUSED: served binary is $b, not the gated candidate"; exit 2; }
echo "served binary: $b (the gated candidate)"

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2
for i in $(seq 1 240); do pgrep -x glm53 >/dev/null || break; sleep 1; done

echo "--- merging p0-sync (tools/ + c/openai_server.py; c/glm53.c unchanged)"
cd ~/src/colibri || exit 2
git checkout hot-expert-tier || exit 2
git merge --no-edit --ff-only p0-sync || { echo "MERGE NOT A FAST-FORWARD"; exit 2; }
git log --oneline -1
git diff --stat HEAD@{1} HEAD
b2=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
[ "$b2" = "$CAND_SHA" ] || { echo "REFUSED: the merge changed the served binary ($b2)"; exit 2; }
echo "served binary after the merge: $b2 (unchanged)"

echo "--- the gateway's own test suite"
( cd ~/src/colibri/c && timeout 900 python3 -m unittest tests.test_openai_server ) > $OUT/test_openai.txt 2>&1
r=$?; echo "  test_openai_server exit=$r  $(tail -3 $OUT/test_openai.txt | tr '\n' ' ')"
[ "$r" = 0 ] || { echo "GATEWAY TESTS FAILED"; exit 4; }

echo "--- restarting the gateway"
start_gateway

echo
echo "### (e1) ttft_serve --url --cancel 5 --cancel-phase decode"
python3 $HERE/ttft_serve.py --url http://127.0.0.1:8081 --sizes 1000 --repeat 1 --warm \
    --cancel 5 --cancel-phase decode \
    --tag $TAG --json $OUT/live.jsonl 2>&1 | tee $OUT/live.txt | tail -20
echo "live cancel rc=${PIPESTATUS[0]}"

echo
echo "### (e2) a real client disconnect: curl -m 8, twice"
KEY=$(cat ~/.colibri_api_key)
MODEL=$(curl -s -H "Authorization: Bearer $KEY" http://127.0.0.1:8081/v1/models \
        | python3 -c "import json,sys; print(json.load(sys.stdin)['data'][0]['id'])")
python3 - "$MODEL" > $OUT/curl_big.json <<'PY'
import json, sys
text = open("/home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md").read()
user = ("Read the following notes and answer in one sentence: what machine "
        "are they about?\n\n" + text[:4200])
print(json.dumps({"model": sys.argv[1], "stream": True, "max_tokens": 256,
                  "temperature": 0, "messages": [{"role": "user", "content": user}]}))
PY
python3 - "$MODEL" > $OUT/curl_small.json <<'PY'
import json, sys
print(json.dumps({"model": sys.argv[1], "stream": False, "max_tokens": 8,
                  "temperature": 0, "messages": [{"role": "user", "content": "Say OK."}]}))
PY
for round in 1 2; do
  echo "--- round $round: curl -m 8 (the browser tab closing)"
  date -Is
  curl -s -m 8 -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
       -d @$OUT/curl_big.json http://127.0.0.1:8081/v1/chat/completions > $OUT/curl_big_$round.out
  rc=$?; echo "curl exit=$rc (28 = timed out and hung up, which is the point)"
  S=$(date +%s.%N)
  curl -s -m 300 -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
       -d @$OUT/curl_small.json http://127.0.0.1:8081/v1/chat/completions > $OUT/curl_small_$round.out
  rc=$?; E=$(date +%s.%N); echo "curl exit=$rc"
  python3 -c "print(f'round $round: short request after the disconnect: {$E - $S:.2f} s')"
  head -c 240 $OUT/curl_small_$round.out; echo
done
echo
echo "--- the gateway's own record (the cancelled requests must be IN it)"
~/bench/owui_report.sh 10
grep -E "CANCEL [0-9]+ at " ~/glm53_server.log | tail -8
