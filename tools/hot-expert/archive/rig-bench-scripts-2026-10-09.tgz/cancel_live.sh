#!/bin/bash
# Step (e) of cancel_gate, re-run against the gateway that is already serving
# the candidate. Starts no engine of its own: --url uses the gateway's, which
# is the same thing the chain's own live step does after it serves.
set -u
TAG=cancellive$(date +%m%d%H%M)
OUT=~/bench/cancel_live_out; mkdir -p $OUT
HERE=~/src/colibri-p7/tools/hot-expert

echo "=== live cancel checks $(date -Is) tag=$TAG"
echo "serving binary: $(sha256sum ~/src/colibri/c/glm53 | cut -c1-16)"
pgrep -f "openai_[s]erver.py" >/dev/null || { echo "REFUSED: no gateway"; exit 2; }

echo
echo "### (e1) ttft_serve --url --cancel 5 --cancel-phase decode"
python3 $HERE/ttft_serve.py --url http://127.0.0.1:8081 --sizes 1000 --repeat 1 --warm \
    --cancel 5 --cancel-phase decode \
    --tag $TAG --json $OUT/live.jsonl 2>&1 | tee $OUT/live.txt | tail -25
echo "live cancel rc=${PIPESTATUS[0]}"
~/bench/owui_report.sh 3

echo
echo "### (e2) a real client disconnect: curl -m 8, twice"
KEY=$(cat ~/.colibri_api_key)
MODEL=$(curl -s -H "Authorization: Bearer $KEY" http://127.0.0.1:8081/v1/models \
        | python3 -c "import json,sys; print(json.load(sys.stdin)['data'][0]['id'])")
echo "model id: $MODEL"
python3 - "$MODEL" > $OUT/curl_big.json <<'PY'
import json, sys
text = open("/home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md").read()
user = ("Read the following notes and answer in one sentence: what machine "
        "are they about?\n\n" + text[:4200])
print(json.dumps({"model": sys.argv[1], "stream": True, "max_tokens": 256,
                  "temperature": 0, "messages": [{"role": "user", "content": user}]}))
PY
python3 - "$MODEL" > $OUT/curl_small.json <<'PY'
import json, sys
print(json.dumps({"model": sys.argv[1], "stream": False, "max_tokens": 8,
                  "temperature": 0, "messages": [{"role": "user", "content": "Say OK."}]}))
PY
for round in 1 2; do
  echo "--- round $round: curl -m 8 (the browser tab closing)"
  date -Is
  curl -s -m 8 -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
       -d @$OUT/curl_big.json http://127.0.0.1:8081/v1/chat/completions > $OUT/curl_big_$round.out
  rc=$?
  echo "curl exit=$rc (28 = timed out and hung up, which is the point)"
  date -Is
  S=$(date +%s.%N)
  curl -s -m 300 -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
       -d @$OUT/curl_small.json http://127.0.0.1:8081/v1/chat/completions > $OUT/curl_small_$round.out
  rc=$?
  E=$(date +%s.%N)
  echo "curl exit=$rc"
  python3 -c "print(f'round $round: short request after the disconnect: {$E - $S:.2f} s')"
  head -c 260 $OUT/curl_small_$round.out; echo
done
echo
echo "--- the gateway's own record"
~/bench/owui_report.sh 8
grep -E "CANCEL [0-9]+ at " ~/glm53_server.log | tail -8
echo "=== live checks done $(date -Is)"
