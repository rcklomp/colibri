#!/bin/bash
# P7 chain: merge p0-sync, build, run p7_gate.sh, and serve the candidate only
# if the gate exits 0 AND the live gateway checks pass. The structure is
# p6c_chain.sh's: back up the serving script, patch it, restart, check, revert
# on failure -- and put a working gateway back on EVERY exit path, because it
# is the owner's daily service.
set -u
TAG=p7$(date +%m%d%H%M)
OUT=~/bench/p7_chain_out; mkdir -p $OUT
SNAP=~/models/GLM-5.3-Flash-colibri-int4-g64
CKPT=$SNAP/.coli_ckpt
SERVED=0

start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}

PREMERGE=""
revert_and_serve_pristine() {
  echo "--- REVERTING: pristine binary, pristine tree, original serving script"
  # Stop EVERYTHING first: a leftover engine from a gate step holds the binary
  # open, `cp` fails with ETXTBSY, and the revert silently leaves the CANDIDATE
  # in service. That happened on 2026-09-07 and is why this waits and verifies.
  ~/bench/p7_stop.sh
  cp ~/bench/start_glm53.sh.p7base ~/start_glm53.sh
  chmod +x ~/start_glm53.sh
  if [ -n "$PREMERGE" ]; then (cd ~/src/colibri && git reset --hard "$PREMERGE"); fi
  cp ~/bench/glm53.p7base ~/src/colibri/c/glm53 || { echo "REVERT COPY FAILED"; }
  a=$(sha256sum ~/bench/glm53.p7base | cut -d" " -f1)
  b=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
  if [ "$a" != "$b" ]; then echo "REVERT FAILED: served binary is NOT the pristine one ($b)"; fi
  rm -f $CKPT/*.bin
  start_gateway
}

on_exit() {
  rc=$?
  if [ "$SERVED" != 1 ]; then
    echo "=== chain exiting rc=$rc without a served candidate"
    if ! pgrep -f "openai_[s]erver.py" >/dev/null; then revert_and_serve_pristine; fi
  fi
  echo "=== p7 chain done $(date -Is)"
}
trap on_exit EXIT

echo "=== p7 chain start $(date -Is) tag=$TAG"
cp ~/start_glm53.sh ~/bench/start_glm53.sh.p7base
sha256sum ~/bench/glm53.p7base ~/src/colibri/c/glm53

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2

echo "--- merging p0-sync into hot-expert-tier"
cd ~/src/colibri || exit 2
git checkout hot-expert-tier || exit 2
PREMERGE=$(git rev-parse HEAD); echo "pre-merge HEAD $PREMERGE"
git merge --no-edit p0-sync || { echo "MERGE FAILED"; exit 2; }
git log --oneline -1

echo "--- building"
make -C c glm53 VK=1 2>&1 | tail -5
[ -x ~/src/colibri/c/glm53 ] || { echo "BUILD FAILED"; exit 2; }
sha256sum ~/src/colibri/c/glm53

echo "--- clearing the checkpoint directory so the gate measures cold -> warm"
mkdir -p $CKPT; rm -f $CKPT/*.bin; ls -l $CKPT

echo "--- p7_gate.sh"
bash ~/src/colibri/tools/hot-expert/p7_gate.sh ~/bench/glm53.p7base ~/src/colibri/c/glm53 $TAG 2>&1 | tee $OUT/gate_$TAG.log
GATE=${PIPESTATUS[0]}
echo "GATE rc=$GATE"
if [ "$GATE" != 0 ]; then
  echo "GATE FAILED ($GATE) -- pristine stays in service"
  revert_and_serve_pristine
  exit $GATE
fi

echo "--- patching the serving script (COLI_PREFIX_PIN=1, GLM53_PREFIX_CKPT=1)"
python3 - <<'PY'
import os
p = os.path.expanduser("~/start_glm53.sh"); s = open(p).read()
add = ("# P7 (2026-09-07): prefix checkpoints in the engine and the gateway-side pin.\n"
       "# The engine snapshots the shared system+tools prefix at the boundary the\n"
       "# gateway sends in the 8th SUBMIT field and persists it under\n"
       "# $M/.coli_ckpt, so a NEW conversation -- and the first request after a\n"
       "# gateway restart -- starts warm. COLI_PREFIX_PIN keeps Open WebUI's\n"
       "# <memory_context> block byte-identical for the life of a conversation\n"
       "# (with more than one memory it re-ranks every turn and turn 2 reused 0/195).\n"
       "export GLM53_PREFIX_CKPT=1\n"
       "export COLI_PREFIX_PIN=1\n")
anchor = "export COLI_REQ_LOG=1"
assert anchor in s, "anchor missing from the serving script"
assert "COLI_PREFIX_PIN" not in s, "serving script already patched"
i = s.index(anchor); j = s.index("\n", i) + 1
s = s[:j] + add + s[j:]
open(p + ".new", "w").write(s)
os.chmod(p + ".new", 0o755)
os.replace(p + ".new", p)
PY
grep -n "GLM53_PREFIX_CKPT\|COLI_PREFIX_PIN\|kv-slots\|COLI_KDA_GPU=" ~/start_glm53.sh

echo "--- restarting the gateway on the candidate"
start_gateway
grep -m1 "listening\|Traceback\|ValueError" ~/glm53_server.log

echo "--- live check A: --prefix-ckpt through the gateway (disk checkpoint from the gate)"
timeout 5400 python3 -u ~/src/colibri/tools/hot-expert/ttft_serve.py \
    --url http://127.0.0.1:8081 --prefix-ckpt \
    --tools ~/bench/owui_tools.json --system ~/bench/p6_system.txt \
    --sizes "" --repeat 0 --warm --min-resident 96 \
    --tag $TAG-live --json $OUT/live.jsonl 2>&1 | tee $OUT/liveA_$TAG.log
LIVEA=${PIPESTATUS[0]}

echo "--- live check B: --pin-block through the gateway"
timeout 3600 python3 -u ~/src/colibri/tools/hot-expert/ttft_serve.py \
    --url http://127.0.0.1:8081 --pin-block --system ~/bench/p6_system.txt \
    --sizes "" --repeat 0 --warm --min-resident 96 \
    --tag $TAG-livepin --json $OUT/live.jsonl 2>&1 | tee $OUT/liveB_$TAG.log
LIVEB=${PIPESTATUS[0]}

echo "--- CKPT / REUSE / pin lines from the gateway log"
grep "CKPT \|\[pin\]" ~/glm53_server.log | tail -20
~/bench/owui_report.sh 12

echo "live A rc=$LIVEA live B rc=$LIVEB"
if [ "$LIVEA" = 0 ] && [ "$LIVEB" = 0 ]; then
  SERVED=1
  echo "=== P7 IN SERVICE: checkpoints + pin, binary $(sha256sum ~/src/colibri/c/glm53 | cut -c1-16)"
else
  echo "=== LIVE CHECK FAILED -- reverting"
  ~/bench/p7_stop.sh
  revert_and_serve_pristine
  exit 3
fi
