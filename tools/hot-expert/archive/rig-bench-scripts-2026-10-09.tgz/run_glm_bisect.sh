#!/usr/bin/env bash
cd /home/ronald/src/colibri
G=/home/ronald/models/GLM-5.3-Flash-colibri-int4-g64
P="$(cat ~/bench/prompt_glm.txt)"
log(){ echo "[$(date +%H:%M:%S)] $*"; }
for c in 573871f 6da3910 eabeb9a ad035fe 2d3cf7e; do
  d=/tmp/wt-$c; [ -d $d ] || git worktree add -q $d $c
  log "build glm53 @ $c"; ( cd $d/c && make glm53 VK=1 2>&1 | grep -E "error" ; ls -la glm53 shaders/qmatmul.spv | awk "{print \$5, \$9}" )
done
sudo -n sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches' 2>&1 | grep -v assword || true   # no password stored here (2026-10-06): needs passwordless sudo for this command, else the cache drop is skipped
log "warm GLM"; cat $G/*.safetensors > /dev/null
VK="COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_EXPERTS2=1695 COLI_VK_DEV3=auto COLI_VK_EXPERTS3=1695 COLI_USAGE_PATH=/home/ronald/.glm53_explain.bin"
for c in 573871f 6da3910 eabeb9a ad035fe 2d3cf7e 573871f; do
  d=/tmp/wt-$c/c
  log "run glm53 @ $c"
  ( cd $d && env $VK COLI_VK_SHADERS=$d/shaders /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_bisect_$c.log 2>&1 ); echo "rc=$?"
  grep -E "preload|denso|decode |Major|MAP\]" ~/bench/glm_bisect_$c.log | cut -c1-120
done
log "bisect done"
nohup ~/bench/run_steady.sh > ~/bench/steady.out 2>&1 &
