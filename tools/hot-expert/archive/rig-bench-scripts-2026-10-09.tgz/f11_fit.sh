#!/bin/bash
# Engine step 0: Qwen3.8-Flash-Next under llama.cpp fit at a 32k and a 256k window --
# how much went to the CPU (fit-print) and decode at 19k with fewer CPU experts.
until ~/src/colibri/tools/hot-expert/serve_alt.sh status 2>&1 | grep -q "serving: GLM-5.3 (model id"; do sleep 30; done
export F11_ONLY=Q F11_SKIP_SWEEP=1
for ctx in 32768 262144; do
  echo "=== f11_fit ctx=$ctx $(date -Is)"
  F11_CTX=$ctx ~/src/colibri/tools/hot-expert/run_chain.sh ~/src/colibri/tools/hot-expert/f11_ladder_chain.sh > ~/bench/f11_fit_${ctx}.log 2>&1
  echo "=== rc=$? $(date -Is)"
done
sleep 60; ~/src/colibri/tools/hot-expert/accept_live.sh | tail -1
