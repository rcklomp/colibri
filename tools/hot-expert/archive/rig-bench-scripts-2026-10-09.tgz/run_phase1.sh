#!/usr/bin/env bash
set -o pipefail
cd /home/ronald/src/colibri/c
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "rebuild stale binaries (VK=1)"
make qwen38-vk glm53 VK=1 > ~/bench/build.log 2>&1; echo "build rc=$?"
log "warm Qwen page cache"
cat $M/*.safetensors > /dev/null; log "warm done"
fincore --bytes --noheadings $M/*.safetensors | awk '{r+=$1} END {printf "resident %.1f GiB\n", r/2^30}'
for cap in 64 512; do
  log "Qwen CPU baseline cap=$cap"
  SNAP=$M N_NEW=64 NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin \
    /usr/bin/time -v ./qwen38 $cap 8 ~/bench/prompt1.txt > ~/bench/q38_cpu_cap$cap.log 2>&1
  echo "rc=$?"; grep -E 'Speed|TTFT|hit rate|PEAK|timers\]' ~/bench/q38_cpu_cap$cap.log
done
log "phase1 done"
