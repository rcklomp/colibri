#!/bin/bash
# Q5 gate: fuse the CPU expert's three matmuls into ONE OpenMP region.
# base = Q9 only; cand = Q9 + Q5, so this isolates Q5.
# Gate (roadmap): bit-identical; [OPTIME] cpu-experts <= 13.5 ms/token; report
# step and vk-take beside it and say plainly if the token did not move.
set -u
QSNAP=~/models/Qwen3.8-Flash-Next-FP8
BASE=~/bench/q9/c/qwen38-vk; CAND=~/bench/q5/c/qwen38-vk
SH=~/bench/q5/c/shaders; OUT=~/bench/q5out; mkdir -p "$OUT"; LOG=~/bench/q5_gate2.log
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q5-gate2" 120 || exit 3
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
stop_gateway || exit 1
P=/tmp/q5_prompt.txt
python3 -c "print(open('$HOME/bench/prompt_glm.txt').read().strip())" > "$P"
echo "=== q5_gate $(date -Is)  N_NEW=32 (decode, where the CPU expert share lives) ===" | tee "$LOG"
find "$QSNAP" -type f -name "*.safetensors" -print0 | while IFS= read -r -d '' f; do cat "$f" >/dev/null; done
run(){ cp -f "$QSNAP/.coli_usage" /tmp/q5_hist.bin
  env SNAP="$QSNAP" COLI_USAGE=/tmp/q5_hist.bin N_NEW=32 NOSTREAM=1 \
      Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS="$SH" \
      COLI_TIMERS=1 Q38_TF=1 Q38_TF_DUMP="$OUT/$1.f32" \
      OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close \
      "$2" 512 8 "$P" > "$OUT/$1.log" 2>&1
  echo "--- $1 rc=$?" | tee -a "$LOG"
  grep -E "OPTIME. (cpu-experts|step|vk-take|routed)" "$OUT/$1.log" | sed 's/^/  /' | tee -a "$LOG"
  grep -E "^Speed:|tok/s" "$OUT/$1.log" | head -1 | sed 's/^/  /' | tee -a "$LOG"; }
run base1 "$BASE"; run cand1 "$CAND"; run cand2 "$CAND"; run base2 "$BASE"
echo "--- ORACLE ---" | tee -a "$LOG"
bt=$(grep -c '^teacher_forcing' "$OUT/base1.log"); ct=$(grep -c '^teacher_forcing' "$OUT/cand1.log")
if [ "$bt" -lt 1 ] || [ "$ct" -lt 1 ]; then echo "  REFUSED: no teacher_forcing (base=$bt cand=$ct) -- NOT a pass" | tee -a "$LOG"
else diff <(grep '^teacher_forcing' "$OUT/base1.log") <(grep '^teacher_forcing' "$OUT/cand1.log") >/dev/null \
  && echo "  teacher_forcing: IDENTICAL" | tee -a "$LOG" || echo "  teacher_forcing: DIFFERS" | tee -a "$LOG"; fi
if [ -s "$OUT/base1.f32" ] && [ -s "$OUT/cand1.f32" ]; then
  cmp -s "$OUT/base1.f32" "$OUT/cand1.f32" && echo "  logits: BIT-IDENTICAL" | tee -a "$LOG" \
    || echo "  logits: DIFFER (Q5 must be bit-identical -- investigate)" | tee -a "$LOG"
else echo "  logits: NO DUMP -- oracle incomplete" | tee -a "$LOG"; fi
echo "=== done ===" | tee -a "$LOG"
