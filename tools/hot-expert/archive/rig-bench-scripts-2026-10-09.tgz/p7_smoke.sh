#!/bin/bash
# P7 smoke: exercise the new code paths cheaply (4-tool prefix, scratch clone,
# scratch checkpoint dir) with the gateway stopped, then put the gateway back.
# Not a gate: it is here so the real gate is not the first run of new code.
set -u
LOG=~/bench/p7_smoke_out
mkdir -p $LOG
export COLI_CKPT_DIR=$LOG/ckpt
mkdir -p $COLI_CKPT_DIR
rm -f $COLI_CKPT_DIR/*.bin
S=~/src/colibri-p7

restart_gateway() {
  echo "--- restarting the gateway $(date -Is)"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 90
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
trap restart_gateway EXIT

echo "=== p7 smoke start $(date -Is)"
cd $S && git fetch -q origin && git checkout -q -B p0-sync origin/p0-sync && git log --oneline -1
make -C c glm53 VK=1 2>&1 | grep -E "error|Error" && { echo BUILD FAILED; exit 9; }
ls -l c/glm53

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2
echo "engines left: $(pgrep -x glm53 | wc -l)"

echo "### smoke A: --prefix-ckpt --oracle (4 tools, default system)"
timeout 3600 python3 $S/tools/hot-expert/ttft_serve.py --engine $S/c/glm53 \
   --prefix-ckpt --oracle --tools ~/bench/owui_tools_4.json --kv-slots 4 \
   --sizes "" --repeat 0 --min-resident 90 --tag smokeA --json $LOG/smoke.jsonl \
   --engine-log $LOG/engine_a.log --logit-dir $LOG/logits 2>&1 | tail -60
echo "smoke A rc=${PIPESTATUS[0]}"

echo "### smoke B: --pin-block"
timeout 1800 python3 $S/tools/hot-expert/ttft_serve.py --engine $S/c/glm53 \
   --pin-block --kv-slots 4 --sizes "" --repeat 0 --min-resident 90 \
   --tag smokeB --json $LOG/smoke.jsonl --engine-log $LOG/engine_b.log 2>&1 | tail -30
echo "smoke B rc=${PIPESTATUS[0]}"

echo "### smoke C: tworeq 4 slots, KDA 0"
env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close COLI_VULKAN=1 \
    COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695 \
    COLI_VK_SHADERS=$S/c/shaders COLI_USAGE_PATH=$LOG/hist.bin COLI_KDA_GPU=0 \
    TWOREQ_SLOTS=4 TWOREQ_EXE=$S/c/glm53 GLM53_VERBOSE=1 \
    timeout 1800 python3 $S/tools/hot-expert/tworeq.py 2>&1 | tail -5
echo "smoke C rc=${PIPESTATUS[0]}"

echo "--- CKPT lines seen"
grep -h "^CKPT\|^REUSE" $LOG/engine_a.log $LOG/engine_b.log | tail -30
echo "--- ckpt dir"; ls -l $COLI_CKPT_DIR
echo "=== p7 smoke done $(date -Is)"
