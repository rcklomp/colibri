#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
cp ~/bench/staged/quant.h quant.h
log "kernel A/B (fp8acc2)"
gcc -O3 -march=native -fopenmp -I. ~/bench/fp8acc2.c -o ~/bench/fp8acc2 -lm 2>&1 | grep -E "error" | head
for th in "" 8; do for acc in 0 1; do
  env ${th:+COLI_FP8_THREADS=$th} COLI_FP8_ACC2=$acc OMP_NUM_THREADS=16 OMP_PLACES=threads OMP_PROC_BIND=close ~/bench/fp8acc2 ~/bench/acc_${acc}_${th:-16}.bin
done; done
python3 ~/bench/cmp_logits.py ~/bench/acc_0_16.bin ~/bench/acc_1_16.bin
log "build"
make qwen38 qwen38-vk VK=1 2>&1 | grep -E "error|warning" | head -5; ls -la qwen38 qwen38-vk
VKENV="Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS=shaders"
run(){ name=$1; bin=$2; shift 2; log "run $name"; env "$@" SNAP=$M NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin DUMP=/home/ronald/bench/logits_$name.f32 /usr/bin/time -v $bin 512 8 ~/bench/prompt1.txt > ~/bench/q38_$name.log 2>&1; echo "rc=$?"; grep -E "Speed|TTFT|routed-expert|resident-mm|deltanet|shared-expert|expert-read|preloaded|Major|Percent|Text" ~/bench/q38_$name.log; }
run base_dump ~/bench/qwen38.base N_NEW=64
run t8 ./qwen38 N_NEW=64 COLI_FP8_THREADS=8 OMP_PLACES=threads OMP_PROC_BIND=close
run t8acc2 ./qwen38 N_NEW=64 COLI_FP8_THREADS=8 OMP_PLACES=threads OMP_PROC_BIND=close COLI_FP8_ACC2=1
run t16acc2 ./qwen38 N_NEW=64 COLI_FP8_ACC2=1
run vk_t8acc2_128 ./qwen38-vk $VKENV N_NEW=128 COLI_FP8_THREADS=8 OMP_PLACES=threads OMP_PROC_BIND=close COLI_FP8_ACC2=1
run vk_t8_64 ./qwen38-vk $VKENV N_NEW=64 COLI_FP8_THREADS=8 OMP_PLACES=threads OMP_PROC_BIND=close
log "logit identity vs pristine baseline (same 64 greedy tokens => comparable)"
for n in t8 t8acc2 t16acc2 vk_t8_64; do python3 ~/bench/cmp_logits.py ~/bench/logits_base_dump.f32 ~/bench/logits_$n.f32; done
log "phase6 done"
