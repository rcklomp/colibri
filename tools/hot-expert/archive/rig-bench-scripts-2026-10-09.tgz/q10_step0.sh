#!/bin/bash
# Q10 step 0: the recurrence microbenchmark on a quiet rig.
set -u
. /home/ronald/src/colibri/tools/hot-expert/rig_lock.sh
rig_lock_take q10-step0 || exit 3
restore() {
  pgrep -f "openai_[s]erver.py" >/dev/null || \
    SKIP_WARM=1 setsid nohup /home/ronald/start_glm53.sh > /home/ronald/glm53_server.log 2>&1 < /dev/null &
  sleep 2
  rig_lock_release
}
trap restore EXIT INT TERM

pkill -f "openai_[s]erver.py"; sleep 2; pkill -9 -x glm53
for i in $(seq 1 60); do pgrep -x glm53 >/dev/null || break; sleep 1; done
echo "engines down: glm53=$(pgrep -x glm53 | wc -l) qwen38=$(pgrep -x qwen38 | wc -l)"

cd /home/ronald/src/colibri-q10/tools/hot-expert
gcc -O3 -march=native -fopenmp -pthread -o /tmp/rome_dnbench rome_dnbench.c -lm || exit 1
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
echo "================= FULL RUN ================="
/tmp/rome_dnbench recur
