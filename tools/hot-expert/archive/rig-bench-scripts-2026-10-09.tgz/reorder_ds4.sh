#!/bin/bash
# after the franken-ds4 arm of the DeepSeek quality chain, stop the chain (its trap restores GLM),
# so the GLM gate (queued on "chain exit rc") runs next; then the llama.cpp DeepSeek arm alone.
L=~/bench/franken_quality/chain_ds4.log
until grep -q -- "--- eval --expect franken-ds4 exit=" $L; do sleep 30; done
pkill -TERM -f "franken_quality_[c]hain.sh"
until grep -q "chain exit rc" $L; do sleep 10; done
until grep -q "run_chain glm5_chain exited" ~/bench/glm5_chain.log 2>/dev/null; do sleep 60; done
sleep 120
FRANKEN_BIN=$HOME/bench/franken_decode_ds4_docker.sh ARMS=deepseek exec ~/src/colibri/tools/hot-expert/franken_quality_chain.sh > ~/bench/franken_quality/chain_ds4_llama.log 2>&1
