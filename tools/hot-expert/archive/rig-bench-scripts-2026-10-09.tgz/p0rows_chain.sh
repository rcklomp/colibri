#!/bin/bash
# the one-time long baseline rows that the P0 chain lost to the import bug; runs on the serving binary
while pgrep -f "p2c_[c]hain.sh" >/dev/null; do sleep 30; done
echo "=== p0rows start $(date -Is)"; cd ~/src/colibri
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
md5sum c/glm53
python3 tools/hot-expert/ttft_serve.py --engine ~/src/colibri/c/glm53 --sizes 3000 --repeat 1 --warm --tag rows-3000 --json ~/bench/ttft_p0.jsonl 2>&1 | grep -v "^\[VK\]\|^cache:\|^REUSE"
python3 tools/hot-expert/ttft_serve.py --engine ~/src/colibri/c/glm53 --sizes 30 --repeat 1 --warm --tools /tmp/owui_tools.json --tag rows-tools --json ~/bench/ttft_p0.jsonl 2>&1 | grep -v "^\[VK\]\|^cache:\|^REUSE"
pkill -9 -x glm53 2>/dev/null; sleep 2
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p0rows done $(date -Is)"
