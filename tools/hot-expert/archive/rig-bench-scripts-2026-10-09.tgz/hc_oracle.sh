#!/bin/bash
# Bit-identity oracle for the hyper_connections parallelisation, on UPSTREAM dev:
# same prompt, greedy decode, pristine vs patched, compare generated text AND the
# dumped logits. A parallel-for over independent rows must change nothing.
set -u
M="$HOME/models/GLM-5.3-Flash-colibri-int4-g64"
P="$HOME/bench/hc_pristine/c/glm53"
Q="$HOME/bench/hc_patched/c/glm53"
PROMPT="Describe the water cycle in three sentences."
N="${N:-40}"
. "$HOME/src/colibri/tools/hot-expert/rig_lock.sh"
rig_lock_take "hc-oracle" || { echo "LOCK BUSY: $(rig_lock_holder)"; exit 3; }
GW=0; pgrep -f "openai_[s]erver.py" >/dev/null && GW=1
cleanup(){ if [ "$GW" = 1 ] && ! pgrep -f "openai_[s]erver.py" >/dev/null; then
    SKIP_WARM=1 setsid nohup "$HOME/start_glm53.sh" > "$HOME/glm53_server.log" 2>&1 < /dev/null & fi
  rig_lock_release; }
trap cleanup EXIT
if [ "$GW" = 1 ]; then pkill -f "start_[g]lm53.sh"; sleep 1; pkill -f "openai_[s]erver.py"; sleep 3
  pkill -9 -x glm53 2>/dev/null; for i in $(seq 1 90); do pgrep -x glm53 >/dev/null || break; sleep 1; done; fi

run(){ env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close DUMP="$2" \
       "$1" --model "$M" --prompt "$PROMPT" --greedy "$N" --logits > "$3" 2>&1; }
run "$P" "$HOME/bench/hc_pristine.f32" "$HOME/bench/hc_pristine.out"
run "$Q" "$HOME/bench/hc_patched.f32"  "$HOME/bench/hc_patched.out"

echo "=== generated text ==="
if diff <(grep -v "tok/s\|token in\|experts hits\|budget\|^cache:" "$HOME/bench/hc_pristine.out") \
        <(grep -v "tok/s\|token in\|experts hits\|budget\|^cache:" "$HOME/bench/hc_patched.out") >/dev/null; then
  echo "IDENTICAL"
else
  echo "DIFFERS:"; diff <(grep -v "tok/s\|token in\|experts hits\|budget\|^cache:" "$HOME/bench/hc_pristine.out") \
                        <(grep -v "tok/s\|token in\|experts hits\|budget\|^cache:" "$HOME/bench/hc_patched.out") | head -20
fi
echo "=== logits dump ==="
ls -l "$HOME/bench/hc_pristine.f32" "$HOME/bench/hc_patched.f32" 2>/dev/null
if [ -s "$HOME/bench/hc_pristine.f32" ] && [ -s "$HOME/bench/hc_patched.f32" ]; then
  cmp -s "$HOME/bench/hc_pristine.f32" "$HOME/bench/hc_patched.f32" && echo "logits BYTE-IDENTICAL" || {
    echo "logits differ:"; python3 - <<'PY'
import numpy as np, os
a=np.fromfile(os.path.expanduser("~/bench/hc_pristine.f32"),dtype=np.float32)
b=np.fromfile(os.path.expanduser("~/bench/hc_patched.f32"),dtype=np.float32)
n=min(a.size,b.size); a,b=a[:n],b[:n]
print(f"  n={n} max_abs={np.max(np.abs(a-b)):.3e} cos={float(a@b/(np.linalg.norm(a)*np.linalg.norm(b))):.9f} argmax {int(a.argmax())} vs {int(b.argmax())}")
PY
  }
fi
