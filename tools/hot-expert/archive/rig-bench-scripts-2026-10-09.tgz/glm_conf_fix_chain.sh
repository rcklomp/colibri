#!/bin/bash
cd ~/bench && python3 ~/bench/serve_conformance_glmfix.py --arch glm --engine ~/bench/franken_bin/franken_dec_glm_cpu.ckpt
