#!/bin/bash
set -u
LOG=~/bench/x2_run.log
ATTEMPTS=0
MAX_ATTEMPTS=24   # 24 * 5 min = 2 hours of waiting for the lock
while [ $ATTEMPTS -lt $MAX_ATTEMPTS ]; do
  ATTEMPTS=$((ATTEMPTS+1))
  BEFORE=$(wc -l < "$LOG" 2>/dev/null || echo 0)
  setsid nohup ~/src/colibri-x2/tools/hot-expert/run_chain.sh \
      ~/src/colibri-x2/tools/hot-expert/x2_chain.sh >> "$LOG" 2>&1 < /dev/null &
  disown
  sleep 8
  NEWLINES=$(tail -n +$((BEFORE+1)) "$LOG" 2>/dev/null)
  if echo "$NEWLINES" | grep -q "rig_lock: REFUSED"; then
    echo "[monitor] attempt $ATTEMPTS refused, waiting 5 min"
    sleep 300
    continue
  fi
  echo "[monitor] attempt $ATTEMPTS: lock acquired, chain launched"
  break
done

if [ $ATTEMPTS -ge $MAX_ATTEMPTS ]; then
  echo "[monitor] GAVE UP after $MAX_ATTEMPTS attempts, lock never freed"
  exit 3
fi

# Now poll until the chain finishes (run_chain prints its own exit banner)
for i in $(seq 1 360); do   # 360 * 10s = 1 hour
  if grep -q "=== run_chain x2_chain exited" "$LOG" 2>/dev/null; then
    echo "[monitor] chain finished"
    break
  fi
  sleep 10
done

echo "[monitor] final log tail:"
tail -n 120 "$LOG"
