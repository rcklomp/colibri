#!/bin/bash
# P7 smoke 3: pin-block at the gate's own scale (--system ~/bench/p6_system.txt).
set -u
LOG=~/bench/p7_smoke_out; mkdir -p $LOG
export COLI_CKPT_DIR=$LOG/ckpt3; mkdir -p $COLI_CKPT_DIR; rm -f $COLI_CKPT_DIR/*.bin
S=~/src/colibri-p7
restart_gateway() {
  echo "--- restarting the gateway $(date -Is)"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 90; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
trap restart_gateway EXIT
echo "=== p7 smoke3 start $(date -Is)"
~/bench/p7_stop.sh || exit 2
timeout 2400 python3 -u $S/tools/hot-expert/ttft_serve.py --engine $S/c/glm53 \
   --pin-block --kv-slots 4 --sizes "" --repeat 0 --warm --min-resident 90 \
   --system ~/bench/p6_system.txt \
   --tag smokeB3 --json $LOG/smoke.jsonl --engine-log $LOG/engine_b3.log 2>&1
echo "smoke B3 rc=$?"
grep "^CKPT\|^REUSE" $LOG/engine_b3.log
echo "=== p7 smoke3 done $(date -Is)"
