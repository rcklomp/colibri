#!/bin/bash
# P7b: re-run ONLY the live gateway pin-block check, with the corrected
# criterion, on the candidate. p7_gate.sh already exited 0 for this binary
# (~/bench/p7_gate_p709071034) and live check A already passed through the
# gateway; only live B's threshold was miscalibrated. Twice, on purpose:
# run 1 has a COLD turn 1 (the revert emptied the checkpoint directory) and
# exercises the ttft bound; run 2's turn 1 is restored from the checkpoint
# run 1 wrote, and exercises the warm branch.
set -u
TAG=p7b$(date +%m%d%H%M)
OUT=~/bench/p7_chain_out; mkdir -p $OUT
SNAP=~/models/GLM-5.3-Flash-colibri-int4-g64
CKPT=$SNAP/.coli_ckpt
SERVED=0
PREMERGE=""

start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}

revert_and_serve_pristine() {
  echo "--- REVERTING: pristine binary, pristine tree, original serving script"
  ~/bench/p7_stop.sh
  cp ~/bench/start_glm53.sh.p7base ~/start_glm53.sh
  chmod +x ~/start_glm53.sh
  if [ -n "$PREMERGE" ]; then (cd ~/src/colibri && git reset --hard "$PREMERGE"); fi
  cp ~/bench/glm53.p7base ~/src/colibri/c/glm53 || echo "REVERT COPY FAILED"
  a=$(sha256sum ~/bench/glm53.p7base | cut -d" " -f1)
  b=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
  [ "$a" = "$b" ] || echo "REVERT FAILED: served binary is NOT the pristine one ($b)"
  rm -f $CKPT/*.bin
  start_gateway
}

on_exit() {
  rc=$?
  if [ "$SERVED" != 1 ]; then
    echo "=== chain exiting rc=$rc without a served candidate"
    pgrep -f "openai_[s]erver.py" >/dev/null || revert_and_serve_pristine
  fi
  echo "=== p7b chain done $(date -Is)"
}
trap on_exit EXIT

echo "=== p7b chain start $(date -Is) tag=$TAG"
cp ~/start_glm53.sh ~/bench/start_glm53.sh.p7base
sha256sum ~/bench/glm53.p7base ~/src/colibri/c/glm53

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2

echo "--- merging p0-sync into hot-expert-tier"
cd ~/src/colibri || exit 2
git checkout hot-expert-tier || exit 2
PREMERGE=$(git rev-parse HEAD); echo "pre-merge HEAD $PREMERGE"
git merge --no-edit p0-sync || { echo "MERGE FAILED"; exit 2; }
git log --oneline -1

echo "--- building"
make -C c glm53 VK=1 2>&1 | tail -3
[ -x ~/src/colibri/c/glm53 ] || { echo "BUILD FAILED"; exit 2; }
sha256sum ~/src/colibri/c/glm53
ls -l $CKPT

echo "--- patching the serving script (COLI_PREFIX_PIN=1, GLM53_PREFIX_CKPT=1)"
python3 - <<'PY'
import os
p = os.path.expanduser("~/start_glm53.sh"); s = open(p).read()
add = ("# P7 (2026-09-07): prefix checkpoints in the engine and the gateway-side pin.\n"
       "# The engine snapshots the shared system+tools prefix at the boundary the\n"
       "# gateway sends in the 8th SUBMIT field and persists it under\n"
       "# $M/.coli_ckpt, so a NEW conversation -- and the first request after a\n"
       "# gateway restart -- starts warm. COLI_PREFIX_PIN keeps Open WebUI's\n"
       "# <memory_context> block byte-identical for the life of a conversation\n"
       "# (with more than one memory it re-ranks every turn and turn 2 reused 0/195).\n"
       "export GLM53_PREFIX_CKPT=1\n"
       "export COLI_PREFIX_PIN=1\n")
anchor = "export COLI_REQ_LOG=1"
assert anchor in s, "anchor missing from the serving script"
assert "COLI_PREFIX_PIN" not in s, "serving script already patched"
i = s.index(anchor); j = s.index("\n", i) + 1
open(p + ".new", "w").write(s[:j] + add + s[j:])
os.chmod(p + ".new", 0o755)
os.replace(p + ".new", p)
PY
grep -n "GLM53_PREFIX_CKPT\|COLI_PREFIX_PIN\|kv-slots\|COLI_KDA_GPU=" ~/start_glm53.sh

echo "--- restarting the gateway on the candidate"
start_gateway
grep -m1 "listening\|Traceback\|ValueError" ~/glm53_server.log

echo "--- live B run 1 (cold turn 1: the ttft bound applies)"
timeout 3600 python3 -u ~/src/colibri/tools/hot-expert/ttft_serve.py \
    --url http://127.0.0.1:8081 --pin-block --system ~/bench/p6_system.txt \
    --sizes "" --repeat 0 --warm --min-resident 96 \
    --tag $TAG-live1 --json $OUT/live.jsonl 2>&1 | tee $OUT/liveB1_$TAG.log
L1=${PIPESTATUS[0]}

echo "--- live B run 2 (turn 1 now restored from the checkpoint run 1 wrote)"
timeout 3600 python3 -u ~/src/colibri/tools/hot-expert/ttft_serve.py \
    --url http://127.0.0.1:8081 --pin-block --system ~/bench/p6_system.txt \
    --sizes "" --repeat 0 --warm --min-resident 96 \
    --tag $TAG-live2 --json $OUT/live.jsonl 2>&1 | tee $OUT/liveB2_$TAG.log
L2=${PIPESTATUS[0]}

echo "--- CKPT / pin lines from the gateway log"
grep "CKPT \|\[pin\]" ~/glm53_server.log | tail -20
~/bench/owui_report.sh 10
ls -l $CKPT

echo "live B run1 rc=$L1 run2 rc=$L2"
if [ "$L1" = 0 ] && [ "$L2" = 0 ]; then
  SERVED=1
  echo "=== P7 IN SERVICE: checkpoints + pin, binary $(sha256sum ~/src/colibri/c/glm53 | cut -c1-16)"
else
  echo "=== LIVE B FAILED -- reverting"
  ~/bench/p7_stop.sh
  revert_and_serve_pristine
  exit 3
fi
