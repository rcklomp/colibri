#!/bin/bash
# P6b chain: merge p0-sync, build, run p6b_gate.sh, and serve the candidate at
# --kv-slots 4 with COLI_KDA_GPU=2 only if the gate exits 0 AND the live check
# (the gate's own step 4) passes. Structure is p7_chain.sh's: back up the
# serving script, patch it, restart, check, revert on failure -- and put a
# working gateway back on EVERY exit path, because it is the owner's daily
# service.
set -u
TAG=p6b$(date +%m%d%H%M)
OUT=~/bench/p6b_chain_out; mkdir -p $OUT
SERVED=0
GATEDIR=""

start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}

PREMERGE=""
revert_and_serve_pristine() {
  echo "--- REVERTING: pristine binary (P7, 19e28e72…), pristine tree, original serving script"
  # Stop EVERYTHING first: a leftover engine from a gate step holds the binary
  # open, `cp` fails with ETXTBSY, and the revert silently leaves the CANDIDATE
  # in service. That happened on 2026-09-07 (P7) and is why this verifies.
  ~/bench/p7_stop.sh
  cp ~/bench/start_glm53.sh.p6bbase ~/start_glm53.sh
  chmod +x ~/start_glm53.sh
  if [ -n "$PREMERGE" ]; then (cd ~/src/colibri && git reset --hard "$PREMERGE"); fi
  cp ~/bench/glm53.p6bbase ~/src/colibri/c/glm53 || echo "REVERT COPY FAILED"
  a=$(sha256sum ~/bench/glm53.p6bbase | cut -d" " -f1)
  b=$(sha256sum ~/src/colibri/c/glm53 | cut -d" " -f1)
  if [ "$a" != "$b" ]; then echo "REVERT FAILED: served binary is NOT the pristine one ($b)"; else
    echo "revert verified: $b"; fi
  start_gateway
}

on_exit() {
  rc=$?
  if [ "$SERVED" != 1 ]; then
    echo "=== chain exiting rc=$rc without a served candidate"
    if ! pgrep -f "openai_[s]erver.py" >/dev/null; then revert_and_serve_pristine; fi
  fi
  echo "=== p6b chain done $(date -Is)"
}
trap on_exit EXIT

echo "=== p6b chain start $(date -Is) tag=$TAG"
cp ~/start_glm53.sh ~/bench/start_glm53.sh.p6bbase
sha256sum ~/bench/glm53.p6bbase ~/src/colibri/c/glm53

echo "--- stopping the gateway"
~/bench/p7_stop.sh || exit 2

echo "--- merging p0-sync into hot-expert-tier"
cd ~/src/colibri || exit 2
git checkout hot-expert-tier || exit 2
PREMERGE=$(git rev-parse HEAD); echo "pre-merge HEAD $PREMERGE"
git merge --no-edit p0-sync || { echo "MERGE FAILED"; exit 2; }
git log --oneline -1

echo "--- building"
make -C c glm53 VK=1 2>&1 | tail -3
[ -x ~/src/colibri/c/glm53 ] || { echo "BUILD FAILED"; exit 2; }
sha256sum ~/src/colibri/c/glm53

echo "--- p6b_gate.sh steps 1,2,3,5,6 (step 4 needs a gateway and runs after serving)"
GATE_STEPS=${GATE_STEPS:-12356} GATE_TOOLS=${GATE_TOOLS:-~/bench/owui_tools.json} \
  bash ~/src/colibri/tools/hot-expert/p6b_gate.sh \
       ~/bench/glm53.p6bbase ~/src/colibri/c/glm53 $TAG 2>&1 | tee $OUT/gate_$TAG.log
GATE=${PIPESTATUS[0]}
GATEDIR=~/bench/p6b_gate_$TAG
echo "GATE rc=$GATE"
if [ "$GATE" != 0 ]; then
  echo "GATE FAILED ($GATE) -- pristine stays in service"
  revert_and_serve_pristine
  exit $GATE
fi

echo "--- patching the serving script (--kv-slots 4, COLI_KDA_GPU=2)"
python3 - <<'PY'
import os, re
p = os.path.expanduser("~/start_glm53.sh"); s = open(p).read()
assert "--kv-slots 8" in s, "expected --kv-slots 8 in the serving script"
assert "export COLI_KDA_GPU=0" in s, "expected COLI_KDA_GPU=0 in the serving script"
assert "GLM53_PREFIX_CKPT=1" in s and "COLI_PREFIX_PIN=1" in s, "P7 knobs missing"
s = s.replace("--kv-slots 8", "--kv-slots 4")
s = s.replace(
  "export COLI_KDA_GPU=0   # P6: 4 slots need the CPU recurrence until P6b (the engine forces 0 anyway)",
  "# P6b (2026-09-07): the engine allocates ONE KDA state set per KV slot on dev0,\n"
  "# before the expert preload, so slots no longer share a recurrence and the CPU\n"
  "# fallback is gone. 4 slots x 156 MB = 625 MB of dev0, paid in the coldest ~44\n"
  "# of its 1 296 preloaded experts; it buys back the ~10 % decode / ~5 % prefill\n"
  "# P6 gave up. --kv-slots is 4, not 8, because that is the pool the gate measured\n"
  "# and because 8 would cost 88 experts for slots Open WebUI does not use.\n"
  "# If the pool ever comes up short the engine says so and forces 0 by itself.\n"
  "export COLI_KDA_GPU=2   # P6b: per-slot device state (was 0 from P6, 2026-09-06)")
open(p + ".new", "w").write(s)
os.chmod(p + ".new", 0o755)
os.replace(p + ".new", p)
PY
grep -n "GLM53_PREFIX_CKPT\|COLI_PREFIX_PIN\|kv-slots\|COLI_KDA_GPU=" ~/start_glm53.sh

echo "--- restarting the gateway on the candidate"
start_gateway
grep -m1 "listening\|Traceback\|ValueError" ~/glm53_server.log
echo "--- the engine's own lines about the pool and the slots"
grep -E "KDA slot pool|KV_SLOTS=|preload: [0-9]+ heat-ranked" ~/glm53_server.log | head -5

echo "--- live check: p6b_gate.sh step 4 against the serving gateway"
GATE_STEPS=4 P6B_URL=http://127.0.0.1:8081 \
  bash ~/src/colibri/tools/hot-expert/p6b_gate.sh \
       ~/bench/glm53.p6bbase ~/src/colibri/c/glm53 $TAG 2>&1 | tee $OUT/live_$TAG.log
LIVE=${PIPESTATUS[0]}

echo "--- REUSE / pool / forcing lines from the gateway log"
grep -E "REUSE|KDA slot pool|forcing COLI_KDA_GPU" ~/glm53_server.log | tail -20
~/bench/owui_report.sh 12

echo "live rc=$LIVE"
if [ "$LIVE" = 0 ]; then
  SERVED=1
  echo "=== P6b IN SERVICE: 4 slots, COLI_KDA_GPU=2, binary $(sha256sum ~/src/colibri/c/glm53 | cut -c1-16)"
  echo "=== gate outputs in $GATEDIR"
else
  echo "=== LIVE CHECK FAILED -- reverting"
  revert_and_serve_pristine
  exit 3
fi
