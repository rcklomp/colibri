#!/bin/bash
# P6 end-to-end: the multiturn+side-request case through the LIVE gateway (HTTP, the user path), after p4c restarts it with 4 slots.
while pgrep -f "p4c_[c]hain.sh" >/dev/null; do sleep 30; done
sleep 100   # engine load after the restart
echo "=== p6http start $(date -Is)"; cd ~/src/colibri
grep -c "kv-slots 4" ~/start_glm53.sh; ps -o args -p $(pgrep -f "openai_[s]erver.py" | head -1) | tail -1 | grep -o "kv-slots [0-9]*"
python3 tools/hot-expert/ttft_serve.py --url http://127.0.0.1:8081 --sizes 300 --repeat 0 --multiturn --side-request --system ~/bench/p6_system.txt --min-resident 90 --tag p6http --json ~/bench/ttft_p6.jsonl 2>&1 | grep "^turn\|^side\|^regen\|^multiturn\|REFUSED\|Traceback\|Error"
echo "--- REUSE lines from the gateway log:"; grep "^REUSE" ~/glm53_server.log | tail -6
echo "=== p6http done $(date -Is)"
