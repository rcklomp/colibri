#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
G=/home/ronald/models/GLM-5.3-Flash-colibri-int4-g64
P="$(cat ~/bench/prompt_glm.txt)"
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "warm GLM"; cat $G/*.safetensors > /dev/null
fincore --bytes --noheadings $G/*.safetensors | awk '{r+=$1} END {printf "resident %.1f GiB\n", r/2^30}'
VK="COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_EXPERTS2=100000 COLI_VK_DEV3=auto COLI_VK_EXPERTS3=100000 COLI_VK_SHADERS=shaders COLI_USAGE_PATH=/home/ronald/.glm53_explain.bin"
for r in 1 2; do
  log "GLM 3-GPU, explain histogram, run $r"
  env $VK /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_repro_gpu_$r.log 2>&1; echo "rc=$?"
  grep -E "preload|denso|decode |teacher|caricamento|Major|experts hits" ~/bench/glm_repro_gpu_$r.log | cut -c1-140
done
log "GLM CPU-only, warm"
/usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_repro_cpu.log 2>&1; echo "rc=$?"
grep -E "decode |teacher|caricamento|Major|experts hits" ~/bench/glm_repro_cpu.log | cut -c1-140
log "glm repro done"
