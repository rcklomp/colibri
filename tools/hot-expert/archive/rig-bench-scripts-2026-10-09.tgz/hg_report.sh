#!/bin/bash
sed -n '/=== hgblk start/,$p' ~/bench/glm_seq_hg.log 2>/dev/null | grep -vE "^run_chain|^$|^oracle |chain exit" | cut -c1-200 | head -60
