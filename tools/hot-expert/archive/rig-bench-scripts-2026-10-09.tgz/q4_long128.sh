#!/bin/bash
# Q4 extra diagnostic, NOT a gate leg: the 128-token greedy continuation after
# the LONG (~1200-position) prompt, where the reassociation has accumulated
# through 1200 positions of KV cache and the last-token relL2 is 1.5e-3 rather
# than the short prompt's 2.2e-6. §G15's note says greedy text on a chaotic
# long prompt is an ambiguous oracle -- this is run to report the fact, not to
# decide the item, whose gate is the SHORT-prompt 128-token text (met).
set -u
SRC=~/src/colibri; WT=~/src/colibri-q4
OUT=~/bench/q4_out; mkdir -p "$OUT"
QSNAP=~/models/Qwen3.8-Flash-Next-FP8
PRIS=~/bench/qwen38-vk.q4base
CAND="$WT/c/qwen38-vk"
HIST_SRC="$QSNAP/.coli_usage"
GATEWAY_UP=0
log(){ echo "[$(date -Is)] $*"; }
. "$SRC/tools/hot-expert/rig_lock.sh"
wait_no_engine(){ for _ in $(seq 1 240); do pgrep -x "$1" >/dev/null || return 0; sleep 1; done; return 1; }
kill_bench_engines(){ pkill -9 -f "bench/qwen38-[v]k\." 2>/dev/null; true; }
start_gateway(){
  log "restarting the gateway"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  for _ in $(seq 1 90); do pgrep -f "openai_[s]erver.py" >/dev/null && pgrep -x glm53 >/dev/null && break; sleep 10; done
  log "gateway: server=$(pgrep -f "openai_[s]erver.py" | wc -l) engine=$(pgrep -x glm53 | wc -l)"
  GATEWAY_UP=1
}
on_exit(){ rc=$?; log "=== long128 exiting rc=$rc"
  pkill -9 -x qwen38-vk 2>/dev/null; kill_bench_engines; wait_no_engine qwen38-vk
  python3 - <<'PY' || true
import sys, os
sys.path.insert(0, os.path.expanduser("~/src/colibri/c/tools"))
import datapoint
print("evict_cache(Qwen) ->", datapoint.evict_cache(247.0, snap_dir=os.path.expanduser("~/models/Qwen3.8-Flash-Next-FP8")))
PY
  [ "$GATEWAY_UP" = 1 ] || start_gateway
  rig_lock_release; log "=== long128 done"; }
trap on_exit EXIT INT TERM HUP
rig_lock_take "q4-long128" || { echo "rig busy"; exit 3; }
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
if pgrep -x glm53 >/dev/null; then
  log "stopping the owner's gateway"; pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53
  wait_no_engine glm53 || { log "REFUSED: glm53 would not die"; exit 1; }
fi
python3 - <<'PY'
import sys, os
sys.path.insert(0, os.path.expanduser("~/src/colibri/c/tools"))
import datapoint
print("evict_cache(GLM) ->", datapoint.evict_cache(247.0, snap_dir=os.path.expanduser("~/models/GLM-5.3-Flash-colibri-int4-g64")))
PY
warm(){ find "$QSNAP" -type f -name "*.safetensors" -print0 | while IFS= read -r -d '' f; do cat "$f" >/dev/null; done; }
log "warming Qwen"; warm
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
export Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS="$SRC/c/shaders"
LONG=/tmp/q4_prompt_long.txt
run(){ local bin="$1" tag="$2"; shift 2
  cp -f "$HIST_SRC" /tmp/q4_hist.bin
  log "--- $tag $*"
  env SNAP="$QSNAP" COLI_USAGE=/tmp/q4_hist.bin N_NEW=128 NOSTREAM=1 \
      Q38_TF=1 Q38_TF_DUMP="$OUT/$tag.tf.f32" DUMP="$OUT/$tag.last.f32" \
      "$@" "$bin" 512 8 "$LONG" > "$OUT/$tag.log" 2>&1
  log "  rc=$?"; grep -E "^Speed:|Expert cache hit rate" "$OUT/$tag.log" | sed 's/^/  /'; }
run "$PRIS" l128-A1
run "$CAND" l128-A3 Q38_BF16_ACC4=1
python3 "$WT/tools/hot-expert/qp_compare.py" "$OUT" "l128-A1" "l128-A3" "LONG prompt, 128 greedy tokens -- DIAGNOSTIC, not a gate leg"
