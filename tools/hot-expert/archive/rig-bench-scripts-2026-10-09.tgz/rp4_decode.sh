#!/bin/bash
# RP4 addendum: one DECODE run with the timestamps on, so the "what would a
# faster expert shader buy?" question is sized for decode too and not only for
# prefill. Short prompt (21 tokens), 64 greedy tokens -- decode dominates the
# [VKTS] totals. Stops the gateway, runs, restarts it. ~8 min of downtime.
set -u
TAG=rp4dec$(date +%H%M)
OUT=~/bench/rp4_chain_out; mkdir -p $OUT
M=$HOME/models/GLM-5.3-Flash-colibri-int4-g64

start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
trap 'pgrep -f "openai_[s]erver.py" >/dev/null || start_gateway; echo "=== rp4 decode done $(date -Is)"' EXIT

echo "=== rp4 decode addendum $(date -Is) tag=$TAG"
~/bench/p7_stop.sh || exit 2
for _ in $(seq 1 180); do pgrep -x glm53 >/dev/null || break; sleep 1; done

export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
export COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto
export COLI_VK_SHADERS=$HOME/src/colibri/c/shaders
export COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695
export COLI_KDA_GPU=2 COLI_TIMERS=1 GLM53_VERBOSE=1
cp ~/.glm53_explain.bin /tmp/rp4dec_hist.bin; export COLI_USAGE_PATH=/tmp/rp4dec_hist.bin
P="Explain in three sentences why a gated delta rule needs a decay term."
for lv in 1 2; do
  echo "--- decode run, COLI_VK_TIMESTAMPS=$lv"
  COLI_VK_TIMESTAMPS=$lv ~/src/colibri/c/glm53 --model "$M" --prompt "$P" --greedy 64 --logits 512 \
    > $OUT/decode_lvl$lv.txt 2>&1
  echo "  rc=$?"
  grep -E "^\[OPTIME\]|^\[PROF\]|^\[VKTS|decode .* token in|prefill .* token in" $OUT/decode_lvl$lv.txt | cut -c1-220
done
