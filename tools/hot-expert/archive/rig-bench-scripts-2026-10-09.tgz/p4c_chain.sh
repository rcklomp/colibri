#!/bin/bash
# P4c: v3 tile shaders + backend I%8 gate. Waits for p6ev. Pristine = binary + shaders in service.
while pgrep -f "p6ev_[c]hain.sh" >/dev/null || pgrep -f "p4b_[c]hain.sh" >/dev/null; do sleep 30; done
echo "=== p4c chain start $(date -Is)"; cd ~/src/colibri
rm -rf ~/bench/shaders_p4c_base; cp -r c/shaders ~/bench/shaders_p4c_base; cp c/glm53 ~/bench/glm53.p4c_base; md5sum ~/bench/glm53.p4c_base
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engines: $(pgrep -x glm53 | wc -l)"
git merge -q --ff-only p0-sync && git branch -q -D p0-sync; git log --oneline -1
make -C c shaders/qmatmul_tile.spv shaders/qmatmul_gate_up_tile.spv VK=1 2>&1 | grep -E "error" | head -3
make -C c glm53 VK=1 2>&1 | grep -E "error|warning: unused"; md5sum c/glm53; ls -la c/shaders/*tile.spv | cut -c25-
echo "=== gate $(date -Is)"
PRISTINE_SHADERS=~/bench/shaders_p4c_base MIN_SPEEDUP=1.0 tools/hot-expert/prefill_gate.sh ~/bench/glm53.p4c_base ~/src/colibri/c/glm53 p4c
GATE=$?
echo "=== gate rc=$GATE $(date -Is)"
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto
export COLI_VK_SHADERS=$HOME/src/colibri/c/shaders COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695 COLI_KDA_GPU=2 GLM53_VERBOSE=1
cp ~/.glm53_explain.bin /tmp/p4c_hist.bin; export COLI_USAGE_PATH=/tmp/p4c_hist.bin
python3 tools/hot-expert/tworeq.py 2>&1 | grep -v "^\[VK\]\|^cache:" | tail -3
TWO=${PIPESTATUS[0]}
echo "=== tworeq rc=$TWO $(date -Is)"
pkill -9 -x glm53 2>/dev/null; sleep 2
if [ "$GATE" = 0 ] && [ "$TWO" = 0 ]; then echo "SERVING THE CANDIDATE (v3 shaders)"; else echo "GATE FAILED ($GATE/$TWO): restoring base binary + shaders"; cp ~/bench/glm53.p4c_base c/glm53; cp ~/bench/shaders_p4c_base/*.spv c/shaders/; fi
md5sum c/glm53 | cut -c1-12; md5sum c/shaders/qmatmul_tile.spv | cut -c1-12
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p4c chain done $(date -Is)"
