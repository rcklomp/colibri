#!/bin/bash
# m2_chain.sh -- run the M2 expert histograms with the cards empty:
# stop the gateway (under run_chain's lock), run m5_bench, restart, accept_live.
set -u
HERE=~/src/colibri/tools/hot-expert
KEY=$(cat ~/.colibri_api_key); GLOG=~/glm53_server.log
engine_alive() { ps -C glm53 -o stat= 2>/dev/null | grep -qv '^Z'; }
wait_no_glm53() { for _ in $(seq 1 120); do engine_alive || return 0; sleep 2; done; echo "glm53 still alive after 240 s"; return 1; }
start_gateway() {
  env -u COLI_CKPT_DIR -u GLM53_PREFIX_CKPT SKIP_WARM=1 setsid nohup ~/start_glm53.sh >> "$GLOG" 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -H "Authorization: Bearer $KEY" -w '%{http_code}' http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && break
    sleep 5
  done
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(engine_alive && echo 1 || echo 0)"
}
stop_gateway() {
  pkill -f "openai_[s]erver.py" 2>/dev/null || true
  for _ in $(seq 1 10); do pgrep -f "openai_[s]erver.py" >/dev/null || break; sleep 1; done
  pkill -9 -f "openai_[s]erver.py" 2>/dev/null || true
  pkill -9 -x glm53 2>/dev/null || true
  wait_no_glm53
}
on_exit() {
  rc=$?; trap - EXIT INT TERM HUP
  if pgrep -f "openai_[s]erver.py" >/dev/null && engine_alive; then echo "gateway already in service"; else stop_gateway; start_gateway; fi
  echo "=== m2_chain exit rc=$rc $(date -Is)"
  "$HERE/accept_live.sh"; a=$?; echo "--- accept_live exit=$a"; [ "$rc" -eq 0 ] && rc=$a; exit "$rc"
}
trap on_exit EXIT INT TERM HUP
echo "=== m2_chain start $(date -Is)"
stop_gateway || exit 1
sleep 5
for d in /sys/class/drm/card[0-9]/device; do echo "vram_used_before=$(( $(cat $d/mem_info_vram_used) / 1048576 )) MiB"; done
mkdir -p ~/bench/m2; rc=0
echo "=== M2 deepseek $(date -Is)"; /home/ronald/src/colibri-m1/tools/hot-expert/franken/run_moe_hist.sh /home/ronald/models/DeepSeek-V4-Flash-0731-UD-IQ2_M/UD-IQ2_M/$(ls /home/ronald/models/DeepSeek-V4-Flash-0731-UD-IQ2_M/UD-IQ2_M | head -1) /home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md ~/bench/m2/deepseek > ~/bench/m2/deepseek.log 2>&1; echo "deepseek rc=$?"
echo "=== M2 glm $(date -Is)"; /home/ronald/src/colibri-m1/tools/hot-expert/franken/run_moe_hist.sh /home/ronald/models/GLM-5.3-Flash/UD-IQ4_XS/$(ls /home/ronald/models/GLM-5.3-Flash/UD-IQ4_XS | grep 00001 | head -1) /home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md ~/bench/m2/glm > ~/bench/m2/glm.log 2>&1; echo "glm rc=$?"

echo "=== m2 done"
exit $rc
