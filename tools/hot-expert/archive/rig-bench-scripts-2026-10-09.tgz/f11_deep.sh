#!/bin/bash
# F11 depth rungs, Qwen3.8-Flash-Next only: nominal 16k/32k/64k/128k/224k
# (real ~5 % more), two arms, no cold sweep. Then, AFTER the chain and its
# trap have exited, the owner s path is checked once more.
export F11_ONLY=Q F11_SKIP_SWEEP=1 F11_LADDER_TIMEOUT=14400
export F11_STEPS=16384,16384,32768,65536,98304
echo "=== f11_deep: launching $(date -Is)"
~/src/colibri/tools/hot-expert/run_chain.sh ~/src/colibri/tools/hot-expert/f11_ladder_chain.sh > ~/bench/f11_deep_ladder.log 2>&1
echo "=== f11_deep: run_chain rc=$? $(date -Is)"
sleep 90
~/src/colibri/tools/hot-expert/accept_live.sh
echo "=== f11_deep: post-exit accept_live rc=$? engine: $(ps -C glm53 -o pid=,stat= | tr "\n" " ")"
