#!/bin/bash
# Q7 step 0: the fmt=9 BF16 microbenchmark, BEFORE any engine dispatch exists.
# Spec: tools/hot-expert/Q7-DENSE-GPU-SPEC-2026-09-12.md "Step 0".
# Rig lock held, gateway stopped (it holds dev0 VRAM and the queue), no engine.
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q7-step0" 120 || exit 3
stop_gateway || exit 1
log "tree: $(git -C $WT log --oneline -1)"
q7_build_shader || { log "shader build failed"; exit 1; }
# -march=native: the accuracy leg compares the GPU against the engine kernel that
# actually ships, which is the AVX2+FMA arm of q38_matmul_bf16.
gcc -O2 -march=native -fopenmp -I"$WT/c" -o /tmp/q7_vkbench \
    "$WT/tools/hot-expert/rome_vkbench.c" "$WT/c/backend_vulkan.o" -lvulkan -lm \
  || { log "vkbench build failed"; exit 1; }
for r in 1 2; do
  log "--- rome_vkbench q7 repeat $r"
  /tmp/q7_vkbench "$WT/c/shaders/qmatmul.spv" q7 2>&1 | tee "$OUT/vkbench-q7-$r.log"
done
log "step0 measured"
