#!/usr/bin/env python3
"""Aggregate the P5 chain's per-bucket profile runs into one table."""
import glob, os, re, statistics as st, sys

OUT = os.path.expanduser("~/bench/p5_chain_out")
BUCKETS = ["TOTAL prefill", "layers", "ffn_moe", "  cpu experts", "  eg (gpu)",
           "  router", "  shared", "kda", "  kda.proj", "  kda.step", "  kda.ko",
           "mla", "  mla.attn", "hc+norm", "head"]


def parse(path):
    txt = open(path, errors="replace").read()
    m = re.search(r"(\d+) prompt tokens in ([\d.]+)s", txt)
    if not m:
        return None
    out = {"_N": int(m.group(1)), "_T": float(m.group(2))}
    for line in txt.splitlines():
        mm = re.match(r"^(\S.*?|\s\s\S.*?)\s{2,}([\d.]+)\s+(\d+)%$", line)
        if mm and mm.group(1).strip():
            name = mm.group(1).rstrip()
            if name in BUCKETS:
                out[name] = float(mm.group(2))
    return out


def group(pattern):
    runs = [parse(p) for p in sorted(glob.glob(os.path.join(OUT, pattern)))]
    runs = [r for r in runs if r]
    if not runs:
        return None
    g = {"_n": len(runs), "_T": st.median(r["_T"] for r in runs),
         "_N": runs[0]["_N"], "_Ts": [r["_T"] for r in runs]}
    for b in BUCKETS:
        v = [r[b] for r in runs if b in r]
        if v:
            g[b] = st.median(v)
    return g


def table(title, cols):
    got = [(n, group(p)) for n, p in cols]
    got = [(n, g) for n, g in got if g]
    if not got:
        print(f"\n{title}: no runs\n")
        return
    print(f"\n### {title}")
    print("prompt tokens: %d" % got[0][1]["_N"])
    hdr = "| bucket | " + " | ".join(n for n, _ in got) + " |"
    print(hdr)
    print("|---|" + "---:|" * len(got))
    for b in BUCKETS:
        row = [("%.1f" % g[b]) if b in g else "-" for _, g in got]
        print("| %s | %s |" % (b.strip() if b.startswith("  ") else "**%s**" % b,
                               " | ".join(row)))
    print("| _wall (s)_ | %s |" % " | ".join(
        "%.1f (%s)" % (g["_T"], "/".join("%.1f" % t for t in g["_Ts"])) for _, g in got))
    base = got[0][1]["_T"]
    print("| _speedup vs %s_ | %s |" % (got[0][0],
          " | ".join("%.2fx" % (base / g["_T"]) for _, g in got)))


table("600-token prompt, serving knob (COLI_KDA_GPU=2), chunk 128, cap 512",
      [("pristine", "prof_600_pristine_r*.txt"),
       ("knobs off", "prof_600_off_r*.txt"),
       ("+P5.1", "prof_600_p1.txt"),
       ("+P5.1+P5.2", "prof_600_p12.txt"),
       ("all on", "prof_600_on_r*.txt")])

table("3 000-token prompt, serving knob",
      [("pristine", "prof_3000_pristine.txt"),
       ("knobs off", "prof_3000_off_r*.txt"),
       ("all on", "prof_3000_on_r*.txt")])
