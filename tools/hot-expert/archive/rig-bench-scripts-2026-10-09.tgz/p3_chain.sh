#!/bin/bash
# P3 gate chain: candidate = P3 on top of P2; pristine for this gate = the P2 binary in service.
echo "=== p3 chain start $(date -Is)"; cd ~/src/colibri
cp c/glm53 ~/bench/glm53.p2; md5sum ~/bench/glm53.p2
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engines: $(pgrep -x glm53 | wc -l)"
git merge -q --ff-only p0-sync && git branch -q -D p0-sync; git log --oneline -1
make -C c glm53 VK=1 2>&1 | grep -E "error|warning: unused"; md5sum c/glm53
echo "=== gate $(date -Is)"
MIN_SPEEDUP=1.0 tools/hot-expert/prefill_gate.sh ~/bench/glm53.p2 ~/src/colibri/c/glm53 p3
GATE=$?
echo "=== gate rc=$GATE $(date -Is)"
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto
export COLI_VK_SHADERS=$HOME/src/colibri/c/shaders COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695 COLI_KDA_GPU=2 GLM53_VERBOSE=1
cp ~/.glm53_explain.bin /tmp/p3_hist.bin; export COLI_USAGE_PATH=/tmp/p3_hist.bin
python3 tools/hot-expert/tworeq.py 2>&1 | grep -v "^\[VK\]\|^cache:" | tail -3
TWO=${PIPESTATUS[0]}
echo "=== tworeq rc=$TWO $(date -Is)"
pkill -9 -x glm53 2>/dev/null; sleep 2
if [ "$GATE" = 0 ] && [ "$TWO" = 0 ]; then echo "SERVING THE CANDIDATE"; else echo "GATE FAILED ($GATE/$TWO): serving the P2 binary"; cp ~/bench/glm53.p2 c/glm53; fi
md5sum c/glm53
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p3 chain done $(date -Is)"
