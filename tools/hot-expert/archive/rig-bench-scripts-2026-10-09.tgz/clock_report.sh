#!/bin/bash
# what the root clock test produced: the two settings against the earlier default-profile run
echo "##### clock_test log"; grep -aE "^===|saved|peak set|compute set|restor|rc=|arm " ~/bench/clock_test.log 2>/dev/null | cut -c1-170 | tail -14
for t in peak compute; do
  L=~/bench/glm_skipclock_chain_$t.log
  echo "##### setting: $t"
  grep -aE "^power state|prefill ms/token|^m[0-9]+_[ab] " $L 2>/dev/null | cut -c1-120
  echo "--- sampler (a arms; card2 = the lone link)"
  grep -aE "^m(31|29|30|0)_a +card" $L 2>/dev/null | cut -c1-150
done
echo "##### earlier DEFAULT profile (record §M7-SKIPCLASS): m31 3.686/3.733  m29 5.976/6.061  m30 7.075/7.149  m0 9.138/9.168 ms/token"
