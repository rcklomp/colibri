#!/bin/bash
# Q9 A/B: the tier gate on the TOTAL (today) vs PER-DEVICE (candidate), both at
# Q38_PREFILL_BATCH=1. Same invocation q9_probe.sh uses, warmed once, both arms
# back to back so residency is identical. Reports [OPTIME] placement for each.
set -u
QSNAP=~/models/Qwen3.8-Flash-Next-FP8
BASE=~/bench/q9base/c/qwen38-vk
CAND=~/bench/q9/c/qwen38-vk
SH=~/bench/q9/c/shaders
OUT=~/bench/q9ab; mkdir -p "$OUT"; LOG=~/bench/q9_ab.log
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q9-ab" 120 || exit 3
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
stop_gateway || exit 1

P=/tmp/q9ab_prompt.txt
python3 -c "print((open('$HOME/bench/prompt_glm.txt').read().strip()+' ')*6)" > "$P"
echo "=== q9_ab $(date -Is) ===" | tee "$LOG"
echo "prompt bytes: $(stat -c%s $P)" | tee -a "$LOG"

warm(){ find "$QSNAP" -type f -name "*.safetensors" -print0 | while IFS= read -r -d '' f; do cat "$f" >/dev/null; done; }
echo "warming Qwen (173 GiB)..." | tee -a "$LOG"; warm

run(){ # run <label> <bin>
  cp -f "$QSNAP/.coli_usage" /tmp/q9ab_hist.bin
  local t0=$(date +%s)
  env SNAP="$QSNAP" COLI_USAGE=/tmp/q9ab_hist.bin N_NEW=1 NOSTREAM=1 \
      Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS="$SH" \
      Q38_PREFILL_BATCH=1 OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close \
      "$2" 512 8 "$P" > "$OUT/$1.log" 2>&1
  local rc=$?
  echo "--- $1  rc=$rc wall=$(( $(date +%s) - t0 ))s" | tee -a "$LOG"
  [ $rc -eq 0 ] || { tail -20 "$OUT/$1.log" | tee -a "$LOG"; return 1; }
  grep -E "OPTIME. placement|Vulkan tier" "$OUT/$1.log" | sed 's/^/  /' | tee -a "$LOG"
}
run base "$BASE" || exit 1
run cand "$CAND" || exit 1
echo "--- oracle (greedy text must not move) ---" | tee -a "$LOG"
if diff <(grep -v "OPTIME\|placement\|ms\b\|wall\|resident" "$OUT/base.log") \
        <(grep -v "OPTIME\|placement\|ms\b\|wall\|resident" "$OUT/cand.log") >/dev/null; then
  echo "  output: IDENTICAL" | tee -a "$LOG"
else
  echo "  output: DIFFERS" | tee -a "$LOG"
  diff <(grep -v "OPTIME\|placement\|ms\b\|wall\|resident" "$OUT/base.log") \
       <(grep -v "OPTIME\|placement\|ms\b\|wall\|resident" "$OUT/cand.log") | head -15 | tee -a "$LOG"
fi
echo "=== done ===" | tee -a "$LOG"
