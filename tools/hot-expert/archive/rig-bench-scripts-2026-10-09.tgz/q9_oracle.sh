#!/bin/bash
# Q9 remaining gate leg: the real numerics oracle. Q38_TF=1 prints
# teacher_forcing (argmax at every prompt position); Q38_TF_DUMP writes that
# position's full logit row as raw f32. Both arms, same prompt, Q38_PREFILL_BATCH=1.
set -u
QSNAP=~/models/Qwen3.8-Flash-Next-FP8
BASE=~/bench/q9base/c/qwen38-vk; CAND=~/bench/q9/c/qwen38-vk
SH=~/bench/q9/c/shaders; OUT=~/bench/q9or; mkdir -p "$OUT"; LOG=~/bench/q9_oracle.log
. /home/ronald/bench/q7_lib.sh
trap q7_on_exit EXIT INT TERM HUP
q7_take_lock "q9-oracle" 120 || exit 3
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
stop_gateway || exit 1
P=/tmp/q9or_prompt.txt
python3 -c "print((open('$HOME/bench/prompt_glm.txt').read().strip()+' ')*6)" > "$P"
echo "=== q9_oracle $(date -Is) ===" | tee "$LOG"
find "$QSNAP" -type f -name "*.safetensors" -print0 | while IFS= read -r -d '' f; do cat "$f" >/dev/null; done
run(){ cp -f "$QSNAP/.coli_usage" /tmp/q9or_hist.bin
  env SNAP="$QSNAP" COLI_USAGE=/tmp/q9or_hist.bin N_NEW=1 NOSTREAM=1 \
      Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS="$SH" \
      Q38_PREFILL_BATCH=1 Q38_TF=1 Q38_TF_DUMP="$OUT/$1.f32" \
      OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close \
      "$2" 512 8 "$P" > "$OUT/$1.log" 2>&1
  echo "--- $1 rc=$? tf_len=$(grep -c '^teacher_forcing' "$OUT/$1.log") dump=$(stat -c%s "$OUT/$1.f32" 2>/dev/null || echo 0)B" | tee -a "$LOG"; }
run base "$BASE"; run cand "$CAND"
echo "--- ORACLE ---" | tee -a "$LOG"
bt=$(grep -c '^teacher_forcing' "$OUT/base.log"); ct=$(grep -c '^teacher_forcing' "$OUT/cand.log")
if [ "$bt" -lt 1 ] || [ "$ct" -lt 1 ]; then
  echo "  REFUSED: no teacher_forcing line in one or both arms (base=$bt cand=$ct) -- NOT a pass" | tee -a "$LOG"
else
  diff <(grep '^teacher_forcing' "$OUT/base.log") <(grep '^teacher_forcing' "$OUT/cand.log") >/dev/null \
    && echo "  teacher_forcing: IDENTICAL ($bt line(s))" | tee -a "$LOG" \
    || { echo "  teacher_forcing: DIFFERS" | tee -a "$LOG"
         python3 - "$OUT" <<'PY' | tee -a "$LOG"
import sys,os
b=open(os.path.join(sys.argv[1],"base.log")).read().split("teacher_forcing")[1].split("\n")[0].split()
c=open(os.path.join(sys.argv[1],"cand.log")).read().split("teacher_forcing")[1].split("\n")[0].split()
n=min(len(b),len(c)); d=sum(1 for i in range(n) if b[i]!=c[i])
print(f"    {d} of {n} positions differ")
PY
       }
fi
if [ -s "$OUT/base.f32" ] && [ -s "$OUT/cand.f32" ]; then
  cmp -s "$OUT/base.f32" "$OUT/cand.f32" && echo "  logits: BYTE-IDENTICAL" | tee -a "$LOG" || {
    python3 - "$OUT" <<'PY' | tee -a "$LOG"
import sys,os,struct,math
def rd(p):
    d=open(p,'rb').read(); return list(struct.unpack('<%df'%(len(d)//4), d[:len(d)//4*4]))
a=rd(os.path.join(sys.argv[1],"base.f32")); b=rd(os.path.join(sys.argv[1],"cand.f32"))
n=min(len(a),len(b)); a,b=a[:n],b[:n]
dot=sum(x*y for x,y in zip(a,b)); na=math.sqrt(sum(x*x for x in a)); nb=math.sqrt(sum(x*x for x in b))
print(f"  logits: max_abs={max(abs(x-y) for x,y in zip(a,b)):.3e} cos={dot/(na*nb):.9f} argmax {a.index(max(a))} vs {b.index(max(b))}")
PY
  }
else echo "  logits: NO DUMP WRITTEN -- oracle incomplete" | tee -a "$LOG"; fi
echo "=== done ===" | tee -a "$LOG"
