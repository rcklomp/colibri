#!/bin/bash
# Real GLM-5.3 measurement at 65,527 tokens, take 3: prefill_profile.sh's
# standalone CLI cannot take this prompt at all ("Argument list too long" --
# a real execve() E2BIG passing 206KB as a single argv element, not an
# engine bug). Route through the LIVE gateway's JSON API instead (already
# proven to accept this exact prompt), with COLI_TIMERS=1 exported before
# the gateway starts so the same [OPTIME]/[PROF] lines land in
# glm53_server.log. Let the request run to real completion this time (a
# short generation afterward) so decode throughput at this context is also
# captured in the same request.
set -u
cd /home/ronald/src/colibri || exit 1
. tools/hot-expert/rig_lock.sh

LOG=/home/ronald/bench/context_65527_v2.log
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

echo "[$(date -Is)] start"

wait_no_engine() {
  for _ in $(seq 1 180); do pgrep -x glm53 >/dev/null || return 0; sleep 1; done
  echo "REFUSED: a glm53 is still running after 180s"
  return 1
}

RESTORED=0
cleanup() {
  if [ "$RESTORED" = "0" ]; then
    echo "[$(date -Is)] cleanup: restoring gateway to its normal (no-timers) config"
    pkill -f "openai_[s]erver.py" 2>/dev/null
    pkill -9 -x glm53 2>/dev/null
    wait_no_engine
    SKIP_WARM=1 setsid nohup /home/ronald/start_glm53.sh > /home/ronald/glm53_server.log 2>&1 < /dev/null &
    disown
  fi
  rig_lock_release
  echo "[$(date -Is)] cleanup done"
}
trap cleanup EXIT

rig_lock_take context_65527v2 || { echo "REFUSED: rig lock held by another chain"; exit 3; }

echo "[$(date -Is)] stopping the owner gateway (this run holds the rig lock)"
pkill -f "openai_[s]erver.py" 2>/dev/null
pkill -9 -x glm53 2>/dev/null
wait_no_engine || exit 2

echo "[$(date -Is)] restarting gateway with COLI_TIMERS=1 for the diagnostic breakdown"
COLI_TIMERS=1 SKIP_WARM=1 setsid nohup /home/ronald/start_glm53.sh > /home/ronald/glm53_server.log 2>&1 < /dev/null &
disown

echo "[$(date -Is)] waiting for gateway to come up"
for _ in $(seq 1 120); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8081/v1/models --max-time 3 || true)
  [ "$code" = "200" ] || [ "$code" = "401" ] && break
  sleep 3
done
echo "[$(date -Is)] gateway up (code=$code)"

K=$(cat ~/.colibri_api_key)
python3 - "$K" <<'PYEOF'
import sys, json, time, subprocess
K = sys.argv[1]
with open("/home/ronald/bench/prompt_65527.txt", "rb") as f:
    text = f.read().decode("utf-8", errors="ignore")
payload = {"model": "glm-5.3-flash", "messages": [{"role": "user", "content": text}],
           "max_tokens": 48, "temperature": 0}
with open("/tmp/real_req.json", "w") as f:
    json.dump(payload, f)
print(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] submitting real request, {len(text)} chars, max_tokens=48, letting it run to completion")
t0 = time.time()
r = subprocess.run(
    ["curl", "-s", "-X", "POST", "http://localhost:8081/v1/chat/completions",
     "-H", f"Authorization: Bearer {K}", "-H", "Content-Type: application/json",
     "-d", "@/tmp/real_req.json", "--max-time", "14400"],
    capture_output=True, text=True)
dt = time.time() - t0
print(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] request finished in {dt:.1f}s")
print("RESPONSE:", r.stdout[:2000])
if r.stderr:
    print("STDERR:", r.stderr[:500])
PYEOF

echo "[$(date -Is)] real request done"
echo "[$(date -Is)] finished"
