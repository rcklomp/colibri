#!/bin/bash
# F11 step 0, scheduled 2026-09-21 by the orchestrating session: wait until
# 21:00 UTC (23:00 CEST), run the chain under the rig lock, then -- AFTER the
# chain and its trap have fully exited -- check the owner s path once more.
echo "=== f11_tonight: launching $(date -Is)"
~/src/colibri/tools/hot-expert/run_chain.sh ~/src/colibri/tools/hot-expert/f11_ladder_chain.sh > ~/bench/f11_ladder.log 2>&1
echo "=== f11_tonight: run_chain rc=$? $(date -Is)"
sleep 90
echo "=== f11_tonight: accept_live AFTER the chain exited $(date -Is)"
~/src/colibri/tools/hot-expert/accept_live.sh
echo "=== f11_tonight: post-exit accept_live rc=$? engine: $(ps -C glm53 -o pid=,stat= | tr "\n" " ")"
