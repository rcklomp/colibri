#!/bin/bash
# P6 evidence: does a side request (Open WebUI title generation) evict the conversation's prefix?
# one slot (serving config) vs four slots routed like the gateway (CPU recurrence: the device holds one state).
while pgrep -f "p4b_[c]hain.sh" >/dev/null; do sleep 30; done
echo "=== p6ev start $(date -Is)"; cd ~/src/colibri
git merge -q --ff-only p0-sync && git branch -q -D p0-sync; git log --oneline -1
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
head -c 3000 tools/hot-expert/PREFILL-ROADMAP-2026-09.md > ~/bench/p6_system.txt
for cfg in "1 2" "4 0"; do
  set -- $cfg; slots=$1; kda=$2
  echo "--- kv_slots=$slots COLI_KDA_GPU=$kda"
  COLI_KDA_GPU=$kda python3 tools/hot-expert/ttft_serve.py --engine ~/src/colibri/c/glm53 --sizes 300 --repeat 0 \
      --multiturn --side-request --system ~/bench/p6_system.txt --kv-slots $slots --warm \
      --tag p6ev-s$slots-k$kda --json ~/bench/ttft_p6.jsonl 2>&1 \
      | grep "^turn\|^side\|^regen\|^multiturn\|^REUSE\|REFUSED\|Traceback\|Error"
  pkill -9 -x glm53 2>/dev/null; sleep 2
done
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p6ev done $(date -Is)"
