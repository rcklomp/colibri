#!/bin/bash
for i in $(seq 1 30); do
  ~/src/colibri-f6a/tools/hot-expert/run_chain.sh ~/src/colibri-f6a/tools/hot-expert/f6a_gate_chain.sh >> ~/bench/f6a_gate.log 2>&1; rc=$?
  echo "=== f6a_queue attempt $i $(date -Is): run_chain exit=$rc" >> ~/bench/f6a_gate.log
  [ "$rc" != 3 ] && exit 0
  sleep 120
done
echo "=== f6a_queue: GIVING UP" >> ~/bench/f6a_gate.log
