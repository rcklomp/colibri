#!/bin/bash
# queued launcher: retry run_chain every 5 min while the lock is held (exit 3), up to 6 h
for i in $(seq 1 72); do
  ~/src/colibri-glmflash/tools/hot-expert/run_chain.sh ~/src/colibri-glmflash/tools/hot-expert/glm53flash_ladder_chain.sh >> ~/bench/glmflash_ladder.log 2>&1; rc=$?
  echo "=== glmflash_queue attempt $i $(date -Is): run_chain exit=$rc" >> ~/bench/glmflash_ladder.log
  [ "$rc" != 3 ] && { echo "=== glmflash_queue: chain ran (rc=$rc) -- done" >> ~/bench/glmflash_ladder.log; exit 0; }
  sleep 300
done
echo "=== glmflash_queue: GIVING UP after 6 h of lock refusals" >> ~/bench/glmflash_ladder.log
