#!/bin/bash
# Q4 step 2: the isolated microbenchmark, BEFORE any engine edit.
# rome_cpubench.c unchanged at hot-expert-tier 00a7713. Rig lock held, gateway
# stopped, 8 threads pinned, pools > L3 (128 MB) and > Infinity Cache (96 MB).
set -u
SRC=~/src/colibri
OUT=~/bench/q4_out; mkdir -p "$OUT"
GATEWAY_UP=0
log(){ echo "[$(date -Is)] $*"; }
. "$SRC/tools/hot-expert/rig_lock.sh"
wait_no_engine(){ for _ in $(seq 1 240); do pgrep -x "$1" >/dev/null || return 0; sleep 1; done
  echo "REFUSED: $1 still running"; return 1; }
start_gateway(){
  log "restarting the gateway"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  for _ in $(seq 1 90); do
    pgrep -f "openai_[s]erver.py" >/dev/null && pgrep -x glm53 >/dev/null && break
    sleep 10
  done
  local svc eng code
  svc=$(pgrep -f "openai_[s]erver.py" | wc -l); eng=$(pgrep -x glm53 | wc -l)
  log "gateway processes: server=$svc engine=$eng"
  if [ "$svc" -ge 1 ] && [ "$eng" -ge 1 ]; then
    GATEWAY_UP=1
    code=$(curl -s -o /dev/null -m 30 -w '%{http_code}' -H "Authorization: Bearer $(cat ~/.colibri_api_key)" http://127.0.0.1:8081/v1/models) || true
    log "curl /v1/models -> ${code:-?}"
  else log "WARNING: gateway did not come up cleanly"; fi
}
on_exit(){ rc=$?; log "=== micro exiting rc=$rc"
  [ "$GATEWAY_UP" = 1 ] || start_gateway
  rig_lock_release; log "=== q4 micro done"; }
trap on_exit EXIT INT TERM HUP
rig_lock_take "q4-micro" || { echo "rig busy"; exit 3; }
for e in qwen38 qwen38-vk; do pgrep -x "$e" >/dev/null && { log "REFUSED: $e running"; exit 1; }; done
if pgrep -x glm53 >/dev/null; then
  log "stopping the owner's gateway"
  pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53
  wait_no_engine glm53 || { log "REFUSED: glm53 would not die"; exit 1; }
fi
log "tree: $(git -C $SRC log --oneline -1)"
gcc -O3 -march=native -fopenmp -I"$SRC/c" -o /tmp/q4_cpubench "$SRC/tools/hot-expert/rome_cpubench.c" -lm || { log "build failed"; exit 1; }
free -g
for r in 1 2; do
  log "--- rome_cpubench repeat $r (8 threads)"
  OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close /tmp/q4_cpubench 2>&1 | tee "$OUT/cpubench-$r.log"
done
log "done"
