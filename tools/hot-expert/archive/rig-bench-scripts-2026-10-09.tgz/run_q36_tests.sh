#!/bin/bash
# Run every qwen36 C test in the given tree and report pass/fail.
# Run from c/ -- test_qwen36_tok_merges writes its fixture under tests/tmp_*.
cd "$1/c" || exit 1
pass=0; fail=0
for t in test_qwen36_ctx test_qwen36_dense_batch test_qwen36_json_escape \
         test_qwen36_tok_merges test_qwen36_cache_index test_qwen36_vk_nibble \
         test_qwen36_tier_int8 test_qwen36_tier_multidev test_qwen36_tier_shutdown \
         test_qwen36_tier_invariants test_qwen36_tier_autoplace test_qwen36_tier_fp8 \
         test_qwen36_tier_int8_engine; do
  if [ ! -x "./tests/$t" ]; then echo "MISSING $t"; fail=$((fail+1)); continue; fi
  if "./tests/$t" > "/tmp/r_$t.log" 2>&1; then
    echo "PASS $t"; pass=$((pass+1))
  else
    echo "FAIL $t"; tail -4 "/tmp/r_$t.log"; fail=$((fail+1))
  fi
done
echo "qwen36 C tests: $pass passed, $fail failed (of $((pass+fail)))"
[ "$fail" -eq 0 ]
