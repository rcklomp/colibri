#!/bin/bash
# per-bucket profile at the SERVING knob (COLI_KDA_GPU=2) for the P4 binary and its base
echo "=== p4prof start $(date -Is)"; cd ~/src/colibri
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
for side in p4base p4; do
  bin=~/bench/glm53.p4base; [ $side = p4 ] && bin=~/src/colibri/c/glm53
  echo "--- profile $side at COLI_KDA_GPU=2"
  COLI_KDA_GPU=2 tools/hot-expert/prefill_profile.sh $bin ~/bench/prefill_prompt_600.txt prof2-$side 2>&1 | grep -v "^teacher_forcing\|^last_logits\|^\[OPTIME\]\|^\[PROF\]\|^###\|^\[resid"
done
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p4prof done $(date -Is)"
