#!/bin/bash
# ckptmin_chain.sh — stop a short conversation from evicting the tool-block checkpoint.
#
# The engine keeps 4 checkpoint slots and captures any prefix over
# GLM53_PREFIX_CKPT_MIN (128 tokens). A 170-token API chat therefore stores a ~160 MB
# checkpoint and evicts one of the ~4 400-token Open WebUI ones — measured during the P9
# gate, which lost the 4307 capture between arms and paid ~24 minutes for it. The owner's
# own 05:00 canary makes exactly such a request, so this is self-inflicted every morning.
#
# Env-only change, no rebuild: GLM53_PREFIX_CKPT_MIN=1024 in ~/start_glm53.sh. A 500-token
# prefix then re-prefills in ~40 s instead of being cached; losing a 4 400-token one costs
# ~7 minutes. The proper fix is value-based eviction (keep the longest, not the most recent)
# and belongs in the engine — this is the safe night-time half.
set -u
LOG=$HOME/glm53_server.log; BK=$HOME/bench/start_glm53.sh.ckptmin_base
say() { echo "$(date +%H:%M:%S) $*"; }
say "=== ckptmin chain start"
cp -p ~/start_glm53.sh "$BK" || exit 2

before=$(ls ~/models/GLM-5.3-Flash-colibri-int4-g64/.coli_ckpt/*.bin 2>/dev/null | wc -l)
say "checkpoints on disk before: $before"

python3 - <<'PY'
import os, re
p = os.path.expanduser("~/start_glm53.sh"); s = open(p).read()
if "GLM53_PREFIX_CKPT_MIN" not in s:
    s = s.replace('export GLM53_PREFIX_CKPT=1',
"""export GLM53_PREFIX_CKPT=1
# A short conversation must not evict the tool-block checkpoint: 4 slots, and any prefix over
# the minimum is captured. At 128 a 170-token API chat stored ~160 MB and knocked out a
# 4 300-token capture (measured in the P9 gate, ~24 min lost). 1024 keeps the slots for
# prefixes worth minutes; a 500-token one re-prefills in ~40 s.
export GLM53_PREFIX_CKPT_MIN=1024""", 1)
    open(p + ".new", "w").write(s); os.chmod(p + ".new", 0o755); os.replace(p + ".new", p)
    print("patched")
else:
    print("already set")
PY
grep -n "GLM53_PREFIX_CKPT_MIN" ~/start_glm53.sh

# restart the service on the new setting
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null
for _ in $(seq 1 60); do pgrep -x glm53 >/dev/null || break; sleep 2; done
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > "$LOG" 2>&1 < /dev/null &
K=$(cat ~/.colibri_api_key)
for i in $(seq 1 90); do sleep 10
  [ "$(curl -s -o /dev/null -m 15 -w '%{http_code}' -H "Authorization: Bearer $K" http://127.0.0.1:8081/v1/models)" = 200 ] && break
done
say "gateway back: $(curl -s -o /dev/null -m 15 -w '%{http_code}' -H "Authorization: Bearer $K" http://127.0.0.1:8081/v1/models)"

# the probe: a short API chat must NOT create a checkpoint now
mark=$(grep -ac "CKPT store" "$LOG" 2>/dev/null || echo 0)
curl -s -m 300 -o /dev/null -H "Authorization: Bearer $K" -H "Content-Type: application/json" \
  http://127.0.0.1:8081/v1/chat/completions \
  -d '{"model":"glm-5.3-flash","messages":[{"role":"user","content":"Name three colours, comma separated."}],"max_tokens":24}'
curl -s -m 300 -o /dev/null -H "Authorization: Bearer $K" -H "Content-Type: application/json" \
  http://127.0.0.1:8081/v1/chat/completions \
  -d '{"model":"glm-5.3-flash","messages":[{"role":"user","content":"Name three colours, comma separated."},{"role":"assistant","content":"Red, blue, green."},{"role":"user","content":"And one more?"}],"max_tokens":24}'
after=$(grep -ac "CKPT store" "$LOG" 2>/dev/null || echo 0)
stores=$((after - mark))
say "short-chat probe: CKPT store lines +$stores (want 0)"

~/src/colibri/tools/hot-expert/accept_live.sh > /tmp/ckptmin_accept.txt 2>&1; rc=$?
grep -a "^[0-9]\.\|^2b\.\|accept_live" /tmp/ckptmin_accept.txt | cut -c1-120
if [ "$stores" = 0 ] && [ "$rc" = 0 ]; then
  say "=== KEEPING GLM53_PREFIX_CKPT_MIN=1024 (no small capture, accept_live PASS)"
  exit 0
fi
say "=== REVERTING (stores=$stores accept_live rc=$rc)"
cp -p "$BK" ~/start_glm53.sh
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null
for _ in $(seq 1 60); do pgrep -x glm53 >/dev/null || break; sleep 2; done
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > "$LOG" 2>&1 < /dev/null &
for i in $(seq 1 90); do sleep 10
  [ "$(curl -s -o /dev/null -m 15 -w '%{http_code}' -H "Authorization: Bearer $K" http://127.0.0.1:8081/v1/models)" = 200 ] && break
done
say "reverted; gateway $(curl -s -o /dev/null -m 15 -w '%{http_code}' -H "Authorization: Bearer $K" http://127.0.0.1:8081/v1/models)"
exit 1
