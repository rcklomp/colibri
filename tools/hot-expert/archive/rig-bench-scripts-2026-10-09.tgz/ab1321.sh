#!/bin/bash
# Cold A/B for JustVugg/colibri#1321, in the shape the maintainer asked for:
# same machine, same prompt, same greedy decode (so same tokens, no seed needed),
# page cache evicted before EVERY run, reporting tok/s AND expert hit rate for
# both the old budget (dev) and the new one (patched).
#
# Eviction is posix_fadvise(DONTNEED) over the model shards -- no sudo, and it
# targets exactly the pages under test rather than the whole machine.
set -u
M="$HOME/models/GLM-5.3-Flash-colibri-int4-g64"
OLD="$HOME/bench/devbase/c/glm53"
NEW="$HOME/bench/pr1321/c/glm53"
NGEN="${NGEN:-60}"
REPS="${REPS:-2}"
PROMPT="Explain, in one paragraph, why a memory cache and a page cache that hold the same bytes can make a machine slower than either alone."
OUT="$HOME/bench/ab1321.log"

. "$HOME/src/colibri/tools/hot-expert/rig_lock.sh"
rig_lock_take "ab1321" || { echo "LOCK BUSY: $(rig_lock_holder)"; exit 3; }
GW=0
if pgrep -f "openai_[s]erver.py" >/dev/null; then GW=1; fi
cleanup() {
  if [ "$GW" = 1 ] && ! pgrep -f "openai_[s]erver.py" >/dev/null; then
    echo "[ab] restarting the owner's gateway"
    SKIP_WARM=1 setsid nohup "$HOME/start_glm53.sh" > "$HOME/glm53_server.log" 2>&1 < /dev/null &
  fi
  rig_lock_release
}
trap cleanup EXIT
if [ "$GW" = 1 ]; then
  echo "[ab] stopping the gateway for the campaign"
  pkill -f "start_[g]lm53.sh"; sleep 1
  pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null
  for i in $(seq 1 90); do pgrep -x glm53 >/dev/null || break; sleep 1; done
fi

evict() {
  python3 - "$M" <<'PY'
import os, sys, glob
n = 0
for f in sorted(glob.glob(os.path.join(sys.argv[1], "*.safetensors"))):
    fd = os.open(f, os.O_RDONLY)
    try:
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED); n += 1
    finally:
        os.close(fd)
print(f"[evict] {n} shards")
PY
}

run() {   # run <label> <binary> [env...]
  local label="$1" bin="$2"; shift 2
  evict >/dev/null
  sleep 3
  local t0=$(date +%s)
  local log="$HOME/bench/ab1321.$label.txt"
  env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close GLM53_VERBOSE=1 "$@" \
      "$bin" --model "$M" --prompt "$PROMPT" --greedy "$NGEN" > "$log" 2>&1
  local rc=$? el=$(( $(date +%s) - t0 ))
  local budget=$(grep -m1 "expert budget" "$log" | sed 's/^[[:space:]]*//')
  local slots=$(grep -m1 "experts:.*slots" "$log" | sed 's/^[[:space:]]*//')
  local dec=$(grep -m1 "^decode " "$log")
  local exp=$(grep -m1 "^experts hits" "$log")
  local toks=$(echo "$dec" | sed -n 's/.*= \([0-9.]*\) tok\/s.*/\1/p')
  local h=$(echo "$exp" | sed -n 's/experts hits \([0-9]*\).*/\1/p')
  local ms=$(echo "$exp" | sed -n 's/.*miss \([0-9]*\).*/\1/p')
  local hr="-"
  [ -n "${h:-}" ] && [ -n "${ms:-}" ] && hr=$(python3 -c "h=$h;m=$ms;print(f'{100.0*h/(h+m):.1f}' if h+m else '-')")
  printf '%-22s rc=%s wall=%ss tok/s=%-7s hit=%-6s hits=%-8s miss=%-8s | %s\n' \
         "$label" "$rc" "$el" "${toks:--}" "$hr" "${h:--}" "${ms:--}" "$budget" | tee -a "$OUT"
  [ -n "$slots" ] && echo "    $slots" | tee -a "$OUT"
}

echo "=== ab1321 $(date -Is) ngen=$NGEN reps=$REPS ===" | tee -a "$OUT"
for r in $(seq 1 "$REPS"); do
  run "old-dev-run$r"   "$OLD"
  run "new-patch-run$r" "$NEW"
done
echo "=== done $(date -Is) ===" | tee -a "$OUT"
