#!/bin/bash
echo "=== vkprof start $(date -Is)"; cd ~/src/colibri
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
VK_PROF=1 COLI_KDA_GPU=2 tools/hot-expert/prefill_profile.sh ~/src/colibri/c/glm53 ~/bench/prefill_prompt_600.txt vkprof-p4 2>&1 | grep -v "^teacher_forcing\|^last_logits\|^###\|^\[resid"
echo "--- VK_PROF lines:"; grep -h "VK_PROF\|\[VK\] prof\|phase\|memcpy\|fence" ~/bench/prefill_profile_vkprof-p4.log | grep -v "P4 tiles" | head -20
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== vkprof done $(date -Is)"
