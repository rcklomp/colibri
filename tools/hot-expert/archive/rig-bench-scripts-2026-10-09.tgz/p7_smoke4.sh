#!/bin/bash
# P7 smoke 4: only gate steps 4 and 5, from the scratch clone, to confirm the
# "wait for the engine to die" fix before spending another 2.5 h on the chain.
set -u
S=~/src/colibri-p7
LOG=~/bench/p7_smoke_out; mkdir -p $LOG
export COLI_CKPT_DIR=$LOG/ckpt4; mkdir -p $COLI_CKPT_DIR; rm -f $COLI_CKPT_DIR/*.bin
restart_gateway() {
  echo "--- restarting the gateway $(date -Is)"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
  sha256sum ~/src/colibri/c/glm53
}
trap restart_gateway EXIT
echo "=== p7 smoke4 start $(date -Is)"
cd $S && git fetch -q origin && git checkout -q -B p0-sync origin/p0-sync && git log --oneline -1
make -C c glm53 VK=1 2>&1 | tail -3
~/bench/p7_stop.sh || exit 2
GATE_STEPS=45 \
STEP5_REF=~/bench/prefill_gate_p709070839-off/ttft.jsonl \
STEP5_REF_TAG=p709070839 \
  bash $S/tools/hot-expert/p7_gate.sh ~/bench/glm53.p7base $S/c/glm53 smoke4
echo "smoke4 gate rc=$?"
echo "=== p7 smoke4 done $(date -Is)"
