#!/usr/bin/env bash
# step0_gate.sh — refuse a chain whose build item has no step-0 measurement record.
# Usage (first lines of each item chain):  ~/bench/step0_gate.sh <ITEM-ID> || exit $?
#
# Convention (verified against the record 2026-09-25): step 0 of a build item is
# recorded as a heading "## §<ITEM>-STEP0" in the ROME record — existing:
# F1/F2/F3/F8/F10/F11-STEP0. The L ladder's step 0 IS the M program (design §4,
# §7 "L0 is not started until M1, M3 and M5 have reported"), so an L-item is
# allowed when any §M0..§M5 section exists.
#
# Exit codes, chosen to coexist with run_chain.sh semantics (CLAUDE.md 2026-09-24:
# sequences RETRY on rc 3 = lock busy — never 3 here):
#   0 = allowed (evidence found; or record unreadable -> warn, do not block)
#   4 = refused: no step-0 evidence. NOT retryable — a human/script must run
#       the measurement and record it first.
# Override for a genuinely exempt launch (e.g. oracle-only replay):
#   STEP0_GATE_NOTE="why" ~/bench/step0_gate.sh <ITEM>   -> allowed, logs the note
set -u
REC=/home/ronald/src/colibri/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md
ITEM=${1:?usage: step0_gate.sh ITEM-ID}
if [ -n "${STEP0_GATE_NOTE:-}" ]; then
  echo "step0_gate: ALLOWED by override for $ITEM — note: $STEP0_GATE_NOTE"; exit 0
fi
if [ ! -r "$REC" ]; then
  echo "step0_gate: WARNING — record unreadable, cannot verify $ITEM; allowing"; exit 0
fi
shopt -s nocasematch
if grep -m1 -E "§?${ITEM}[- ]?STEP0" "$REC" >/dev/null 2>&1; then
  echo "step0_gate: OK — §${ITEM}-STEP0 found in the record"; exit 0
fi
if [[ "$ITEM" =~ ^[Ll][0-9] ]] && grep -qm1 "^## §M[0-5]" "$REC"; then
  echo "step0_gate: OK — $ITEM is a ladder rung; the M program (design §4) is its step 0"; exit 0
fi
echo "step0_gate: REFUSED — no §${ITEM}-STEP0 measurement in the record."
echo "  Rule: step 0 is a measurement, never arithmetic (CLAUDE.md; HANDOFF §5.1)."
echo "  Run the step-0 microbenchmark, record it as §${ITEM}-STEP0, then relaunch."
exit 4
