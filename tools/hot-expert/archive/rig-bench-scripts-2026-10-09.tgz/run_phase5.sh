#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
while ! grep -q "phase4 done" ~/bench/phase4.out; do sleep 5; done
cp ~/bench/staged/quant.h ~/bench/staged/qwen38_core.h ~/bench/staged/qwen38.c .
log "build (VK=1) with GPU orchestration patch"
make qwen38 qwen38-vk VK=1 2>&1 | grep -E "error|warning" | head -10
ls -la qwen38 qwen38-vk
VKENV="Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS=shaders"
run(){ name=$1; shift; log "run $name"; env "$@" SNAP=$M NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin /usr/bin/time -v ./qwen38-vk 512 8 ~/bench/prompt1.txt > ~/bench/q38_$name.log 2>&1; echo "rc=$?"; grep -E "Speed|TTFT|routed-expert|resident-mm|deltanet|shared-expert|expert-read|preloaded|tier|Major|Minor|Percent|Text|resident weights" ~/bench/q38_$name.log; }
run vk_preload_64 $VKENV N_NEW=64
run vk_lazy_64 $VKENV N_NEW=64 Q38_VK_PRELOAD=0
run vk_preload_128 $VKENV N_NEW=128
run cpu_vkbuild_64 N_NEW=64
log "phase5 done"
