#!/bin/bash
# Order-controlled A/B: P,Q,Q,P so cache-warmth order cannot favour either arm.
set -u
M="$HOME/models/GLM-5.3-Flash-colibri-int4-g64"
P="$HOME/bench/hc_pristine/c/glm53"; Q="$HOME/bench/hc_patched/c/glm53"
PROMPT="Describe the water cycle in three sentences."
N=40; OUT="$HOME/bench/hc_ab.log"
. "$HOME/src/colibri/tools/hot-expert/rig_lock.sh"
rig_lock_take "hc-ab" || { echo "LOCK BUSY: $(rig_lock_holder)"; exit 3; }
GW=0; pgrep -f "openai_[s]erver.py" >/dev/null && GW=1
cleanup(){ if [ "$GW" = 1 ] && ! pgrep -f "openai_[s]erver.py" >/dev/null; then
    SKIP_WARM=1 setsid nohup "$HOME/start_glm53.sh" > "$HOME/glm53_server.log" 2>&1 < /dev/null & fi
  rig_lock_release; }
trap cleanup EXIT
if [ "$GW" = 1 ]; then pkill -f "start_[g]lm53.sh"; sleep 1; pkill -f "openai_[s]erver.py"; sleep 3
  pkill -9 -x glm53 2>/dev/null; for i in $(seq 1 90); do pgrep -x glm53 >/dev/null || break; sleep 1; done; fi
echo "=== hc_ab $(date -Is) order P,Q,Q,P (all warm) ===" | tee -a "$OUT"
for arm in P Q Q P; do
  [ "$arm" = P ] && BIN="$P" || BIN="$Q"
  r=$(env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close "$BIN" \
      --model "$M" --prompt "$PROMPT" --greedy "$N" 2>&1 | grep -m1 "^decode ")
  printf '%s  %s\n' "$arm" "$r" | tee -a "$OUT"
done
echo "=== done ===" | tee -a "$OUT"
