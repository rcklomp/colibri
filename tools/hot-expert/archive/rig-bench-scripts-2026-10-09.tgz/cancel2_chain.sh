#!/bin/bash
# cancel2_chain.sh — land the deferred-cancel fix (gateway Python only) and the lock/watchdog.
# Gate: the abandoned-request case, six times, must never leave the next request waiting more
# than 45 s (it reproduced 1-in-3 at 158-255 s before), plus accept_live in full.
# Run through run_chain.sh so the rig lock is held.
set -u
TREE=$HOME/src/colibri; LOG=$HOME/glm53_server.log; K=$(cat $HOME/.colibri_api_key)
LAST_GATED=$(cd $TREE && git rev-parse HEAD)
echo "=== cancel2 chain $(date +%Y-%m-%dT%H:%M:%S%z); last gated tree: $(cd $TREE && git log --oneline -1)"
restart() {
  pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null
  for _ in $(seq 1 60); do pgrep -x glm53 >/dev/null || break; sleep 2; done
  SKIP_WARM=1 setsid nohup $HOME/start_glm53.sh > $LOG 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -w '%{http_code}' -H "Authorization: Bearer $K" \
         http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && return 0
    sleep 5
  done
  echo "gateway did not come back"; return 1
}
revert() {
  echo "--- REVERTING the tree to $LAST_GATED"
  (cd $TREE && git reset -q --hard "$LAST_GATED" && git log --oneline -1)
  restart
}
cd $TREE || exit 2
git merge -q --ff-only p0-sync || { echo "merge refused"; exit 2; }
echo "merged: $(git log --oneline -1)"
grep -q cancel_pending c/openai_server.py || { echo "the fix is not in the tree"; revert; exit 2; }
restart || { revert; exit 2; }

BIG=$(python3 -c "print(('The quick brown fox jumps over the lazy dog. ' * 130))")
body=$(printf '%s' "$BIG Summarise this in one word." | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')
fail=0
for i in $(seq 1 6); do
  curl -s -m 8 -o /dev/null -H "Authorization: Bearer $K" -H "Content-Type: application/json" \
    http://127.0.0.1:8081/v1/chat/completions \
    -d "{\"model\":\"glm-5.3-flash\",\"messages\":[{\"role\":\"user\",\"content\":$body}],\"max_tokens\":32}" || true
  t0=$(date +%s.%N)
  curl -s -m 400 -o /dev/null -H "Authorization: Bearer $K" -H "Content-Type: application/json" \
    http://127.0.0.1:8081/v1/chat/completions \
    -d '{"model":"glm-5.3-flash","messages":[{"role":"user","content":"Say OK."}],"max_tokens":8}'
  t=$(python3 -c "print(round($(date +%s.%N) - $t0, 1))")
  c=$(grep -c "CANCEL " $LOG)
  echo "abandoned-request run $i: next request answered in ${t}s (cancel lines so far: $c)"
  python3 -c "import sys; sys.exit(0 if $t <= 45 else 1)" || { echo "  ABOVE THE 45 s BOUND"; fail=1; }
done
echo "--- accept_live"
$TREE/tools/hot-expert/accept_live.sh; alrc=$?
echo "accept_live rc=$alrc"
if [ $fail = 0 ] && [ $alrc = 0 ]; then
  echo "=== IN SERVICE: $(cd $TREE && git log --oneline -1)"
  (cd $TREE && git rev-parse HEAD > $HOME/bench/served.commit)
  exit 0
fi
echo "=== GATE FAILED (abandoned-request fail=$fail, accept_live=$alrc)"; revert; exit 1
