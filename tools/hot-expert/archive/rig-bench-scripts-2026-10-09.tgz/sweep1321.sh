#!/bin/bash
# Where is the optimum, and does the formula's 8% margin land on it?
# GLM53_EXPERT_GB is used directly as the budget in GB, so these points are
# independent of the meminfo unit fix -- they measure the machine, not the
# formula. Same prompt, same greedy decode, page cache evicted before each run.
set -u
M="$HOME/models/GLM-5.3-Flash-colibri-int4-g64"
BIN="$HOME/bench/pr1321/c/glm53"
NGEN="${NGEN:-60}"
PROMPT="Explain, in one paragraph, why a memory cache and a page cache that hold the same bytes can make a machine slower than either alone."
OUT="$HOME/bench/sweep1321.log"
POINTS="${POINTS:-24 40 48 61 100}"

. "$HOME/src/colibri/tools/hot-expert/rig_lock.sh"
rig_lock_take "sweep1321" || { echo "LOCK BUSY: $(rig_lock_holder)"; exit 3; }
GW=0; pgrep -f "openai_[s]erver.py" >/dev/null && GW=1
cleanup(){
  if [ "$GW" = 1 ] && ! pgrep -f "openai_[s]erver.py" >/dev/null; then
    echo "[sweep] restarting the owner's gateway"
    SKIP_WARM=1 setsid nohup "$HOME/start_glm53.sh" > "$HOME/glm53_server.log" 2>&1 < /dev/null &
  fi
  rig_lock_release
}
trap cleanup EXIT
if [ "$GW" = 1 ]; then
  pkill -f "start_[g]lm53.sh"; sleep 1
  pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null
  for i in $(seq 1 90); do pgrep -x glm53 >/dev/null || break; sleep 1; done
fi

evict(){ python3 - "$M" <<'PY'
import os, sys, glob
for f in sorted(glob.glob(os.path.join(sys.argv[1], "*.safetensors"))):
    fd = os.open(f, os.O_RDONLY)
    try: os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
    finally: os.close(fd)
PY
}

echo "=== sweep1321 $(date -Is) ngen=$NGEN points=$POINTS ===" | tee -a "$OUT"
for gb in $POINTS; do
  evict; sleep 3
  log="$HOME/bench/sweep1321.$gb.txt"
  env OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close GLM53_VERBOSE=1 \
      GLM53_EXPERT_GB="$gb" "$BIN" --model "$M" --prompt "$PROMPT" --greedy "$NGEN" > "$log" 2>&1
  dec=$(grep -m1 "^decode " "$log"); exp=$(grep -m1 "^experts hits" "$log")
  toks=$(echo "$dec" | sed -n 's/.*= \([0-9.]*\) tok\/s.*/\1/p')
  h=$(echo "$exp" | sed -n 's/experts hits \([0-9]*\).*/\1/p')
  ms=$(echo "$exp" | sed -n 's/.*miss \([0-9]*\).*/\1/p')
  hr="-"; [ -n "${h:-}" ] && [ -n "${ms:-}" ] && hr=$(python3 -c "h=$h;m=$ms;print(f'{100.0*h/(h+m):.1f}' if h+m else '-')")
  slots=$(grep -m1 "experts:.*slots" "$log" | sed -n 's/.*, \([0-9]*\) per layer.*/\1/p')
  printf 'GLM53_EXPERT_GB=%-5s tok/s=%-7s hit=%-6s hits=%-8s miss=%-8s slots/layer=%s\n' \
         "$gb" "${toks:--}" "$hr" "${h:--}" "${ms:--}" "${slots:--}" | tee -a "$OUT"
done
echo "=== done $(date -Is) ===" | tee -a "$OUT"
