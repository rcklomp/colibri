#!/bin/bash
# glm5_timeline_chain_hwq.sh -- (the timeline chain with HWQ=<n> passed as GPU_MAX_HW_QUEUES into the container, H1b of GLM5.md 14.3; only when HWQ is set) GLM5.md section 14: the GLM prefill DEVICE TIMELINE, one GPU process
# (glm5_gpu_gate.sh timeline: one load, then tl_smoke, A off, T --timeline, B off), the shape of
# ~/bench/glm5e_chain.sh / glm5f_chain.sh (the pf2 / ckpt gates): stop the gateway, run the gate in
# the ROCm 7.14 image with the cards (--ulimit memlock=-1: the pinned expert mirror), read the
# timeline with glm5_timeline.py on the host, then the usual exit (gateway left down while
# ~/bench/.dev_reserved exists, else restarted; accept_live).
#
# Launch (on the rig; NOT run by the agent that wrote it -- it initialises the GPUs):
#   ~/src/colibri/tools/hot-expert/preflight.sh && \
#     setsid nohup ~/src/colibri/tools/hot-expert/run_chain.sh ~/bench/glm5_timeline_chain.sh \
#       > ~/bench/glm5_timeline_chain.log 2>&1 < /dev/null &
# Env: TL_WT the worktree whose build runs (default ~/src/franken-engine), TL_OUT the output
# dir (default ~/bench/franken/glm5/pftl). Outputs: gate_run.log, gate.txt, timeline.csv,
# timeline_smoke.csv, timeline_report.txt (the gate's), timeline_report_host.txt.
set -u
HERE=~/src/colibri/tools/hot-expert
WT=${TL_WT:-/home/ronald/src/franken-engine}
D=$WT/franken/decode
O=${TL_OUT:-/home/ronald/bench/franken/glm5/pftl}
KEY=$(cat ~/.colibri_api_key); GLOG=~/glm53_server.log
engine_alive() { ps -C glm53 -o stat= 2>/dev/null | grep -qv '^Z'; }
franken_alive() { [ -n "$(docker ps -q -f name='^franken_engine$' 2>/dev/null)" ]; }
wait_engines_gone() {
  for _ in $(seq 1 120); do engine_alive || franken_alive || return 0; sleep 2; done
  echo "an engine is still alive after 240 s (glm53: $(engine_alive && echo yes || echo no), franken_engine container: $(franken_alive && echo yes || echo no))"; return 1
}
start_gateway() {
  env -u COLI_CKPT_DIR -u GLM53_PREFIX_CKPT SKIP_WARM=1 setsid nohup ~/start_glm53.sh >> "$GLOG" 2>&1 < /dev/null &
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -m 5 -H "Authorization: Bearer $KEY" -w '%{http_code}' http://127.0.0.1:8081/v1/models 2>/dev/null)" = 200 ] && break
    sleep 5
  done
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(engine_alive && echo 1 || echo 0)"
}
stop_gateway() {
  pkill -f "openai_[s]erver.py" 2>/dev/null || true
  for _ in $(seq 1 10); do pgrep -f "openai_[s]erver.py" >/dev/null || break; sleep 1; done
  pkill -9 -f "openai_[s]erver.py" 2>/dev/null || true
  pkill -9 -x glm53 2>/dev/null || true
  wait_engines_gone
}
on_exit() {
  rc=$?; trap - EXIT INT TERM HUP
  if [ -e "$HOME/bench/.dev_reserved" ]; then echo "rig reserved for development: gateway left down"
  elif pgrep -f "openai_[s]erver.py" >/dev/null && engine_alive; then echo "gateway already in service"; else stop_gateway; start_gateway; fi
  echo "=== glm5_timeline_chain exit rc=$rc $(date -Is)"
  "$HERE/accept_live.sh"; a=$?; echo "--- accept_live exit=$a"; [ "$rc" -eq 0 ] && rc=$a; exit "$rc"
}
trap on_exit EXIT INT TERM HUP
[ -x $D/franken_decode_glm ] || { echo "no $D/franken_decode_glm (make -C franken/decode gpu GPU_BIN=franken_decode_glm)"; exit 2; }
mkdir -p $O
echo "=== glm5_timeline_chain start $(date -Is) worktree $WT ($(git -C $WT log --oneline -1 2>/dev/null))"
stop_gateway || exit 1
sleep 5
m=0
for d in /sys/class/drm/card[0-9]/device; do
  u=$(( $(cat $d/mem_info_vram_used) / 1048576 )); echo "vram_used_before=$u MiB"; [ $u -gt $m ] && m=$u
done
[ $m -gt 1024 ] && { echo "REFUSED: a card still holds $m MiB (another engine?) -- not timing on busy cards"; exit 3; }
docker run --rm --device /dev/kfd --device /dev/dri --group-add video --security-opt seccomp=unconfined --ipc=host \
  --ulimit memlock=-1 ${HWQ:+-e GPU_MAX_HW_QUEUES=$HWQ} -e GLM5_GPU_OK=1 -e GLM5_GATE_OUT=$O -e GLM5_D=$D \
  -e LD_LIBRARY_PATH=/opt/rocm/lib:/home/ronald/src/llama-glm53/build-hip/bin -e HOME=/home/ronald \
  -v /home/ronald:/home/ronald -w $D rocm/dev-ubuntu-24.04:7.14.0-full bash ./glm5_gpu_gate.sh timeline 2>&1 \
  | tee $O/gate.txt; rc=${PIPESTATUS[0]}
echo "=== glm5 timeline gate rc=$rc"
# the report again on the host (the gate wrote it from inside the image when it had python3)
if [ -f $O/timeline.csv ]; then
  # (the gate's own copy, timeline_report.txt, is root's: the image runs as root)
  python3 -I $D/glm5_timeline.py $O/timeline.csv --tokens 512 --layers --gantt 4 > $O/timeline_report_host.txt 2>&1
  echo "--- glm5_timeline.py rc=$? -> $O/timeline_report_host.txt"
  sed -n '/^=== steady state/,/^  gantt/p' $O/timeline_report_host.txt
fi
exit $rc
