#!/bin/bash
sed -n '/=== verifycost start/,$p' ~/bench/glm_seq_vc.log 2>/dev/null | grep -vE "^run_chain|^$|chain exit" | cut -c1-200 | head -30
