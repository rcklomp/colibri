#!/bin/bash
until ~/src/colibri/tools/hot-expert/serve_alt.sh status 2>&1 | grep -q "serving: GLM-5.3 (model id"; do sleep 30; done
until [ ! -d ~/bench/.rig.lock ] || ! kill -0 $(awk "{print \$2}" ~/bench/.rig.lock/owner 2>/dev/null) 2>/dev/null; do sleep 30; done
exec ~/bench/f11_fit.sh
