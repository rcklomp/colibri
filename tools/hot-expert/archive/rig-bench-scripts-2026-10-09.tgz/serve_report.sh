#!/bin/bash
sed -n '/=== glm_serve_chunk start/,$p' ~/bench/glm_seq_serve.log 2>/dev/null | grep -vE "^run_chain|^$|chain exit trap" | cut -c1-210 | head -60
