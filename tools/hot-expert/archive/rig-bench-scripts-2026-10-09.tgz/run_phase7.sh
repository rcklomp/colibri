#!/usr/bin/env bash
cd /home/ronald/src/colibri
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
cp ~/bench/staged/quant.h ~/bench/staged/qwen38_core.h ~/bench/staged/qwen38.c c/
cp ~/bench/staged/docs/qwen38.md ~/bench/staged/docs/ENVIRONMENT.md docs/
cp ~/bench/staged/hot-expert/* tools/hot-expert/
git status -s
cd c
log "build qwen38 qwen38-vk glm53 (quant.h is shared)"
make qwen38 qwen38-vk glm53 VK=1 2>&1 | grep -E "error|warning" | head -10; ls -la qwen38 qwen38-vk glm53
log "unit tests that touch qwen38 (compile + run where fixture-free)"
make tests/test_qwen38_config tests/test_qwen38_serve_framing tests/test_qwen38_metrics tests/test_qwen38_prefix VK=1 2>&1 | grep -E "error" | head -5
for t in test_qwen38_config test_qwen38_serve_framing tests_qwen38_metrics test_qwen38_metrics test_qwen38_prefix; do [ -x tests/$t ] && { timeout 120 ./tests/$t >/tmp/$t.log 2>&1; echo "$t rc=$?"; tail -2 /tmp/$t.log; }; done
log "rome_fp8test against final quant.h"; gcc -O3 -march=native -fopenmp -I. ../tools/hot-expert/rome_fp8test.c -o /tmp/rome_fp8test -lm && OMP_NUM_THREADS=16 /tmp/rome_fp8test | tail -4
VKENV="Q38_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto COLI_VK_SHADERS=shaders"
run(){ name=$1; bin=$2; shift 2; log "run $name"; env "$@" SNAP=$M NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin DUMP=/home/ronald/bench/logits_$name.f32 /usr/bin/time -v $bin 512 8 ~/bench/prompt1.txt > ~/bench/q38_$name.log 2>&1; echo "rc=$?"; grep -E "Speed|TTFT|routed-expert|resident-mm|expert-read|preloaded|Major|Text" ~/bench/q38_$name.log; }
run final_cpu16 ./qwen38 N_NEW=64
run final_cpu8 ./qwen38 N_NEW=64 OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
run final_vk128 ./qwen38-vk $VKENV N_NEW=128
run final_vk128_8t ./qwen38-vk $VKENV N_NEW=128 OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
log "identity vs pristine"
for n in final_cpu16 final_cpu8 final_vk128; do python3 ~/bench/cmp_logits.py ~/bench/logits_base_dump.f32 ~/bench/logits_$n.f32; done
log "phase7 done"
