#!/bin/bash
# f7_serve.sh -- put the gated F7 binary (GPU prefill attention core) in service.
set -u
T=$HOME/src/colibri-f7/tools/hot-expert
CAND=$HOME/bench/glm53.f7; PRIS=$HOME/bench/glm53.f2
. "$T/rig_lock.sh"
rig_lock_take "f7_serve" || exit 3
trap 'rig_lock_release' EXIT INT TERM
echo "=== f7_serve $(date -u -Is)"
cp -p $HOME/src/colibri-f7/c/glm53 $CAND || exit 4
sha256sum $CAND $PRIS $HOME/src/colibri/c/glm53 | cut -c1-16,65-
cp -p $HOME/src/colibri-f7/c/shaders/mla_attn_*.spv $HOME/src/colibri/c/shaders/ || exit 4
S=$HOME/start_glm53.sh
cp -p $S $HOME/bench/start_glm53.sh.pre-f7
if ! grep -q GLM53_MLA_ATTN_GPU $S; then
  awk '/^export GLM53_VK_SWIGLU_CLAMP=1/ { print; print "# F7 (2026-09-20): the prefill MLA attention core on dev0, batched over the chunk rows (decode untouched)."; print "# Gate: 18k turn 683.3 -> 454.6 s (1.50x), turn 1 1.35x; numerics = an fp32-rounding-sized perturbation (jitter arm)."; print "export GLM53_MLA_ATTN_GPU=1"; next } { print }' $S > $S.new && chmod +x $S.new && bash -n $S.new && mv -f $S.new $S || exit 5
fi
grep -n "MLA_ATTN_GPU" $S || exit 5
"$T/serve_candidate.sh" $CAND $PRIS
rc=$?
echo "=== serve_candidate rc=$rc $(date -u -Is)"
if [ $rc -ne 0 ]; then cp -p $HOME/bench/start_glm53.sh.pre-f7 $S.revert && mv -f $S.revert $S; echo "start script reverted"; fi
grep -a "\[MLA\]\|mla_attn\|MLA attn" $HOME/glm53_server.log | head -5
exit $rc
