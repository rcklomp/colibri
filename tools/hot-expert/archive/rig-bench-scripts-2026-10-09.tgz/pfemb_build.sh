#!/bin/bash
# pfemb_build.sh -- build the pf-embed-kernel worktree (no GPU touched: docker without --device).
# Each container: --cpus 1, nice 19 inside; make -j4 over the six targets.
set -u
W=/home/ronald/src/franken-engine-pfemb/franken/decode
IMG=rocm/dev-ubuntu-24.04:7.14.0-full
cd $W || exit 2
date -Is
nice -n 19 make -j4 \
  DOCKER_RUN="docker run --rm --user 1000:1000 --cpus 1 -v /home/ronald:/home/ronald -w $W $IMG nice -n 19" \
  cpu gpu glm-serve-cpu glm-serve-gpu ds4-cpu ds4-gpu CPU_BIN=franken_decode_glm_cpu GPU_BIN=franken_decode_glm
echo "make rc=$?"
date -Is
ls -la franken_decode_glm franken_decode_glm_cpu franken_dec_glm franken_dec_glm_cpu franken_decode_ds4 franken_decode_ds4_cpu 2>&1
