#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "warm Qwen (after drop_caches)"; cat $M/*.safetensors > /dev/null
fincore --bytes --noheadings $M/*.safetensors | awk '{r+=$1} END {printf "resident %.1f GiB\n", r/2^30}'
run(){ name=$1; bin=$2; shift 2; log "run $name ($bin)"; env "$@" SNAP=$M N_NEW=64 NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin /usr/bin/time -v $bin 512 8 ~/bench/prompt1.txt > ~/bench/q38_$name.log 2>&1; echo "rc=$?"; grep -E "Speed|TTFT|routed-expert|resident-mm|deltanet|shared-expert|expert-read|lm-head|Major|Minor|Percent|Text" ~/bench/q38_$name.log; }
run base1 ~/bench/qwen38.base X=1
run all1 ./qwen38 X=1
run nopop ./qwen38 Q38_MMAP_POPULATE=0
run nofuse ./qwen38 Q38_DENSE_MULTI=0
run base2 ~/bench/qwen38.base X=1
run all2 ./qwen38 X=1
run all_passive ./qwen38 OMP_WAIT_POLICY=passive
run all_8t ./qwen38 OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
log "phase4 done"
