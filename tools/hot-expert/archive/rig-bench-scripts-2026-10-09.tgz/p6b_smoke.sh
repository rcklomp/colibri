#!/bin/bash
# P6b smoke: steps 1 and 5 of the gate on the SCRATCH build (~/src/colibri-p7),
# with the 4-tool fixture, to prove the pool allocates, the guard stays silent
# and the sync left the write-combined path -- before spending ~2 h on the real
# gate. Restarts the gateway on every exit path.
set -u
TAG=p6bsmoke$(date +%m%d%H%M)
start_gateway() {
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 100
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
on_exit() {
  echo "=== smoke done rc=$? $(date -Is)"
  pgrep -f "openai_[s]erver.py" >/dev/null || start_gateway
}
trap on_exit EXIT
echo "=== p6b smoke $(date -Is) tag=$TAG"
~/bench/p7_stop.sh || exit 2
GATE_STEPS=15 GATE_TOOLS=~/bench/owui_tools_4.json P6B_SYNC_MS=1000 \
  bash ~/src/colibri-p7/tools/hot-expert/p6b_gate.sh \
       ~/bench/glm53.p6bbase ~/src/colibri-p7/c/glm53 $TAG 2>&1
echo "SMOKE rc=$?"
