#!/bin/bash
# pfemb_cpu_guard.sh -- run pfemb_cpu_check.sh parts 1 and 2 ONLY while the rig lock is free, and abort
# the check within ~1 s if a live holder takes the lock meanwhile (a chain starting back-to-back); then wait
# and retry the same part. Usage: pfemb_cpu_guard.sh [parts] (default "1 2"). The check itself also refuses at start if the lock is held. No GPU.
set -u
LOCKD=$HOME/bench/.rig.lock
held() { [ -d "$LOCKD" ] || return 1; local pid; pid=$(awk '{print $2}' "$LOCKD/owner" 2>/dev/null); [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; }
echo "[guard] start $(date -Is)"
for part in ${@:-1 2}; do
  for try in $(seq 1 400); do
    # free for FREE_S (default 60) consecutive seconds before starting (chains launched back to back leave gaps of ~10-20 s)
    while held; do sleep 5; done
    ok=1; for s in $(seq 1 ${FREE_S:-60}); do if held; then ok=0; break; fi; sleep 1; done
    [ $ok = 1 ] || continue
    echo "[guard] part $part try $try start $(date -Is) (lock free ${FREE_S:-60} s)"
    "$HOME/bench/pfemb_cpu_check.sh" $part > "$HOME/bench/pfemb_cpu_check_p$part.log" 2>&1 &
    cpid=$!
    aborted=0
    while kill -0 $cpid 2>/dev/null; do
      if held; then
        aborted=1
        echo "[guard] lock taken ($(cat "$LOCKD/owner" 2>/dev/null)) at $(date -Is): aborting part $part"
        pkill -f "[s]rc/franken-engine-pfemb/franken/decode/franken_decode_glm_cpu"
        kill $cpid 2>/dev/null
        break
      fi
      sleep 1
    done
    wait $cpid 2>/dev/null
    if [ $aborted = 0 ]; then echo "[guard] part $part finished $(date -Is)"; break; fi
    sleep 5
  done
done
echo "[guard] done $(date -Is)"
