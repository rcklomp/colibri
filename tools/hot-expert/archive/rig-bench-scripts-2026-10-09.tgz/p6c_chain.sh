#!/bin/bash
# P6 live check, take two: 4 slots + CPU recurrence in the serving script, warm, side-request case through the gateway.
echo "=== p6c start $(date -Is)"; cd ~/src/colibri
cp ~/start_glm53.sh ~/bench/start_glm53.sh.p6cbase
python3 - <<'PY'
import os, re
p=os.path.expanduser("~/start_glm53.sh"); s=open(p).read()
s=re.sub(r"  --kv-slots \d+ \\\n", "  --kv-slots 4 \\\n", s, count=1)
s=re.sub(r"^export COLI_KDA_GPU=\d+.*$", "export COLI_KDA_GPU=0   # P6: 4 slots need the CPU recurrence until P6b (the engine forces 0 anyway)", s, count=1, flags=re.M)
open(p+".new","w").write(s); os.chmod(p+".new",0o755); os.replace(p+".new",p)
PY
grep -n "^export COLI_KDA_GPU\|kv-slots" ~/start_glm53.sh
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 100; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"; grep -m1 "listening\|ValueError" ~/glm53_server.log
echo "--- side-request case through the live gateway (warm first)"
python3 tools/hot-expert/ttft_serve.py --url http://127.0.0.1:8081 --sizes 300 --repeat 0 --multiturn --side-request \
    --system ~/bench/p6_system.txt --warm --min-resident 96 --tag p6http2 --json ~/bench/ttft_p6.jsonl 2>&1 \
    | grep "^turn\|^side\|^regen\|^multiturn\|^\[resid.*short\|REFUSED\|Traceback\|Error"
echo "--- REUSE lines from the gateway log:"; grep "^REUSE" ~/glm53_server.log | tail -5
VERDICT=$(python3 - <<'PY'
import json
r=[json.loads(l) for l in open("/home/ronald/bench/ttft_p6.jsonl") if '"p6http2"' in l]
t1=[x for x in r if x["kind"]=="turn1"]; t2=[x for x in r if x["kind"]=="turn2"]
print("PASS" if t1 and t2 and t2[-1]["ttft_s"] and t1[-1]["ttft_s"] and t2[-1]["ttft_s"] < 0.35*t1[-1]["ttft_s"] else "FAIL")
PY
)
echo "live-gateway reuse: $VERDICT"
if [ "$VERDICT" != PASS ]; then
  echo "REVERTING the serving script"; cp ~/bench/start_glm53.sh.p6cbase ~/start_glm53.sh
  pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 8; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
else
  echo "P6 IN SERVICE: 4 slots, CPU recurrence"
fi
echo "=== p6c done $VERDICT $(date -Is)"
