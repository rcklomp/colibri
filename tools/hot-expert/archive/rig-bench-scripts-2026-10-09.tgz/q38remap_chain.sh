#!/bin/bash
# q38remap_chain.sh -- re-take qwen38-vk steady-state rows on the rome rig
# after the upstream `dev` merge moved the expert mapping into c/st.h
# (st_map_shard_range, COLI_MAP_EXPERTS_DEFAULT=1 for qwen38/qwen38-vk).
# Measurement only: no engine code, shaders, or serving script are touched.
#
# Structure follows ~/bench/devmerge_chain.sh's pattern: stop gateway -> build
# -> tests -> drop GLM / warm Qwen -> rome_bench.sh's own remote body (so the
# regime and the record-append are the harness's, byte for byte) -> drop Qwen
# / warm+serve GLM -> report. GLM warm + gateway back is the one thing that
# must happen on every exit path.
set -u
TAG=q38remap$(date +%m%d%H%M)
OUT=~/bench/q38remap_out; mkdir -p "$OUT"
SRC=~/src/colibri
QWEN_SNAP=~/models/Qwen3.8-Flash-Next-FP8
GLM_SNAP=~/models/GLM-5.3-Flash-colibri-int4-g64
RECORD="$SRC/tools/hot-expert/ROME-3x7900XTX-2026-09-04.md"
GATEWAY_UP=0

log() { echo "[$(date -Is)] $*"; }

wait_no_engine() {   # <name>
  local name=$1
  for _ in $(seq 1 240); do pgrep -x "$name" >/dev/null || return 0; sleep 1; done
  echo "REFUSED: a $name is still running: $(pgrep -x "$name" | tr '\n' ' ')"; return 1
}

residency_pct() {   # <glob...>  -> prints "size=<B> res=<B> pct=<P>"
  fincore -b --noheadings -o SIZE,RES "$@" 2>/dev/null | \
    awk '{sz+=$1; res+=$2} END{ if (sz>0) printf "size=%d res=%d pct=%.2f\n", sz, res, 100*res/sz; else print "size=0 res=0 pct=0" }'
}

start_gateway() {
  log "restarting the gateway (warm GLM first, no SKIP_WARM -- a few minutes)"
  setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  for _ in $(seq 1 90); do
    if pgrep -f "openai_[s]erver.py" >/dev/null && pgrep -x glm53 >/dev/null; then break; fi
    sleep 10
  done
  local svc eng
  svc=$(pgrep -f "openai_[s]erver.py" | wc -l)
  eng=$(pgrep -x glm53 | wc -l)
  log "gateway processes: server=$svc engine=$eng"
  if [ "$svc" -ge 1 ] && [ "$eng" -ge 1 ]; then
    GATEWAY_UP=1
    if [ -s ~/.colibri_api_key ]; then
      local code
      code=$(curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $(cat ~/.colibri_api_key)" http://127.0.0.1:8081/v1/models)
      log "curl /v1/models -> $code"
    fi
    log "GLM residency after restart:"
    residency_pct "$GLM_SNAP"/*.safetensors | tee "$OUT/glm_residency_final.txt"
  else
    log "WARNING: gateway did not come up cleanly (server=$svc engine=$eng)"
  fi
}

on_exit() {
  rc=$?
  log "=== chain exiting rc=$rc"
  if [ "$GATEWAY_UP" != 1 ]; then
    if ! { pgrep -f "openai_[s]erver.py" >/dev/null && pgrep -x glm53 >/dev/null; }; then
      log "gateway not confirmed up -- restoring it as the one mandatory step"
      pkill -9 -x qwen38-vk 2>/dev/null; pkill -9 -x qwen38 2>/dev/null
      wait_no_engine qwen38-vk; wait_no_engine qwen38
      start_gateway
    fi
  fi
  log "=== q38remap chain done"
}
trap on_exit EXIT

log "=== q38remap chain start ($TAG) ==="

# --- Step 1: refuse to start if another engine is running; stop the gateway.
if pgrep -x qwen38 >/dev/null || pgrep -x qwen38-vk >/dev/null || pgrep -x glm53 >/dev/null; then
  log "an engine appears to already be running:"
  pgrep -x qwen38 -l 2>/dev/null; pgrep -x qwen38-vk -l 2>/dev/null; pgrep -x glm53 -l 2>/dev/null
fi
log "stopping the gateway"
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53
wait_no_engine glm53 || { log "REFUSED: glm53 would not die"; exit 1; }
log "gateway stopped, glm53 confirmed dead"

# --- Step 2: build from the current tree, confirm HEAD, run the four C tests.
log "tree HEAD:"; git -C "$SRC" log --oneline -1
log "building qwen38 qwen38-vk VK=1"
make -C "$SRC/c" qwen38 qwen38-vk VK=1 > "$OUT/build.log" 2>&1
mrc=$?
tail -20 "$OUT/build.log"
[ $mrc -eq 0 ] && [ -x "$SRC/c/qwen38-vk" ] && [ -x "$SRC/c/qwen38" ] || { log "REFUSED: build failed (rc=$mrc), see $OUT/build.log"; exit 1; }

for t in test_qwen38_prefix test_qwen38_config test_qwen38_metrics test_qwen38_serve_framing; do
  ( cd "$SRC/c" && ./tests/$t ) > "$OUT/$t.log" 2>&1
  trc=$?
  log "$t exit=$trc"
  [ $trc -eq 0 ] || { log "REFUSED: $t failed, see $OUT/$t.log"; exit 1; }
done

# --- Step 3: drop GLM without sudo (posix_fadvise, same primitive datapoint.py's
# evict_cache uses), warm Qwen, assert residency with fincore before recording.
log "free -g / MemAvailable before drop:"
free -g
awk '/MemAvailable/{print "MemAvailable: " $2 " kB"}' /proc/meminfo

python3 - <<'PYEOF'
import sys, os
sys.path.insert(0, os.path.expanduser("~/src/colibri/c/tools"))
import datapoint
ok = datapoint.evict_cache(247.0, snap_dir=os.path.expanduser("~/models/GLM-5.3-Flash-colibri-int4-g64"))
print("evict_cache(GLM) ->", ok)
PYEOF

log "free -g / MemAvailable after GLM drop:"
free -g
awk '/MemAvailable/{print "MemAvailable: " $2 " kB"}' /proc/meminfo

log "warming Qwen3.8 ($QWEN_SNAP) -- cat every shard"
find "$QWEN_SNAP" -type f \( -name "*.safetensors" -o -name "*.bin" \) -print0 | \
  while IFS= read -r -d '' f; do cat "$f" > /dev/null; done

log "free -g / MemAvailable after Qwen warm:"
free -g
awk '/MemAvailable/{print "MemAvailable: " $2 " kB"}' /proc/meminfo

log "fincore residency, Qwen shards:"
residency_pct "$QWEN_SNAP"/*.safetensors | tee "$OUT/qwen_residency.txt"
QPCT=$(awk -F'pct=' '{print $2}' "$OUT/qwen_residency.txt")
log "Qwen residency = ${QPCT}%"
awk -F'[= ]' '{ if ($NF+0 < 99.0) exit 1 }' "$OUT/qwen_residency.txt" || log "WARNING: Qwen residency under 99%"

# --- Step 4: rome_bench.sh's own remote body, extracted verbatim so the regime
# and the record-append (RECORD_PATH resolves to the real record on THIS box)
# are the harness's own, byte for byte -- same pattern as devmerge_chain.sh.
awk "/bash -s \\\$REMOTE_ARGV/{f=1;next} /^REMOTE_SCRIPT\$/{f=0} f" "$SRC/tools/rome_bench.sh" > "$OUT/rb_body.sh"
grep -q 'RECORD_PATH=' "$OUT/rb_body.sh" || { log "REFUSED: could not extract rome_bench.sh's remote body"; exit 1; }

romebench() {   # <config-name> <extra-env>
  wait_no_engine qwen38-vk || exit 2
  wait_no_engine qwen38 || exit 2
  log "--- rome_bench qwen38-vk $1 (extra: ${2:-none})"
  bash "$OUT/rb_body.sh" qwen38-vk "$1" "${2:-}" > "$OUT/rb_$1.txt" 2>&1
  local rc=$?
  log "  rc=$rc"
  grep -E "^RESULT:|Rotating median|GPU tier confirmed|Vulkan tier preloaded|Appended row|Error" "$OUT/rb_$1.txt" | sed 's/^/  /'
  return $rc
}

romebench q-remap-run1 ""                    || { log "REFUSED: q-remap-run1 failed"; exit 1; }
romebench q-remap-run2 ""                    || { log "REFUSED: q-remap-run2 failed"; exit 1; }
romebench q-remap-nomap "COLI_MAP_EXPERTS=0" || { log "REFUSED: q-remap-nomap failed"; exit 1; }

wait_no_engine qwen38-vk || true
wait_no_engine qwen38 || true

# --- Step 5: drop Qwen, restore the daily service (GLM warm + gateway).
log "free -g / MemAvailable before dropping Qwen:"
free -g
python3 - <<'PYEOF'
import sys, os
sys.path.insert(0, os.path.expanduser("~/src/colibri/c/tools"))
import datapoint
ok = datapoint.evict_cache(247.0, snap_dir=os.path.expanduser("~/models/Qwen3.8-Flash-Next-FP8"))
print("evict_cache(Qwen) ->", ok)
PYEOF
log "free -g / MemAvailable after Qwen drop:"
free -g

start_gateway

# --- Step 6: report the three new runs next to the 2026-09-06 rows.
log "=== summary ==="
for f in q-remap-run1 q-remap-run2 q-remap-nomap; do
  echo "--- $f"
  grep -E "Rotating median:|RESULT:" "$OUT/rb_$f.txt"
done
echo "2026-09-06 rows: q-baseline-run1 rotating 4.06 warm 5.45 cold 2.32; q-baseline-run2 rotating 4.10 warm 5.46 cold 2.40"
tail -5 "$RECORD"
