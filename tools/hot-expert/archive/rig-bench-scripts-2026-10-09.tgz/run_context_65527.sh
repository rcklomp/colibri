#!/bin/bash
# Real GLM-5.3 measurement at 65,527 tokens (the verified-exact size that fits
# under the live gateway's 65,536-token slot ceiling). Run directly by the
# coordinator after two failed delegated attempts; follows CLAUDE.md rig
# discipline precisely: lock before stopping the gateway, wait for the engine
# to die, restore on every exit path.
set -u
cd /home/ronald/src/colibri || exit 1
. tools/hot-expert/rig_lock.sh

LOG=/home/ronald/bench/context_65527_run.log
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

echo "[$(date -Is)] start"

wait_no_engine() {
  for _ in $(seq 1 180); do pgrep -x glm53 >/dev/null || return 0; sleep 1; done
  echo "REFUSED: a glm53 is still running after 180s"
  return 1
}

cleanup() {
  echo "[$(date -Is)] cleanup: restoring gateway"
  pkill -f "openai_[s]erver.py" 2>/dev/null
  pkill -9 -x glm53 2>/dev/null
  wait_no_engine
  SKIP_WARM=1 setsid nohup /home/ronald/start_glm53.sh > /home/ronald/glm53_server.log 2>&1 < /dev/null &
  disown
  rig_lock_release
  echo "[$(date -Is)] cleanup done"
}
trap cleanup EXIT

rig_lock_take context_65527 || { echo "REFUSED: rig lock held by another chain"; exit 3; }

echo "[$(date -Is)] stopping the owner gateway (this run holds the rig lock)"
pkill -f "openai_[s]erver.py" 2>/dev/null
pkill -9 -x glm53 2>/dev/null
wait_no_engine || exit 2

# Residency: the documented baseline with an engine up is ~91.6%, not 95%+
# (PREFILL-ROADMAP-2026-09.md, "Discipline this track inherits", point 3).
# Assert and print, don't gate on an unreachable number.
echo "[$(date -Is)] residency check"
python3 -c "
import subprocess
out = subprocess.run(['bash','-c','for f in /home/ronald/models/GLM-5.3-Flash-colibri-int4-g64/*.safetensors; do fincore --raw \"\$f\" 2>/dev/null | tail -1; done'], capture_output=True, text=True).stdout
print(out[:2000])
" || true

echo "[$(date -Is)] running prefill_profile.sh at 65,527 tokens (this is the long step)"
# PROFILE_MIN_RESIDENT: empirically confirmed on this box (2026-09-15, two independent
# checks) that ~91.6-91.7% is the real achievable ceiling, matching the documented
# precedent in PREFILL-ROADMAP-2026-09.md ("the gateway's sits at 91.6%"). 100% is not
# reachable in practice here; repeated stop/restart cycles measured LOWER (87-90%), not
# higher. Overriding to 90, just below the demonstrated achievable number, rather than
# continuing to chase an unreachable floor.
PROFILE_MIN_RESIDENT=90 OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close \
  tools/hot-expert/prefill_profile.sh /home/ronald/src/colibri/c/glm53 /home/ronald/bench/prompt_65527.txt ctx65527 128

echo "[$(date -Is)] prefill_profile.sh done, exit=$?"
echo "[$(date -Is)] finished"
