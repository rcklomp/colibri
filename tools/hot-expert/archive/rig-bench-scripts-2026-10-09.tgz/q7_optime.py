#!/usr/bin/env python3
"""Median of the `decode only` [OPTIME] bank across repeats of a tag group."""
import sys, os, glob, statistics

D = os.path.expanduser("~/bench/q7_probe_out")

def decode_bank(path):
    out, on = {}, False
    for line in open(path, errors="replace"):
        if "[OPTIME] === decode only" in line:
            on = True
            out["__step__"] = float(line.split("forwards,")[1].split("ms/forward")[0])
            continue
        if on and "[OPTIME] === whole run" in line:
            break
        if on and line.startswith("[OPTIME]"):
            f = line.split()
            if len(f) >= 3:
                try:
                    out[f[1]] = float(f[2])
                except ValueError:
                    pass
    return out

def group(pat):
    banks = [decode_bank(p) for p in sorted(glob.glob(os.path.join(D, pat + ".log")))]
    banks = [b for b in banks if b]
    if not banks:
        return {}, 0
    keys = set().union(*[set(b) for b in banks])
    return {k: statistics.median([b[k] for b in banks if k in b]) for k in keys}, len(banks)

rows = ["__step__", "dn-proj", "qsa-proj", "lm-head", "vk-dense", "dense-matmul",
        "deltanet", "attention", "moe", "vk-take", "vk-issue", "cpu-experts",
        "qsa-attn", "qsa-index", "qsa-rest", "dn-recur", "dn-conv", "dn-qknorm",
        "dn-gnorm", "gr-down", "gr-up", "gr-read", "router", "shared"]
tags = sys.argv[1:]
data = {}
for t in tags:
    data[t], n = group(t)
    print(f"# {t}: {n} repeats", file=sys.stderr)
w = max(len(r) for r in rows) + 2
print("bucket".ljust(w) + "".join(t.rjust(14) for t in tags))
for r in rows:
    line = r.ljust(w)
    for t in tags:
        v = data[t].get(r)
        line += (f"{v:14.3f}" if v is not None else "".rjust(14))
    print(line)
