#!/bin/bash
set -u
. /home/ronald/src/colibri/tools/hot-expert/rig_lock.sh
rig_lock_take q10-perf || exit 3
restore() {
  pgrep -f "openai_[s]erver.py" >/dev/null || \
    SKIP_WARM=1 setsid nohup /home/ronald/start_glm53.sh > /home/ronald/glm53_server.log 2>&1 < /dev/null &
  sleep 2; rig_lock_release
}
trap restore EXIT INT TERM
pkill -f "openai_[s]erver.py"; sleep 2; pkill -9 -x glm53
for i in $(seq 1 60); do pgrep -x glm53 >/dev/null || break; sleep 1; done
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close
EV=cycles,instructions,cache-references,cache-misses,LLC-load-misses,LLC-store-misses
for REG in 0 2; do
for VAR in 0 7; do
echo "===== perf stat  regime=$REG variant=$VAR ====="
Q10_NOORACLE=1 Q10_ONLY=$VAR Q10_REG=$REG perf stat -e $EV /tmp/rome_dnbench recur 2>&1 | grep -E "ms/token|cycles|instructions|cache|LLC|elapsed|insn per"
done; done
