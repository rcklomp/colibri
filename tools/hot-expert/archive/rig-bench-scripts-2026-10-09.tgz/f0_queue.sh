#!/bin/bash
sleep 900   # let the agent's own 15 x 60 s retry loop expire first
for i in $(seq 1 40); do
  ~/src/colibri-f0/tools/hot-expert/run_chain.sh ~/src/colibri-f0/tools/hot-expert/vk_stream_chain.sh >> ~/bench/vk_stream.log 2>&1; rc=$?
  echo "=== f0_queue attempt $i $(date -Is): run_chain exit=$rc" >> ~/bench/vk_stream.log
  [ "$rc" != 3 ] && exit 0
  sleep 300
done
echo "=== f0_queue: GIVING UP" >> ~/bench/vk_stream.log
