#!/bin/bash
# lookahead_cpu_check.sh -- CPU-twin checks of the router-lookahead probe (GLM5.md 14b). No GPU: the CPU
# binaries link no HIP. Each step starts only while ~/bench/.rig.lock is absent or its owner pid is dead,
# runs nice -n 19 with 4 threads and is bounded by `timeout`; the script waits (polling) for a free lock.
set -u
D=$HOME/src/franken-engine-lookahead/franken/decode
BASE=$HOME/bench/lookahead_base_src/franken/decode/franken_decode_glm_cpu     # b5cf4e0, the parent commit
NEW=$D/franken_dec_glm_cpu                                                     # this branch, make glm-serve-cpu
M=$HOME/models/GLM-5.3-Flash/UD-IQ4_XS/GLM-5.3-Flash-UD-IQ4_XS-00001-of-00005.gguf
PR=$HOME/bench/franken/glm5/prose2200.txt
O=$HOME/bench/franken/glm5/lookahead_cpu
mkdir -p $O
lock_free() {
  local L=$HOME/bench/.rig.lock pid
  [ ! -e $L ] && return 0
  pid=$(grep -o '[0-9]\{3,\}' $L/owner 2>/dev/null | sed -n 1p)
  [ -n "$pid" ] && ! kill -0 $pid 2>/dev/null
}
wait_free() { local n=0; until lock_free; do n=$((n+1)); [ $n -gt ${LA_WAIT_POLLS:-720} ] && { echo "lock still held after the wait: giving up"; exit 3; }; sleep 15; done; }
# the configuration of GLM5.md 9.5: 24 prose tokens, layers 0-5, three "cards", adaptation swapping every 2 tokens
COMMON="--model $M --tokens-file $PR --max-tokens 24 --cpu --layers 0-5 --no-head --ctx 512 --threads 4 --devices 3 --three-link 1 --adapt 1 --placement $HOME/bench/m2/glm --expert-gb 0.3 --adapt-every 2 --adapt-mb-per-token 64 --adapt-verify 1"
step() { local name=$1; shift; wait_free; echo "=== $name $(date -Is) lock: $(cat $HOME/bench/.rig.lock/owner 2>/dev/null || echo absent)"; \
  ( ulimit -v unlimited; timeout 290 nice -n 19 "$@" ) > $O/$name.log 2>&1; echo "rc=$? ($name)"; }
echo "=== lookahead_cpu_check start $(date -Is)"
step base24      $BASE $COMMON --dump $O/base24
step off24       $NEW  $COMMON --oracle $O/base24
step on24        $NEW  $COMMON --oracle $O/base24 --lookahead-probe 1 --lookahead-prompt 1 --lookahead-lag 0,1,2 --lookahead-out $O/on24.la.log
# a small real-model sample of the lag-1/2 hit rates: layers 0-11 (targets 3-11), 20 prose tokens, 2 GB of experts a "card"
DEEP="--model $M --tokens-file $PR --max-tokens 20 --cpu --layers 0-11 --no-head --ctx 512 --threads 4 --devices 3 --three-link 1 --adapt 1 --placement $HOME/bench/m2/glm --expert-gb 2 --adapt-every 2 --adapt-mb-per-token 64"
step deep20      $NEW  $DEEP --lookahead-probe 1 --lookahead-prompt 1 --lookahead-lag 1,2 --lookahead-out $O/deep20.la.log
for n in base24 off24 on24 deep20; do
  echo "--- $n"; grep -E "^arch=|ORACLE|oracle summary|adapt_verify|^lookahead|LOOKAHEAD|greedy" $O/$n.log | cut -c1-260 | head -12
  echo "taps compared: $(grep -c '^oracle .* cos=' $O/$n.log)  not bit-exact: $(grep '^oracle .* cos=' $O/$n.log | grep -vc 'cos=1.000000 maxabs=0 ')"
done
for n in on24 deep20; do
  python3 $D/glm5_lookahead_report.py $O/$n.la.log --phase all --csv $O/$n.csv > $O/$n.report.txt 2>&1; echo "report $n rc=$? ($(wc -l < $O/$n.report.txt) lines)"
done
echo "=== lookahead_cpu_check done $(date -Is)"
