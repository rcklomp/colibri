#!/bin/bash
# M0c: the 256k window with 1024 (the slow known config) and 3072 MiB fit margin, GTT/VRAM sampled
# every 20 s -- is the 128k->256k step a VRAM overcommit evicted to GTT?
until ~/src/colibri/tools/hot-expert/serve_alt.sh status 2>&1 | grep -q "serving: GLM-5.3 (model id"; do sleep 30; done
until [ ! -d ~/bench/.rig.lock ] || ! kill -0 $(awk "{print \$2}" ~/bench/.rig.lock/owner 2>/dev/null) 2>/dev/null; do sleep 30; done
( while true; do echo "$(date +%T) $(for d in /sys/class/drm/card[0-9]/device; do printf "vram=%d gtt=%d " $(($(cat $d/mem_info_vram_used)/1048576)) $(($(cat $d/mem_info_gtt_used)/1048576)); done)"; sleep 20; done ) > ~/bench/f11_gtt.log 2>&1 &
SAMPLER=$!
export F11_ONLY=Q F11_SKIP_SWEEP=1 F11_CTX=262144
for m in 1024 3072; do
  echo "=== f11_fit ctx=262144 margin=$m $(date -Is)"
  FIT_MARGIN_MIB=$m ~/src/colibri/tools/hot-expert/run_chain.sh ~/src/colibri/tools/hot-expert/f11_ladder_chain.sh > ~/bench/f11_fit_262144_m${m}.log 2>&1
  echo "=== rc=$? $(date -Is)"
done
kill $SAMPLER
sleep 60; ~/src/colibri/tools/hot-expert/accept_live.sh | tail -1
