#!/bin/bash
# P0 chain (2026-09-06): waits for the baseline harness, then the pristine-vs-pristine
# gate, the one-time long rows, and the gateway restart. Log: ~/bench/p0_chain.log
cd ~/src/colibri
while pgrep -f "ttft_[s]erve.py" >/dev/null; do sleep 20; done
echo "=== chain start $(date -Is)"
cp -n c/glm53 ~/bench/glm53.pristine; md5sum ~/bench/glm53.pristine
echo "=== gate pristine-vs-pristine $(date -Is)"
tools/hot-expert/prefill_gate.sh ~/bench/glm53.pristine ~/bench/glm53.pristine p0self
echo "=== gate rc=$? $(date -Is)"
echo "=== long rows $(date -Is)"
python3 tools/hot-expert/ttft_serve.py --engine ~/bench/glm53.pristine --sizes 3000 --repeat 1 --warm --tag p0-3000 --json ~/bench/ttft_p0.jsonl 2>&1 | grep -v "^\[VK\]\|^cache:"
python3 tools/hot-expert/ttft_serve.py --engine ~/bench/glm53.pristine --sizes 30 --repeat 1 --warm --tools /tmp/owui_tools.json --tag p0-tools --json ~/bench/ttft_p0.jsonl 2>&1 | grep -v "^\[VK\]\|^cache:"
echo "=== restart gateway $(date -Is)"
pgrep -x glm53 && pkill -9 -x glm53; sleep 2
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== chain done $(date -Is)"
