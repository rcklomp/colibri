#!/bin/bash
# P7 smoke, take 2: pin-block after the slot-hash fix, plus the step-5
# neutrality check (two identical prompts must not capture or restore).
set -u
LOG=~/bench/p7_smoke_out
mkdir -p $LOG
export COLI_CKPT_DIR=$LOG/ckpt2
mkdir -p $COLI_CKPT_DIR
rm -f $COLI_CKPT_DIR/*.bin
S=~/src/colibri-p7
restart_gateway() {
  echo "--- restarting the gateway $(date -Is)"
  SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
  sleep 90
  echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
}
trap restart_gateway EXIT
echo "=== p7 smoke2 start $(date -Is)"
cd $S && git fetch -q origin && git checkout -q -B p0-sync origin/p0-sync && git log --oneline -1
make -C c glm53 VK=1 2>&1 | grep -E " error|Error 1" && { echo BUILD FAILED; exit 9; }
~/bench/p7_stop.sh || exit 2

echo "### smoke B2: --pin-block"
timeout 1800 python3 -u $S/tools/hot-expert/ttft_serve.py --engine $S/c/glm53 \
   --pin-block --kv-slots 4 --sizes "" --repeat 0 --min-resident 90 \
   --tag smokeB2 --json $LOG/smoke.jsonl --engine-log $LOG/engine_b2.log 2>&1
echo "smoke B2 rc=$?"

echo "### smoke D: repeat neutrality (sizes 300, repeat 2, checkpoints ON)"
timeout 1800 python3 -u $S/tools/hot-expert/ttft_serve.py --engine $S/c/glm53 \
   --sizes 300 --repeat 2 --min-resident 90 --kv-slots 4 \
   --tag smokeD --json $LOG/smoke.jsonl --engine-log $LOG/engine_d.log 2>&1
echo "smoke D rc=$?"
echo "--- engine lines"; grep "^CKPT\|^REUSE" $LOG/engine_b2.log $LOG/engine_d.log
echo "=== p7 smoke2 done $(date -Is)"
