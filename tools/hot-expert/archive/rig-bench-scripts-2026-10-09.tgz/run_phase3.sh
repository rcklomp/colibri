#!/usr/bin/env bash
cd /home/ronald/src/colibri
M=/home/ronald/models/Qwen3.8-Flash-Next-FP8
log(){ echo "[$(date +%H:%M:%S)] $*"; }
while ! grep -q "phase2 done" ~/bench/phase2.out; do sleep 5; done
log "branch + apply"
git checkout -q -b perf/rome-cpu-path 2>&1 || git checkout -q perf/rome-cpu-path
cp ~/bench/staged/quant.h c/quant.h; cp ~/bench/staged/qwen38_core.h c/qwen38_core.h
git diff --stat
cd c
log "fp8test"
gcc -O3 -march=native -fopenmp -I. ~/bench/fp8test.c -o ~/bench/fp8test -lm 2>&1 | grep -E "error|warning" | head -5
OMP_NUM_THREADS=16 ~/bench/fp8test
log "build qwen38 + qwen38-vk"
make qwen38 qwen38-vk VK=1 2>&1 | grep -E "error|warning: (unused|implicit)" | head -10; echo "build rc=${PIPESTATUS[0]}"
run(){ name=$1; shift; log "run $name"; env "$@" SNAP=$M N_NEW=64 NOSTREAM=1 COLI_TIMERS=1 COLI_USAGE=/home/ronald/bench/q38_usage_cpu.bin /usr/bin/time -v ./qwen38 512 8 ~/bench/prompt1.txt > ~/bench/q38_$name.log 2>&1; echo "rc=$?"; grep -E "Speed|TTFT|routed-expert|resident-mm|deltanet|shared-expert|expert-read|Major|Minor|Percent|Text" ~/bench/q38_$name.log; }
run patched_all X=1
run patched_nopopulate Q38_MMAP_POPULATE=0
run patched_nofuse Q38_DENSE_MULTI=0
run patched_all_rep2 X=1
log "phase3 done"
