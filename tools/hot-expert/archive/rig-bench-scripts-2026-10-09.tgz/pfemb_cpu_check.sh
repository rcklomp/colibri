#!/bin/bash
# pfemb_cpu_check.sh <part 1|2> -- CPU-arm checks of the pf-embed-kernel branch (GLM5.md 15): the embedding
# rows by kernel (the default, Ds4Ops::rows_bank + copy_rows) are bit-identical to the old staged upload
# (--embed-upload-dma 1) and to the pre-change engine. No GPU. Refuses while the rig lock is held by a live
# process. Each part < 5 min, nice 19, 4 threads.
set -u
if [ -d ~/bench/.rig.lock ]; then
  pid=$(awk '{print $2}' ~/bench/.rig.lock/owner 2>/dev/null)
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && { echo "REFUSED: rig lock held by $(cat ~/bench/.rig.lock/owner)"; exit 3; }
fi
W=/home/ronald/src/franken-engine-pfemb/franken/decode
N=$W/franken_decode_glm_cpu
M=/home/ronald/models/GLM-5.3-Flash/UD-IQ4_XS/GLM-5.3-Flash-UD-IQ4_XS-00001-of-00005.gguf
S5=/home/ronald/bench/franken/glm5/s5
O=/home/ronald/bench/franken/glm5/pfemb_cpu
T6="154822 785 6722 315 9621 374"
T136=/home/ronald/bench/franken/glm5/t136.txt
mkdir -p $O
COMMON="--model $M --cpu --devices 3 --split 2,4 --layers 0-4 --no-head --ctx 4096 --threads 4 --placement /home/ronald/bench/m2/glm --expert-gb 0.3"
verdict() { awk '/^=== gate-plan config/{f=$4} /^oracle .* cos=/{n[f]++; if ($0 !~ /cos=1.000000 maxabs=0 /) b[f]++} /GLM5 CPU ORACLE/{r[f]=$4} END{for (k in n) printf "  %-8s taps=%d not_bitexact=%d oracle=%s\n", k, n[k], b[k]+0, r[k]}' $1 | sort; grep -E "gate_plan_summary|^adapt_snapshot_dma=" $1 | sort | uniq -c; }
if [ "${1:-1}" = 1 ]; then
  # one load, three "devices" (three-link, helpers computing missed experts). a* = the OLD path
  # (--embed-upload-dma 1) dumps, n* = the new path (default) held to that dump bit for bit:
  # a6/n6 -- 6 tokens in chunks of 2 (T = 2, the piped boundary); a6t/n6t -- the same 6 tokens one at a
  # time (T = 1: the decode-shaped step; 6 steps wrap the 4 banks once)
  cat > $O/p1_plan.txt <<PLAN
a6   --tokens $T6 --adapt 0 --chunk 2 --embed-upload-dma 1 --dump $O/a6
n6   --tokens $T6 --adapt 0 --chunk 2 --oracle $O/a6
a6t  --tokens $T6 --adapt 0 --embed-upload-dma 1 --dump $O/a6t
n6t  --tokens $T6 --adapt 0 --oracle $O/a6t
PLAN
  timeout 300 nice -n 19 $N $COMMON --gate-plan $O/p1_plan.txt > $O/p1.log 2>&1; echo "part 1 rc=$?"
  verdict $O/p1.log
else
  # 136 tokens in chunks of 32 (5 steps: the 4 banks wrap once) on the new path, against the pre-change
  # token-by-token reference (s5/base136, the CPU gates' reference since GLM step 5)
  cat > $O/p2_plan.txt <<PLAN
c32n --tokens-file $T136 --oracle $S5/base136 --adapt 0 --chunk 32
PLAN
  timeout 300 nice -n 19 $N $COMMON --gate-plan $O/p2_plan.txt > $O/p2.log 2>&1; echo "part 2 rc=$?"
  verdict $O/p2.log
fi
