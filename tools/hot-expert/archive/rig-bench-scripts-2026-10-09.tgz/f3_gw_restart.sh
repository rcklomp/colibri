#!/bin/bash
# restart the gateway under the rig lock, then accept_live
. ~/src/colibri/tools/hot-expert/rig_lock.sh
rig_lock_take f3_gw_restart || exit 3
trap rig_lock_release EXIT
pkill -f "openai_[s]erver.py" || true
pkill -9 -x glm53 2>/dev/null || true
for _ in $(seq 1 60); do pgrep -x glm53 >/dev/null 2>&1 || break; sleep 2; done
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
KEY=$(cat ~/.colibri_api_key)
for _ in $(seq 1 90); do sleep 10; c=$(curl -s -o /dev/null -m 20 -w "%{http_code}" -H "Authorization: Bearer $KEY" http://127.0.0.1:8081/v1/models); [ "$c" = 200 ] && break; done
echo "models=$c engine=$(pgrep -x glm53 | wc -l)"
~/src/colibri/tools/hot-expert/accept_live.sh
echo "accept_live rc=$?"
