#!/usr/bin/env bash
cd /home/ronald/src/colibri/c
G=/home/ronald/models/GLM-5.3-Flash-colibri-int4-g64
P="$(cat ~/bench/prompt_glm.txt)"
log(){ echo "[$(date +%H:%M:%S)] $*"; }
log "warm GLM"; cat $G/*.safetensors > /dev/null
fincore --bytes --noheadings $G/*.safetensors | awk '{r+=$1} END {printf "resident %.1f GiB\n", r/2^30}'
VK="COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_EXPERTS2=1695 COLI_VK_DEV3=auto COLI_VK_EXPERTS3=1695 COLI_VK_SHADERS=shaders COLI_USAGE_PATH=/home/ronald/.glm53_explain.bin"
for r in 1 2; do
  log "GLM 3-GPU, caps 1695/1695, explain histogram, run $r"
  env $VK /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_repro2_gpu_$r.log 2>&1; echo "rc=$?"
  grep -E "preload|denso|decode |caricamento|Major|experts hits" ~/bench/glm_repro2_gpu_$r.log | cut -c1-140
  amd-smi monitor -v 2>/dev/null | head -4
done
log "GLM CPU-only, warm, 8 threads (launcher default)"
OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close /usr/bin/time -v ./glm53 --model $G --prompt "$P" --greedy 60 > ~/bench/glm_repro2_cpu8.log 2>&1; echo "rc=$?"
grep -E "decode |caricamento|Major|experts hits" ~/bench/glm_repro2_cpu8.log | cut -c1-140
log "glm repro2 done"
sed -i 's/glm repro done/glm repro2 done/; s/glm_repro.out/glm_repro2.out/' ~/bench/run_steady.sh
nohup ~/bench/run_steady.sh > ~/bench/steady.out 2>&1 &
