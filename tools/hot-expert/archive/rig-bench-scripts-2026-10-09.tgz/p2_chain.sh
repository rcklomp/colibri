#!/bin/bash
# P2 gate chain (2026-09-06): waits for p0_chain, gates the P2 candidate against the pristine binary.
LOG=~/bench/p2_chain.log
while pgrep -f "p0_[c]hain.sh" >/dev/null; do sleep 30; done
echo "=== p2 chain start $(date -Is)"
pkill -f "openai_[s]erver.py"; sleep 3; pkill -9 -x glm53 2>/dev/null; sleep 2
echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engines: $(pgrep -x glm53 | wc -l)"
cd ~/src/colibri && git pull -q origin hot-expert-tier && git log --oneline -1
make -C c glm53 VK=1 2>&1 | grep -E "error|warning: unused" ; md5sum c/glm53 ~/bench/glm53.pristine
echo "=== gate $(date -Is)"
tools/hot-expert/prefill_gate.sh ~/bench/glm53.pristine ~/src/colibri/c/glm53 p2
GATE=$?
echo "=== gate rc=$GATE $(date -Is)"
echo "=== tworeq (session-state oracle) $(date -Is)"
export OMP_NUM_THREADS=8 OMP_PLACES=cores OMP_PROC_BIND=close COLI_VULKAN=1 COLI_VK_DEV2=auto COLI_VK_DEV3=auto
export COLI_VK_SHADERS=$HOME/src/colibri/c/shaders COLI_VK_EXPERTS2=1695 COLI_VK_EXPERTS3=1695 COLI_KDA_GPU=2 GLM53_VERBOSE=1
cp ~/.glm53_explain.bin /tmp/p2_hist.bin; export COLI_USAGE_PATH=/tmp/p2_hist.bin
python3 tools/hot-expert/tworeq.py 2>&1 | grep -v "^\[VK\]\|^cache:" | tail -12
TWO=${PIPESTATUS[0]}
echo "=== tworeq rc=$TWO $(date -Is)"
pkill -9 -x glm53 2>/dev/null; sleep 2
if [ "$GATE" = 0 ] && [ "$TWO" = 0 ]; then echo "SERVING THE CANDIDATE"; else echo "GATE FAILED: serving the pristine binary"; cp ~/bench/glm53.pristine c/glm53; fi
md5sum c/glm53
SKIP_WARM=1 setsid nohup ~/start_glm53.sh > ~/glm53_server.log 2>&1 < /dev/null &
sleep 5; echo "gateway: $(pgrep -f "openai_[s]erver.py" | wc -l) engine: $(pgrep -x glm53 | wc -l)"
echo "=== p2 chain done $(date -Is)"
