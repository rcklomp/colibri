#!/bin/bash
echo "##### build"; tail -4 ~/bench/build_comb.log | cut -c1-120
echo "##### moeblk G sweep (stock-kernel baseline G=1 vs blocked G=4/8), chunk 512, ctx 262144, ring auto"
for f in ~/bench/franken/glm5/moeblk/g*/gate_run.log; do [ -f "$f" ] && awk -v d="$(basename $(dirname $f))" '/^=== gate-plan config/ { c = $4 } /^prefill_tokens=/ { split($5, a, "="); printf "  %-14s %s %8.3f ms/token = %6.1f tok/s\n", d, c, a[2], 1000 / a[2] }' "$f"; done
echo "##### combined (blocked experts + chunk 1024)"
sed -n '/=== comb start/,$p' ~/bench/glm_comb_chain.log 2>/dev/null | grep -vE "^run_chain|^$" | cut -c1-200 | head -40
