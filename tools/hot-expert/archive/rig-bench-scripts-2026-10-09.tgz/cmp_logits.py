import sys, struct, math
def load(p):
    b=open(p,'rb').read(); n=len(b)//4; return struct.unpack('<%df'%n,b)
a=load(sys.argv[1]); b=load(sys.argv[2])
n=min(len(a),len(b)); dot=sa=sb=0.0; mx=0.0
for i in range(n):
    dot+=a[i]*b[i]; sa+=a[i]*a[i]; sb+=b[i]*b[i]; d=abs(a[i]-b[i]); mx=max(mx,d)
cos=dot/math.sqrt(sa*sb) if sa and sb else float('nan')
ia=max(range(n),key=lambda i:a[i]); ib=max(range(n),key=lambda i:b[i])
print("%s vs %s: cos=%.8f maxabs=%.4g argmax %d vs %d %s"%(sys.argv[1].split('/')[-1],sys.argv[2].split('/')[-1],cos,mx,ia,ib,"SAME" if ia==ib else "DIFF"))
